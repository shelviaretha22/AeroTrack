<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['paginator']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['paginator']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $dari = $paginator->total() ? $paginator->firstItem() : 0;
    $sampai = $paginator->total() ? $paginator->lastItem() : 0;
    $btn = 'inline-flex h-7 min-w-[1.75rem] items-center justify-center rounded-lg border border-[#DCE6E4] px-2 text-[#527D82] hover:bg-[#F3F6F5]';
    $off = 'inline-flex h-7 min-w-[1.75rem] items-center justify-center rounded-lg border border-[#E2EBE9] px-2 text-[#B7C6C3] cursor-not-allowed';
?>
<div class="flex flex-wrap items-center justify-between gap-2 border-t border-[#E2EBE9] px-4 py-2.5 text-[11px] text-[#8BA5A2]">
    <span><?php echo e($dari); ?>–<?php echo e($sampai); ?> dari <?php echo e($paginator->total()); ?> data</span>
    <div class="flex items-center gap-1.5">
        <?php if($paginator->onFirstPage()): ?>
            <span class="<?php echo e($off); ?>">‹</span>
        <?php else: ?>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="<?php echo e($btn); ?>" aria-label="Sebelumnya">‹</a>
        <?php endif; ?>
        <span class="px-1">Hal. <?php echo e($paginator->currentPage()); ?> / <?php echo e(max(1, $paginator->lastPage())); ?></span>
        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="<?php echo e($btn); ?>" aria-label="Berikutnya">›</a>
        <?php else: ?>
            <span class="<?php echo e($off); ?>">›</span>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\AeroTrack\resources\views/components/pager.blade.php ENDPATH**/ ?>