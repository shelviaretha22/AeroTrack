<?php $__env->startSection('page-title', 'Laporan'); ?>

<?php $__env->startSection('content'); ?>

<?php
    $formatRupiah = fn ($nilai) => 'Rp ' . number_format((float) $nilai, 0, ',', '.');

    $totalKomposisi = array_sum($komposisiStatus);

    $persenAktif = $totalKomposisi > 0
        ? ($komposisiStatus['Aktif'] / $totalKomposisi) * 100
        : 0;

    $persenNonaktif = $totalKomposisi > 0
        ? ($komposisiStatus['Nonaktif'] / $totalKomposisi) * 100
        : 0;

    $persenProses = $totalKomposisi > 0
        ? ($komposisiStatus['Proses'] / $totalKomposisi) * 100
        : 0;

    $persenKontrakLengkap = $totalDokumenKontrak > 0
        ? ($dokumenKontrakLengkap / $totalDokumenKontrak) * 100
        : 0;

    $persenBALengkap = $totalBA > 0
        ? ($baLengkap / $totalBA) * 100
        : 0;

    $tahunSekarang = now()->year;
?>

<div class="space-y-6">

    
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
        <div>
            <h1 class="text-2xl font-bold text-[#263F42]">
                Laporan
            </h1>
            <p class="text-sm text-gray-500 mt-1">
                Ringkasan data kerja sama, kontrak, aktivasi, dokumen, dan pendapatan tenant.
            </p>
        </div>

        <div class="text-sm text-gray-500">
            Periode laporan:
            <span class="font-semibold text-[#365F65]">
                Tahun <?php echo e($tahun); ?>

            </span>
        </div>
    </div>

    
    <div>
        <h2 class="text-base font-bold text-[#263F42] mb-3">
            Ringkasan Kontrak
        </h2>

        <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">

            
<div class="bg-white rounded-2xl border border-[#DCE6E4] p-5 shadow-sm">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-xs text-gray-500 font-medium">Total Kontrak</p>
                        <h3 class="text-2xl font-bold text-[#365F65] mt-2">
                            <?php echo e(number_format($totalKontrak)); ?>

                        </h3>
                    </div>
                    <div class="w-11 h-11 rounded-xl bg-[#E7EFED] flex items-center justify-center text-[#365F65]">
                        <i class="fas fa-file-contract text-lg"></i>
                    </div>
                </div>
            </div>

            
            <div class="bg-white rounded-2xl border border-[#DCE6E4] p-5 shadow-sm">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-xs text-gray-500 font-medium">Kontrak Aktif</p>
                        <h3 class="text-2xl font-bold text-emerald-700 mt-2">
                            <?php echo e(number_format($kontrakAktif)); ?>

                        </h3>
                    </div>
                    <div class="w-11 h-11 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-700">
                        <i class="fas fa-check-circle text-lg"></i>
                    </div>
                </div>
            </div>

            
            <div class="bg-white rounded-2xl border border-[#DCE6E4] p-5 shadow-sm">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-xs text-gray-500 font-medium">Kontrak Nonaktif</p>
                        <h3 class="text-2xl font-bold text-gray-600 mt-2">
                            <?php echo e(number_format($kontrakNonaktif)); ?>

                        </h3>
                    </div>
                    <div class="w-11 h-11 rounded-xl bg-gray-100 flex items-center justify-center text-gray-600">
                        <i class="fas fa-file-circle-xmark text-lg"></i>
                    </div>
                </div>
            </div>

            
            <div class="bg-white rounded-2xl border border-[#DCE6E4] p-5 shadow-sm">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-xs text-gray-500 font-medium">Kontrak dalam Proses</p>
                        <h3 class="text-2xl font-bold text-amber-600 mt-2">
                            <?php echo e(number_format($kontrakProses)); ?>

                        </h3>
                    </div>
                    <div class="w-11 h-11 rounded-xl bg-amber-50 flex items-center justify-center text-amber-600">
                        <i class="fas fa-clock text-lg"></i>
                    </div>
                </div>
            </div>

        </div>
    </div>

    
<div class="mt-6">

    <h2 class="text-base font-bold text-[#263F42] mb-3">
        Rekapitulasi Periode Kontrak
    </h2>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">

        
        <div class="bg-white rounded-2xl border border-[#DCE6E4] p-5 shadow-sm">

            <div class="flex items-center justify-between">

                <div>
                    <p class="text-xs text-gray-500 font-medium">
                        Lintas
                    </p>

                    <h3 class="text-2xl font-bold text-[#365F65] mt-2">
                        <?php echo e(number_format($kontrakLintas)); ?>

                    </h3>

                    <p class="text-xs text-gray-400 mt-2">
                        Kontrak dengan keputusan tidak memperpanjang
                    </p>
                </div>

                <div class="w-11 h-11 rounded-xl bg-[#E7EFED] flex items-center justify-center text-[#365F65]">
                    <i class="fas fa-file-circle-xmark text-lg"></i>
                </div>

            </div>

        </div>

        
        <div class="bg-white rounded-2xl border border-[#DCE6E4] p-5 shadow-sm">

            <div class="flex items-center justify-between">

                <div>
                    <p class="text-xs text-gray-500 font-medium">
                        Perpanjangan
                    </p>

                    <h3 class="text-2xl font-bold text-emerald-700 mt-2">
                        <?php echo e(number_format($kontrakPerpanjangan)); ?>

                    </h3>

                    <p class="text-xs text-gray-400 mt-2">
                        Kontrak dengan keputusan ingin memperpanjang
                    </p>
                </div>

                <div class="w-11 h-11 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-700">
                    <i class="fas fa-file-signature text-lg"></i>
                </div>

            </div>

        </div>

    </div>

</div>

    
    <div>
        <h2 class="text-base font-bold text-[#263F42] mb-3">
            Ringkasan Pendapatan dan Tagihan
        </h2>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">

            <div class="bg-white rounded-2xl border border-[#DCE6E4] p-5 shadow-sm">
                <p class="text-xs text-gray-500 font-medium">Total Tagihan</p>
                <h3 class="text-xl font-bold text-[#365F65] mt-2">
                    <?php echo e($formatRupiah($totalTagihan)); ?>

                </h3>
                <p class="text-xs text-gray-400 mt-2">Periode tahun <?php echo e($tahun); ?></p>
            </div>

            <div class="bg-white rounded-2xl border border-[#DCE6E4] p-5 shadow-sm">
                <p class="text-xs text-gray-500 font-medium">Invoice Diberikan</p>
                <h3 class="text-xl font-bold text-emerald-700 mt-2">
                    <?php echo e($formatRupiah($invoiceDiberikan)); ?>

                </h3>
                <p class="text-xs text-gray-400 mt-2">Tagihan yang invoice-nya telah diberikan</p>
            </div>

            <div class="bg-white rounded-2xl border border-[#DCE6E4] p-5 shadow-sm">
                <p class="text-xs text-gray-500 font-medium">Pending Invoice</p>
                <h3 class="text-xl font-bold text-amber-600 mt-2">
                    <?php echo e($formatRupiah($pendingInvoice)); ?>

                </h3>
                <p class="text-xs text-gray-400 mt-2">Tagihan yang invoice-nya belum diberikan</p>
            </div>

        </div>
    </div>


    


<?php
    $totalAnalisisJenis = $komposisiJenisUsaha->sum();
    $totalAnalisisTerminal = $kontrakPerTerminal->sum();

    $warnaGrafik = [
        '#087F68',
        '#D6A14D',
        '#365F65',
        '#8BA5A2',
        '#A8BDB9',
        '#C5D4D1',
    ];

    $persenKontrakBelum = $totalDokumenKontrak > 0
        ? round(($dokumenKontrakBelumLengkap / $totalDokumenKontrak) * 100)
        : 0;

    $persenBABelum = $totalBA > 0
        ? round(($baBelumLengkap / $totalBA) * 100)
        : 0;
?>

<div class="grid grid-cols-1 lg:grid-cols-12 gap-3">

    
    <div class="lg:col-span-4 bg-white rounded-2xl border border-[#DCE6E4] p-4 shadow-sm">

        <h2 class="font-bold text-[#263F42] text-sm">
            Kelengkapan Dokumen
        </h2>

        <p class="text-[11px] text-gray-500 mt-1">
            Jumlah kerja sama yang belum memiliki dokumen yang diperlukan.
        </p>

        <div class="grid grid-cols-2 gap-2 mt-3">

            
            <div class="rounded-xl border border-[#E1EAE8] p-3">

                <div class="flex items-start gap-2">

                    <div class="w-8 h-8 shrink-0 rounded-full bg-[#EAF3F1] flex items-center justify-center">
                        <i class="fas fa-file-alt text-[#16856C]"></i>
                    </div>

                    <p class="text-[10px] leading-tight text-[#365F65] font-medium">
                        Kontrak tanpa nomor kontrak mitra
                    </p>

                </div>

                <p class="text-2xl font-bold text-[#263F42] mt-1 ml-10">
                    <?php echo e($dokumenKontrakBelumLengkap); ?>

                </p>

                <div class="ml-10 mt-2 h-1.5 rounded-full bg-[#E2EBE9] overflow-hidden">
                    <div class="h-full rounded-full bg-[#16856C]"
                        style="width: <?php echo e($persenKontrakBelum); ?>%">
                    </div>
                </div>

                <p class="text-right text-[10px] font-semibold text-[#16856C] mt-1">
                    <?php echo e($persenKontrakBelum); ?>%
                </p>

            </div>

            
            <div class="rounded-xl border border-[#E1EAE8] p-3">

                <div class="flex items-start gap-2">

                    <div class="w-8 h-8 shrink-0 rounded-full bg-[#EAF3F1] flex items-center justify-center">
                        <i class="fas fa-file-alt text-[#16856C]"></i>
                    </div>

                    <p class="text-[10px] leading-tight text-[#365F65] font-medium">
                        BA final belum tersedia
                    </p>

                </div>

                <p class="text-2xl font-bold text-[#263F42] mt-1 ml-10">
                    <?php echo e($baBelumLengkap); ?>

                </p>

                <div class="ml-10 mt-2 h-1.5 rounded-full bg-[#E2EBE9] overflow-hidden">
                    <div class="h-full rounded-full bg-[#16856C]"
                        style="width: <?php echo e($persenBABelum); ?>%">
                    </div>
                </div>

                <p class="text-right text-[10px] font-semibold text-[#16856C] mt-1">
                    <?php echo e($persenBABelum); ?>%
                </p>

            </div>

        </div>
    </div>


    
    <div class="lg:col-span-8 bg-white rounded-2xl border border-[#DCE6E4] p-4 shadow-sm">

        <h2 class="font-bold text-[#263F42] text-sm">
            Analisis Data
        </h2>

        <div class="grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-[#DCE6E4] mt-2">

            
            <div class="px-2 py-2">

                <h3 class="text-[11px] font-bold text-center text-[#263F42]">
                    Komposisi Status Kontrak
                </h3>

                <div class="flex flex-col items-center mt-2">

                    <div class="relative w-20 h-20 rounded-full flex items-center justify-center"
                        style="background: conic-gradient(
                            #087F68 0% <?php echo e($persenAktif); ?>%,
                            #D6A14D <?php echo e($persenAktif); ?>% <?php echo e($persenAktif + $persenNonaktif); ?>%,
                            #DCE6E4 <?php echo e($persenAktif + $persenNonaktif); ?>% 100%
                        );">

                        <div class="w-12 h-12 rounded-full bg-white flex flex-col items-center justify-center">
                            <span class="text-lg font-bold text-[#263F42]">
                                <?php echo e(number_format($totalKomposisi)); ?>

                            </span>
                            <span class="text-[9px] text-gray-400">Total</span>
                        </div>

                    </div>

                    <div class="w-full mt-2 space-y-1">

                        <?php $__currentLoopData = [
                            ['nama' => 'Aktif', 'warna' => '#087F68'],
                            ['nama' => 'Nonaktif', 'warna' => '#D6A14D'],
                            ['nama' => 'Proses', 'warna' => '#DCE6E4'],
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="flex items-center justify-between text-[10px]">

                                <div class="flex items-center gap-2">
                                    <span class="w-2 h-2 rounded-full"
                                        style="background: <?php echo e($status['warna']); ?>">
                                    </span>

                                    <span><?php echo e($status['nama']); ?></span>
                                </div>

                                <span class="font-semibold text-[#365F65]">
                                    <?php echo e($komposisiStatus[$status['nama']]); ?>

                                </span>

                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                </div>
            </div>


            
            <div class="px-2 py-2">

                <h3 class="text-[11px] font-bold text-center text-[#263F42]">
                    Jenis Usaha
                </h3>

                <?php
                    $sudutJenis = 0;
                ?>

                <div class="flex flex-col items-center mt-2">

                    <div class="relative w-20 h-20 rounded-full flex items-center justify-center"
                        style="background: conic-gradient(
                            
<?php
    $bagianJenis = [];
    $sudutJenis = 0;
    $indexJenis = 0;

    foreach ($komposisiJenisUsaha as $nama => $jumlah) {
        $persen = $totalAnalisisJenis > 0
            ? ($jumlah / $totalAnalisisJenis) * 100
            : 0;

        $akhir = $sudutJenis + $persen;

        $warna = $warnaGrafik[
            $indexJenis % count($warnaGrafik)
        ];

        $bagianJenis[] = $warna
            . ' ' . $sudutJenis . '% ' . $akhir . '%';

        $sudutJenis = $akhir;
        $indexJenis++;
    }

    echo $bagianJenis
        ? implode(', ', $bagianJenis)
        : '#DCE6E4 0% 100%';
?>

                        );">

                        <div class="w-12 h-12 rounded-full bg-white flex flex-col items-center justify-center">
                            <span class="text-lg font-bold text-[#263F42]">
                                <?php echo e($totalAnalisisJenis); ?>

                            </span>
                            <span class="text-[9px] text-gray-400">Total</span>
                        </div>

                    </div>

                    <div class="w-full mt-2 space-y-1">

                        <?php $__currentLoopData = $komposisiJenisUsaha; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nama => $jumlah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="flex items-center justify-between text-[10px]">

                                <div class="flex items-center gap-1.5 min-w-0">
                                    <span class="w-2 h-2 rounded-full shrink-0"
                                        style="background: <?php echo e($warnaGrafik[$loop->index % count($warnaGrafik)]); ?>">
                                    </span>

                                    <span class="truncate"><?php echo e($nama); ?></span>
                                </div>

                                <div class="flex items-center gap-2 shrink-0">
                                    <span class="font-semibold"><?php echo e($jumlah); ?></span>

                                    <span class="text-gray-400">
                                        <?php echo e($totalAnalisisJenis > 0 ? round(($jumlah / $totalAnalisisJenis) * 100) : 0); ?>%
                                    </span>
                                </div>

                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                </div>
            </div>


            


<?php
    $totalAnalisisTerminal = $kontrakPerTerminal->sum();

    $warnaTerminal = [
        'T1' => '#365F65',
        'T2' => '#8BA5A2',
    ];

    $bagianTerminal = [];
    $sudutTerminal = 0;

    foreach ($kontrakPerTerminal as $nama => $jumlah) {
        $persen = $totalAnalisisTerminal > 0
            ? ($jumlah / $totalAnalisisTerminal) * 100
            : 0;

        $akhir = $sudutTerminal + $persen;

        $warna = $warnaTerminal[$nama] ?? '#A8BDB9';

        $bagianTerminal[] = "{$warna} {$sudutTerminal}% {$akhir}%";

        $sudutTerminal = $akhir;
    }

    $gradientTerminal = count($bagianTerminal) > 0
        ? implode(', ', $bagianTerminal)
        : '#DCE6E4 0% 100%';
?>

<div class="px-2 py-2">

    <h3 class="text-[11px] font-bold text-center text-[#263F42]">
        Kontrak per Terminal
    </h3>

    <div class="flex flex-col items-center mt-2">

        
        <div
            class="relative w-20 h-20 rounded-full flex items-center justify-center"
            style="background: conic-gradient(<?php echo e($gradientTerminal); ?>);"
        >

            <div class="w-12 h-12 rounded-full bg-white flex flex-col items-center justify-center">

                <span class="text-lg font-bold text-[#263F42]">
                    <?php echo e($totalAnalisisTerminal); ?>

                </span>

                <span class="text-[9px] text-gray-400">
                    Total
                </span>

            </div>

        </div>

        
        <div class="w-full mt-2 space-y-1">

            <?php $__currentLoopData = $kontrakPerTerminal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nama => $jumlah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="flex items-center justify-between text-[10px]">

                    <div class="flex items-center gap-1.5">

                        <span
                            class="w-2 h-2 rounded-full"
                            style="background-color: <?php echo e($warnaTerminal[$nama] ?? '#A8BDB9'); ?>;"
                        ></span>

                        <span><?php echo e($nama); ?></span>

                    </div>

                    <div class="flex items-center gap-2">

                        <span class="font-semibold">
                            <?php echo e($jumlah); ?>

                        </span>

                        <span class="text-gray-400">
                            <?php echo e($totalAnalisisTerminal > 0
                                ? round(($jumlah / $totalAnalisisTerminal) * 100)
                                : 0); ?>%
                        </span>

                    </div>

                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>

</div>

        </div>
    </div>

</div>

    
    <div class="bg-white rounded-2xl border border-[#DCE6E4] p-5 shadow-sm">

        <div class="flex items-center gap-2 mb-4">
            <i class="fas fa-filter text-[#365F65]"></i>
            <h2 class="font-semibold text-[#263F42]">
                Filter Laporan
            </h2>
        </div>

        <form action="<?php echo e(route('laporan')); ?>" method="GET">

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3">

                
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-2">
                        Tahun
                    </label>

                    <select name="tahun"
                        class="w-full rounded-xl border-gray-200 text-sm focus:border-[#365F65] focus:ring-[#365F65]">
                        <?php for($i = $tahunSekarang - 5; $i <= $tahunSekarang + 1; $i++): ?>
                            <option value="<?php echo e($i); ?>" <?php if($tahun == $i): echo 'selected'; endif; ?>>
                                <?php echo e($i); ?>

                            </option>
                        <?php endfor; ?>
                    </select>
                </div>

                
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-2">
                        Jenis Usaha
                    </label>

                    <select name="jenis_usaha"
                        class="w-full rounded-xl border-gray-200 text-sm focus:border-[#365F65] focus:ring-[#365F65]">

                        <option value="">Semua Jenis</option>

                        <?php $__currentLoopData = ['F&B', 'Retail', 'Service', 'Lounge', 'Duty Free', 'UMKM']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($jenis); ?>" <?php if($jenisUsaha == $jenis): echo 'selected'; endif; ?>>
                                <?php echo e($jenis); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                </div>

                
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-2">
                        Terminal
                    </label>

                    <select name="terminal"
                        class="w-full rounded-xl border-gray-200 text-sm focus:border-[#365F65] focus:ring-[#365F65]">

                        <option value="">Semua Terminal</option>
                        <option value="T1" <?php if($terminal == 'T1'): echo 'selected'; endif; ?>>Terminal 1</option>
                        <option value="T2" <?php if($terminal == 'T2'): echo 'selected'; endif; ?>>Terminal 2</option>

                    </select>
                </div>

                
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-2">
                        Status Kontrak
                    </label>

                    <select name="status"
                        class="w-full rounded-xl border-gray-200 text-sm focus:border-[#365F65] focus:ring-[#365F65]">

                        <option value="">Semua Status</option>
                        <option value="Proses" <?php if($statusFilter == 'Proses'): echo 'selected'; endif; ?>>Proses</option>
                        <option value="Aktif" <?php if($statusFilter == 'Aktif'): echo 'selected'; endif; ?>>Aktif</option>
                        <option value="Nonaktif" <?php if($statusFilter == 'Nonaktif'): echo 'selected'; endif; ?>>Nonaktif</option>

                    </select>
                </div>

                
                
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-2">
                        Status Dokumen
                    </label>

                    <select name="dokumen"
                        class="w-full rounded-xl border-gray-200 text-sm focus:border-[#365F65] focus:ring-[#365F65]">

                        <option value="">Semua Dokumen</option>
                        <option value="Lengkap" <?php if($dokumenFilter == 'Lengkap'): echo 'selected'; endif; ?>>Lengkap</option>
                        <option value="Belum Lengkap" <?php if($dokumenFilter == 'Belum Lengkap'): echo 'selected'; endif; ?>>Belum Lengkap</option>

                    </select>
                </div>

            </div> 

            
            <div class="flex flex-wrap justify-end gap-2 mt-4">

                <a href="<?php echo e(route('laporan')); ?>"
                    class="px-4 py-2 rounded-xl border border-gray-200 text-sm font-medium text-gray-600 hover:bg-gray-50">
                    Reset
                </a>

                <button type="submit"
                    class="px-5 py-2 rounded-xl bg-[#365F65] text-white text-sm font-semibold hover:bg-[#294B50]">
                    <i class="fas fa-filter mr-1"></i>
                    Terapkan Filter
                </button>

            </div>

                    </form>
    </div>

    
<div class="bg-white rounded-2xl border border-[#DCE6E4] shadow-sm overflow-hidden mt-8">
        <div class="p-5 border-b border-[#DCE6E4] flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">

            <div>
                <h2 class="font-bold text-[#263F42]">
                    Daftar Laporan Kerja Sama
                </h2>
                <p class="text-xs text-gray-400 mt-1">
                    Menampilkan data kerja sama berdasarkan filter yang dipilih.
                </p>
            </div>

            <span class="text-sm font-semibold text-[#365F65]">
                <?php echo e($laporan->count()); ?> Data
            </span>

        </div>

        <div class="overflow-x-auto">

            <table class="w-full min-w-[1000px] text-sm">

                <thead class="bg-[#F3F6F5] text-gray-500">
                    <tr>
                        <th class="px-5 py-4 text-left font-semibold">No.</th>
                        <th class="px-5 py-4 text-left font-semibold">No. Kerja Sama</th>
                        <th class="px-5 py-4 text-left font-semibold">Mitra Usaha</th>
                        <th class="px-5 py-4 text-left font-semibold">Lokasi</th>
                        <th class="px-5 py-4 text-left font-semibold">Periode Kerja Sama</th>
                        <th class="px-5 py-4 text-center font-semibold">Status</th>
                        <th class="px-5 py-4 text-center font-semibold">Dokumen</th>
                        <th class="px-5 py-4 text-center font-semibold">Aksi</th>
                    </tr>
                </thead>

                <tbody class="divide-y divide-[#EDF1F0]">

                    <?php $__empty_1 = true; $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <?php
                            $ks = $item['kerja_sama'];
                            $lokasiData = $item['lokasi'];
                            $status = $item['status_laporan'];

                            $statusClass = match ($status) {
                                'Aktif' => 'bg-emerald-50 text-emerald-700',
                                'Nonaktif' => 'bg-gray-100 text-gray-600',
                                default => 'bg-amber-50 text-amber-700',
                            };
                        ?>

                        <tr class="hover:bg-[#F8FAF9]">

                            <td class="px-5 py-4 text-gray-500">
                                <?php echo e($index + 1); ?>

                            </td>

                            <td class="px-5 py-4">
                                <span class="font-semibold text-[#365F65]">
                                    <?php echo e($ks->nomor_kerja_sama ?? '-'); ?>

                                </span>
                            </td>

                            <td class="px-5 py-4">
                                <p class="font-semibold text-gray-700">
                                    <?php echo e($ks->mitra_usaha ?? '-'); ?>

                                </p>
                                <p class="text-xs text-gray-400 mt-1">
                                    <?php echo e($ks->brand ?? '-'); ?>

                                </p>
                            </td>

                            <td class="px-5 py-4">
                                <?php if($lokasiData): ?>
                                    <p class="font-medium text-gray-700">
                                        <?php echo e($lokasiData->terminal ?? '-'); ?>

                                    </p>
                                    <p class="text-xs text-gray-400 mt-1">
                                        <?php echo e($lokasiData->kode_tampilan ?? $lokasiData->kode_ruang ?? '-'); ?>

                                    </p>
                                <?php else: ?>
                                    <span class="text-gray-400">Belum ditentukan</span>
                                <?php endif; ?>
                            </td>

                            <td class="px-5 py-4 text-gray-600">
                                <p>
                                    <?php echo e($ks->tanggal_mulai
                                        ? \Carbon\Carbon::parse($ks->tanggal_mulai)->format('d/m/Y')
                                        : '-'); ?>

                                </p>
                                <p class="text-xs text-gray-400 mt-1">
                                    s.d.
                                    <?php echo e($ks->tanggal_berakhir
                                        ? \Carbon\Carbon::parse($ks->tanggal_berakhir)->format('d/m/Y')
                                        : '-'); ?>

                                </p>
                            </td>

                            <td class="px-5 py-4 text-center">
                                <span class="inline-flex px-3 py-1 rounded-full text-xs font-semibold <?php echo e($statusClass); ?>">
                                    <?php echo e($status); ?>

                                </span>
                            </td>

                            <td class="px-5 py-4 text-center">
                                <?php if($item['dokumen_lengkap']): ?>
                                    <span class="text-emerald-700 text-xs font-semibold">
                                        <i class="fas fa-check-circle mr-1"></i>
                                        Lengkap
                                    </span>
                                <?php else: ?>
                                    <span class="text-amber-600 text-xs font-semibold">
                                        <i class="fas fa-exclamation-circle mr-1"></i>
                                        Belum Lengkap
                                    </span>
                                <?php endif; ?>
                            </td>

                            <td class="px-5 py-4 text-center">
                                <a href="<?php echo e(route('laporan.detail', $ks->id)); ?>"
                                    class="inline-flex items-center gap-1 px-3 py-2 rounded-lg bg-[#E7EFED] text-[#365F65] text-xs font-semibold hover:bg-[#DCE6E4]">

                                    <i class="fas fa-eye"></i>
                                    Detail

                                </a>
                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>
                            <td colspan="8" class="px-5 py-12 text-center">

                                <div class="flex flex-col items-center">
                                    <i class="fas fa-folder-open text-3xl text-gray-300 mb-3"></i>

                                    <p class="font-semibold text-gray-500">
                                        Tidak ada data laporan
                                    </p>

                                    <p class="text-xs text-gray-400 mt-1">
                                        Coba ubah filter tahun atau kriteria pencarian.
                                    </p>
                                </div>

                            </td>
                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\AeroTrack\resources\views/laporan/index.blade.php ENDPATH**/ ?>