<?php $__env->startSection('page-title', 'Tambah Lokasi'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full max-w-none space-y-6">

    
    <div>
        <p class="text-sm text-[#8BA5A2]">Management / Lokasi</p>

        <h1 class="mt-1 text-2xl font-bold text-[#365F65]">
            Tambah Lokasi Baru
        </h1>

        <p class="mt-1 text-sm text-[#7A9290]">
            Daftarkan ruangan fisik yang tersedia di area bandara.
        </p>
    </div>

    
    <?php if($errors->any()): ?>
        <div class="rounded-xl border border-red-200 bg-red-50 p-4">
            <p class="mb-2 font-semibold text-red-700">
                Periksa kembali data yang kamu isi.
            </p>

            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="text-sm text-red-600"><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    
    <div class="w-full rounded-2xl border border-[#E2EBE9] bg-white p-5 sm:p-8 lg:p-10">

        <form
            method="POST"
            action="<?php echo e(route('lokasi.store')); ?>"
            class="space-y-6"
        >
            <?php echo csrf_field(); ?>

            <div>
                <h2 class="text-base font-bold text-[#365F65]">
                    Informasi Ruangan
                </h2>

                <p class="mt-1 text-xs text-[#8BA5A2]">
                    Kode lokasi dibuat otomatis oleh sistem.
                </p>
            </div>

            <div class="grid grid-cols-1 gap-x-6 gap-y-5 md:grid-cols-2">

                
                <div>
                    <label for="terminal"
                           class="mb-1.5 block text-sm font-semibold text-[#527D82]">
                        Terminal <span class="text-red-500">*</span>
                    </label>

                    <select
                        id="terminal"
                        name="terminal"
                        required
                        class="w-full rounded-xl border border-[#DCE6E4] bg-[#F8FAF9] px-4 py-3 text-sm text-[#365F65] outline-none focus:border-[#527D82] focus:ring-2 focus:ring-[#527D82]/10"
                    >
                        <option value="">Pilih terminal</option>
                        <option value="T1" <?php echo e(old('terminal') == 'T1' ? 'selected' : ''); ?>>
                            Terminal 1
                        </option>
                        <option value="T2" <?php echo e(old('terminal') == 'T2' ? 'selected' : ''); ?>>
                            Terminal 2
                        </option>
                    </select>

                    <?php $__errorArgs = ['terminal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div>
                    <label for="lantai"
                           class="mb-1.5 block text-sm font-semibold text-[#527D82]">
                        Lantai <span class="text-red-500">*</span>
                    </label>

                    <select
                        id="lantai"
                        name="lantai"
                        required
                        class="w-full rounded-xl border border-[#DCE6E4] bg-[#F8FAF9] px-4 py-3 text-sm text-[#365F65] outline-none focus:border-[#527D82] focus:ring-2 focus:ring-[#527D82]/10"
                    >
                        <option value="">Pilih lantai</option>

                        <?php $__currentLoopData = ['1', '2', '3', '4']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lantai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($lantai); ?>" <?php echo e(old('lantai') == $lantai ? 'selected' : ''); ?>>
                                Lantai <?php echo e($lantai); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <?php $__errorArgs = ['lantai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div>
                    <label for="jenis_ruangan"
                           class="mb-1.5 block text-sm font-semibold text-[#527D82]">
                        Jenis Ruangan <span class="text-red-500">*</span>
                    </label>

                    <select
                        id="jenis_ruangan"
                        name="jenis_ruangan"
                        required
                        class="w-full rounded-xl border border-[#DCE6E4] bg-[#F8FAF9] px-4 py-3 text-sm text-[#365F65] outline-none focus:border-[#527D82] focus:ring-2 focus:ring-[#527D82]/10"
                    >
                        <option value="">Pilih jenis ruangan</option>

                        <?php $__currentLoopData = [
                            'Store',
                            'Counter',
                            'Customer Service',
                            'Lounge',
                            'Antena',
                            'Gudang',
                            'Lainnya'
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($jenis); ?>" <?php echo e(old('jenis_ruangan') == $jenis ? 'selected' : ''); ?>>
                                <?php echo e($jenis); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <?php $__errorArgs = ['jenis_ruangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div>
                    <label for="nomor_ro"
                           class="mb-1.5 block text-sm font-semibold text-[#527D82]">
                        Nomor RO
                    </label>

                    <input
                        type="text"
                        id="nomor_ro"
                        name="nomor_ro"
                        value="<?php echo e(old('nomor_ro')); ?>"
                        placeholder="Masukkan nomor RO jika ada"
                        class="w-full rounded-xl border border-[#DCE6E4] bg-[#F8FAF9] px-4 py-3 text-sm text-[#365F65] outline-none focus:border-[#527D82] focus:ring-2 focus:ring-[#527D82]/10"
                    >

                    <?php $__errorArgs = ['nomor_ro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="md:col-span-2">
                    <label for="kode_preview"
                           class="mb-1.5 block text-sm font-semibold text-[#527D82]">
                        Kode Lokasi
                    </label>

                    <div class="rounded-xl border border-[#DCE6E4] bg-[#EAF1F0] px-4 py-4">
                        <p id="kode_preview"
                           class="break-words text-lg font-bold text-[#365F65]">
                            Pilih terminal dan lantai
                        </p>

                        <p class="mt-1 text-xs text-[#7A9290]">
                            Nomor ruang ditentukan oleh sistem ketika data disimpan.
                        </p>
                    </div>
                </div>

                
                <div class="md:col-span-2">
                    <label for="lokasi"
                           class="mb-1.5 block text-sm font-semibold text-[#527D82]">
                        Nama / Area Lokasi <span class="text-red-500">*</span>
                    </label>

                    <input
                        type="text"
                        id="lokasi"
                        name="lokasi"
                        value="<?php echo e(old('lokasi')); ?>"
                        required
                        maxlength="255"
                        placeholder="Contoh: Area Keberangkatan"
                        class="w-full rounded-xl border border-[#DCE6E4] bg-[#F8FAF9] px-4 py-3 text-sm text-[#365F65] outline-none focus:border-[#527D82] focus:ring-2 focus:ring-[#527D82]/10"
                    >

                    <?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div>
                    <label for="luas_area"
                           class="mb-1.5 block text-sm font-semibold text-[#527D82]">
                        Luas Area (m²)
                    </label>

                    <input
                        type="number"
                        id="luas_area"
                        name="luas_area"
                        value="<?php echo e(old('luas_area')); ?>"
                        min="0"
                        step="0.01"
                        placeholder="Contoh: 20"
                        class="w-full rounded-xl border border-[#DCE6E4] bg-[#F8FAF9] px-4 py-3 text-sm text-[#365F65] outline-none focus:border-[#527D82] focus:ring-2 focus:ring-[#527D82]/10"
                    >

                    <?php $__errorArgs = ['luas_area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div>
                    <label class="mb-1.5 block text-sm font-semibold text-[#527D82]">
                        Status Awal
                    </label>

                    <div class="flex items-center gap-2 rounded-xl border border-[#DCE6E4] bg-[#F8FAF9] px-4 py-3">
                        <span class="h-2.5 w-2.5 rounded-full bg-emerald-500"></span>
                        <span class="text-sm font-semibold text-[#365F65]">
                            Kosong
                        </span>
                    </div>

                    <p class="mt-1 text-xs text-[#8BA5A2]">
                        Berubah menjadi Terisi ketika dihubungkan dengan tenant.
                    </p>
                </div>

                
                <div class="md:col-span-2">
                    <label for="catatan"
                           class="mb-1.5 block text-sm font-semibold text-[#527D82]">
                        Keterangan
                    </label>

                    <textarea
                        id="catatan"
                        name="catatan"
                        rows="4"
                        placeholder="Tambahkan informasi lokasi jika diperlukan..."
                        class="w-full resize-y rounded-xl border border-[#DCE6E4] bg-[#F8FAF9] px-4 py-3 text-sm text-[#365F65] outline-none focus:border-[#527D82] focus:ring-2 focus:ring-[#527D82]/10"
                    ><?php echo e(old('catatan')); ?></textarea>

                    <?php $__errorArgs = ['catatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            
            <div class="flex flex-col-reverse gap-3 border-t border-[#E2EBE9] pt-5 sm:flex-row sm:justify-end">

                <a
                    href="<?php echo e(route('lokasi.index')); ?>"
                    class="inline-flex items-center justify-center rounded-xl border border-[#DCE6E4] bg-white px-5 py-3 text-sm font-semibold text-[#527D82] transition hover:bg-[#F5F8F7]"
                >
                    Batal
                </a>

                <button
                    type="submit"
                    class="inline-flex items-center justify-center rounded-xl bg-[#365F65] px-5 py-3 text-sm font-semibold text-white transition hover:bg-[#294F55] focus:outline-none focus:ring-2 focus:ring-[#527D82] focus:ring-offset-2"
                >
                    Simpan Lokasi
                </button>
            </div>
        </form>
    </div>
</div>


<script>
    document.addEventListener('DOMContentLoaded', function () {
        const terminal = document.getElementById('terminal');
        const lantai = document.getElementById('lantai');
        const preview = document.getElementById('kode_preview');

        function updateKodePreview() {
            if (terminal.value && lantai.value) {
                preview.textContent = `${terminal.value}-L${lantai.value}-XXX`;
            } else {
                preview.textContent = 'Pilih terminal dan lantai';
            }
        }

        terminal.addEventListener('change', updateKodePreview);
        lantai.addEventListener('change', updateKodePreview);

        updateKodePreview();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\AeroTrack\resources\views/lokasi/create.blade.php ENDPATH**/ ?>