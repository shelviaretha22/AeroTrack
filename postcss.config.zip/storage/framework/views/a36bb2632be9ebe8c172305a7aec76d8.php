<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'segments' => [],   // [['label' => 'Terminal 1', 'value' => 12, 'color' => '#527D82'], ...]
    'size' => 'h-44 w-44',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'segments' => [],   // [['label' => 'Terminal 1', 'value' => 12, 'color' => '#527D82'], ...]
    'size' => 'h-44 w-44',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $total = (float) collect($segments)->sum('value');
    $akumulasi = 0;
    $deskripsi = collect($segments)->map(fn ($s) => $s['label'] . ' ' . $s['value'])->implode(', ');
?>

<div class="relative shrink-0 <?php echo e($size); ?>">
    <svg viewBox="0 0 42 42" class="h-full w-full -rotate-90" role="img" aria-label="Diagram pie: <?php echo e($deskripsi); ?>">
        
        <circle cx="21" cy="21" r="7.9577" pathLength="100" fill="none" stroke="#E7EFEC" stroke-width="15.9155"/>
        <?php if($total > 0): ?>
            <?php $__currentLoopData = $segments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $persen = ($s['value'] / $total) * 100; ?>
                <?php if($persen > 0): ?>
                    <circle cx="21" cy="21" r="7.9577" pathLength="100" fill="none"
                            stroke="<?php echo e($s['color']); ?>" stroke-width="15.9155"
                            stroke-dasharray="<?php echo e(round($persen, 3)); ?> <?php echo e(round(100 - $persen, 3)); ?>"
                            stroke-dashoffset="<?php echo e(round(-$akumulasi, 3)); ?>">
                        <title><?php echo e($s['label']); ?>: <?php echo e($s['value']); ?> (<?php echo e(round($persen, 1)); ?>%)</title>
                    </circle>
                    <?php $akumulasi += $persen; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </svg>
</div>
<?php /**PATH C:\xampp\htdocs\AeroTrack\resources\views/components/pie.blade.php ENDPATH**/ ?>