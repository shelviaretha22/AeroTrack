<?php $__env->startSection('page-title', 'Profile & Pengaturan'); ?>

<?php $__env->startSection('content'); ?>
<div class="profile-page">

    <div class="profile-heading">
        <div>
            <h1>Profile & Pengaturan</h1>
            <p>Kelola informasi akun, keamanan, dan preferensi AeroTrack.</p>
        </div>
        <span class="profile-role">
            <span class="status-dot"></span>
            <?php echo e(auth()->user()->peran); ?>

        </span>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-error">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-error">
            <strong>Periksa kembali data yang dimasukkan.</strong>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    
    <section class="profile-card profile-overview">
        <div class="avatar-wrapper">
            <?php if(auth()->user()->avatar_path): ?>
                <img
                    src="<?php echo e(asset('storage/' . auth()->user()->avatar_path)); ?>"
                    alt="Foto profil"
                    class="profile-avatar"
                >
            <?php else: ?>
                <div class="profile-avatar avatar-placeholder">
                    <?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?>

                </div>
            <?php endif; ?>
        </div>

        <div class="profile-overview-info">
            <h2><?php echo e(auth()->user()->name); ?></h2>
            <p><?php echo e(auth()->user()->email); ?></p>
            <span class="profile-role-small"><?php echo e(auth()->user()->peran); ?></span>
            <p class="mt-2 text-xs text-[#8BA5A2]">
                Bergabung <?php echo e(auth()->user()->created_at?->locale('id')->isoFormat('D MMMM YYYY') ?? '-'); ?>

                <?php if(auth()->user()->previous_login_at): ?>
                    · Login sebelumnya <?php echo e(auth()->user()->previous_login_at->locale('id')->diffForHumans()); ?>

                <?php endif; ?>
            </p>
        </div>

        <div class="profile-overview-action">
            <button
                type="button"
                class="btn-secondary"
                onclick="document.getElementById('photo-input').click()"
            >
                <span>↑</span> Ganti Foto
            </button>
        </div>

        <form
            id="photo-form"
            action="<?php echo e(route('profile.photo.update')); ?>"
            method="POST"
            enctype="multipart/form-data"
            class="hidden-form"
        >
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>

            <input
                type="file"
                name="avatar"
                id="photo-input"
                accept="image/jpeg,image/png,image/webp"
                onchange="document.getElementById('photo-form').submit()"
            >
        </form>
    </section>

    
    <?php
        $maksHarian = max(1, (int) $grafikHarian->max('jumlah'));
        $totalKomponen = max(1, (int) $perKomponen->sum());
        $warnaKomponen = ['Kontrak Fisik' => '#527D82', 'Kontrak Sistem' => '#6C8EBF', 'Aktivasi' => '#D6A14D'];
    ?>
    <section class="profile-card">
        <div class="section-heading">
            <div class="section-icon">▥</div>
            <div>
                <h2>Ringkasan Aktivitas</h2>
                <p>Perubahan yang Anda lakukan di menu Aktivasi.</p>
            </div>
        </div>

        <div class="grid grid-cols-1 gap-4 lg:grid-cols-3">

            <div class="grid grid-cols-3 gap-3 lg:grid-cols-1">
                <?php $__currentLoopData = [
                    ['Total aktivitas', $statistik['total'], 'semua waktu'],
                    ['30 hari terakhir', $statistik['tigaPuluhHari'], 'perubahan dicatat'],
                    ['Kerja sama ditangani', $statistik['kerjaSama'], 'kerja sama berbeda'],
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $angka, $ket]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="rounded-xl border border-[#E2EBE9] bg-[#F8FAF9] p-4">
                        <p class="text-xs font-medium text-[#7A9290]"><?php echo e($label); ?></p>
                        <p class="mt-1 text-2xl font-bold text-[#365F65]"><?php echo e($angka); ?></p>
                        <p class="text-[11px] text-[#8BA5A2]"><?php echo e($ket); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="rounded-xl border border-[#E2EBE9] p-4 lg:col-span-2">
                <div class="flex items-center justify-between gap-3">
                    <h3 class="text-sm font-bold text-[#365F65]">14 hari terakhir</h3>
                    <span class="text-xs text-[#8BA5A2]">puncak <?php echo e($maksHarian); ?> per hari</span>
                </div>

                <div class="mt-4 flex h-32 items-end gap-1.5" role="img"
                     aria-label="Grafik aktivitas harian, total <?php echo e($grafikHarian->sum('jumlah')); ?> dalam 14 hari">
                    <?php $__currentLoopData = $grafikHarian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hari): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="group flex h-full flex-1 flex-col items-center justify-end gap-1.5"
                             title="<?php echo e($hari['tanggal']->locale('id')->isoFormat('D MMM')); ?>: <?php echo e($hari['jumlah']); ?> aktivitas">
                            <div class="w-full rounded-t-md <?php echo e($hari['jumlah'] > 0 ? 'bg-[#365F65] group-hover:bg-[#4F8189]' : 'bg-[#E7EFEC]'); ?>"
                                 style="height: <?php echo e($hari['jumlah'] > 0 ? max(8, ($hari['jumlah'] / $maksHarian) * 100) : 4); ?>%"></div>
                            <span class="text-[9px] text-[#8BA5A2] <?php echo e($loop->index % 2 === 0 ? '' : 'hidden sm:block'); ?>"><?php echo e($hari['tanggal']->format('d')); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <?php if($perKomponen->isNotEmpty()): ?>
                    <div class="mt-5 border-t border-[#E2EBE9] pt-4">
                        <div class="flex h-2.5 overflow-hidden rounded-full bg-[#E7EFEC]" role="img" aria-label="Komposisi aktivitas per komponen">
                            <?php $__currentLoopData = $perKomponen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komponen => $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div style="width: <?php echo e(($n / $totalKomponen) * 100); ?>%; background: <?php echo e($warnaKomponen[$komponen] ?? '#8BA5A2'); ?>"
                                     title="<?php echo e($komponen); ?>: <?php echo e($n); ?>"></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-[#7A9290]">
                            <?php $__currentLoopData = $perKomponen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komponen => $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="inline-flex items-center gap-1.5">
                                    <span class="h-2.5 w-2.5 rounded-full" style="background: <?php echo e($warnaKomponen[$komponen] ?? '#8BA5A2'); ?>"></span>
                                    <?php echo e($komponen); ?> <strong class="text-[#365F65]"><?php echo e($n); ?></strong>
                                </span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    
    <section class="profile-card">
        <div class="section-heading">
            <div class="section-icon">◷</div>
            <div>
                <h2>Aktivitas Terakhir</h2>
                <p>Delapan perubahan terbaru yang Anda lakukan.</p>
            </div>
        </div>

        <?php $__empty_1 = true; $__currentLoopData = $aktivitasTerakhir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $warnaTitik = ['Kontrak Fisik' => 'bg-[#527D82]', 'Kontrak Sistem' => 'bg-[#6C8EBF]', 'Aktivasi' => 'bg-[#D6A14D]'][$r->komponen] ?? 'bg-[#8BA5A2]';
                $ks = $r->kerjaSama;
            ?>
            <div class="relative flex gap-4 pb-5 last:pb-0">
                <?php if (! ($loop->last)): ?>
                    <span class="absolute left-[5px] top-4 h-full w-px bg-[#E2EBE9]" aria-hidden="true"></span>
                <?php endif; ?>
                <span class="relative z-10 mt-1.5 h-[11px] w-[11px] shrink-0 rounded-full ring-4 ring-white <?php echo e($warnaTitik); ?>"></span>

                <div class="min-w-0 flex-1">
                    <p class="text-sm text-[#365F65]"><?php echo e($r->keterangan); ?></p>
                    <div class="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-[#8BA5A2]">
                        <span class="rounded-full bg-[#F3F6F5] px-2 py-0.5 font-medium text-[#527D82]"><?php echo e($r->komponen); ?></span>
                        <?php if($ks): ?>
                            <a href="<?php echo e(route('aktivasi.show', $ks->id)); ?>" class="font-semibold text-[#527D82] hover:underline">
                                <?php echo e($ks->mitra_usaha ?: 'KS-' . str_pad($ks->id, 4, '0', STR_PAD_LEFT)); ?>

                            </a>
                        <?php endif; ?>
                        <span title="<?php echo e($r->created_at->format('d M Y H:i')); ?>"><?php echo e($r->created_at->locale('id')->diffForHumans()); ?></span>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="rounded-xl bg-[#F8FAF9] px-4 py-8 text-center text-sm text-[#7A9290]">
                Belum ada aktivitas. Perubahan yang Anda catat di menu Aktivasi akan muncul di sini.
            </p>
        <?php endif; ?>
    </section>

    
    <section class="profile-card">
        <div class="section-heading">
            <div class="section-icon">♙</div>
            <div>
                <h2>Informasi Akun</h2>
                <p>Perbarui informasi dasar akun Anda.</p>
            </div>
        </div>

        <form action="<?php echo e(route('profile.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>

            <div class="form-grid">
                <div class="form-group">
                    <label for="name">Nama Lengkap</label>
                    <input
                        type="text"
                        id="name"
                        name="name"
                        value="<?php echo e(old('name', auth()->user()->name)); ?>"
                        placeholder="Masukkan nama lengkap"
                        required
                        maxlength="255"
                    >
                </div>

                <div class="form-group">
                    <label for="email">Alamat Email</label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        value="<?php echo e(old('email', auth()->user()->email)); ?>"
                        placeholder="nama@email.com"
                        required
                        maxlength="255"
                    >
                </div>

                <div class="form-group">
                    <label for="role">Role Pengguna</label>
                    <input
                        type="text"
                        id="role"
                        value="<?php echo e(auth()->user()->peran); ?>"
                        disabled
                    >
                    <small>Role mengikuti hak akses akun.</small>
                </div>

                <div class="form-group">
                    <label for="created_at">Tanggal Bergabung</label>
                    <input
                        type="text"
                        id="created_at"
                        value="<?php echo e(auth()->user()->created_at?->format('d F Y') ?? '-'); ?>"
                        disabled
                    >
                </div>
            </div>

            <div class="form-footer">
                <button type="submit" class="btn-primary">
                    Simpan Informasi
                </button>
            </div>
        </form>
    </section>

    
    <section class="profile-card">
        <div class="section-heading">
            <div class="section-icon">♧</div>
            <div>
                <h2>Keamanan Akun</h2>
                <p>Gunakan password yang kuat untuk menjaga akun Anda.</p>
            </div>
        </div>

        <form action="<?php echo e(route('profile.password.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-grid">
                <div class="form-group full-width">
                    <label for="current_password">Password Saat Ini</label>
                    <input
                        type="password"
                        id="current_password"
                        name="current_password"
                        placeholder="Masukkan password saat ini"
                        autocomplete="current-password"
                        required
                    >
                </div>

                <div class="form-group"
                     x-data="{
                        pw: '',
                        get skor() {
                            if (!this.pw) return 0;
                            let s = 0;
                            if (this.pw.length >= 8) s++;
                            if (this.pw.length >= 12) s++;
                            if (/[a-z]/.test(this.pw) && /[A-Z]/.test(this.pw)) s++;
                            if (/[0-9]/.test(this.pw)) s++;
                            if (/[^A-Za-z0-9]/.test(this.pw)) s++;
                            return s <= 2 ? 1 : (s === 3 ? 2 : (s === 4 ? 3 : 4));
                        },
                        get label() { return ['', 'Lemah', 'Cukup', 'Kuat', 'Sangat kuat'][this.skor]; },
                        get warna() { return ['', '#D14B4B', '#D6A14D', '#31966A', '#365F65'][this.skor]; }
                     }">
                    <label for="password">Password Baru</label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        x-model="pw"
                        placeholder="Minimal 8 karakter"
                        autocomplete="new-password"
                        minlength="8"
                        required
                    >

                    <div class="mt-2" x-show="pw" style="display:none;">
                        <div class="flex gap-1" aria-hidden="true">
                            <template x-for="i in 4" :key="i">
                                <span class="h-1.5 flex-1 rounded-full transition-colors"
                                      :style="'background:' + (i <= skor ? warna : '#E7EFEC')"></span>
                            </template>
                        </div>
                        <p class="mt-1.5 text-xs" aria-live="polite">
                            Kekuatan: <strong :style="'color:' + warna" x-text="label"></strong>
                            <span class="text-[#8BA5A2]"> · campur huruf besar-kecil, angka, dan simbol</span>
                        </p>
                    </div>
                </div>

                <div class="form-group">
                    <label for="password_confirmation">Konfirmasi Password</label>
                    <input
                        type="password"
                        id="password_confirmation"
                        name="password_confirmation"
                        placeholder="Ulangi password baru"
                        autocomplete="new-password"
                        minlength="8"
                        required
                    >
                </div>
            </div>

            <div class="form-footer">
                <button type="submit" class="btn-primary">
                    Perbarui Password
                </button>
            </div>
        </form>
    </section>

    
    <section class="profile-card">
        <div class="section-heading">
            <div class="section-icon">▣</div>
            <div>
                <h2>Perangkat &amp; Sesi Aktif</h2>
                <p>Tempat akun Anda sedang masuk. Keluarkan yang tidak Anda kenali.</p>
            </div>
        </div>

        <?php $user = auth()->user(); ?>

        <div class="mb-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div class="rounded-xl border border-[#E2EBE9] bg-[#F8FAF9] p-4">
                <p class="text-xs font-medium text-[#7A9290]">Login sesi ini</p>
                <p class="mt-1 text-sm font-bold text-[#365F65]"><?php echo e($user->last_login_at?->locale('id')->isoFormat('D MMM YYYY, HH:mm') ?? '-'); ?></p>
                <p class="text-xs text-[#8BA5A2]">IP <?php echo e($user->last_login_ip ?: '-'); ?></p>
            </div>
            <div class="rounded-xl border border-[#E2EBE9] bg-[#F8FAF9] p-4">
                <p class="text-xs font-medium text-[#7A9290]">Login sebelumnya</p>
                <p class="mt-1 text-sm font-bold text-[#365F65]"><?php echo e($user->previous_login_at?->locale('id')->isoFormat('D MMM YYYY, HH:mm') ?? 'Belum ada'); ?></p>
                <p class="text-xs text-[#8BA5A2]">IP <?php echo e($user->previous_login_ip ?: '-'); ?></p>
            </div>
        </div>

        <?php if($sesiTersedia): ?>
            <ul class="divide-y divide-[#E2EBE9] rounded-xl border border-[#E2EBE9]">
                <?php $__empty_1 = true; $__currentLoopData = $sesi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="flex items-center gap-4 px-4 py-3.5">
                        <span class="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#EAF2F1] text-[#365F65]" aria-hidden="true">
                            <?php if($s['agen']['seluler']): ?>
                                <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/></svg>
                            <?php else: ?>
                                <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg>
                            <?php endif; ?>
                        </span>

                        <div class="min-w-0 flex-1">
                            <p class="text-sm font-semibold text-[#365F65]">
                                <?php echo e($s['agen']['browser']); ?> di <?php echo e($s['agen']['os']); ?>

                                <?php if($s['ini']): ?>
                                    <span class="ml-1.5 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-700">Perangkat ini</span>
                                <?php endif; ?>
                            </p>
                            <p class="text-xs text-[#8BA5A2]">
                                IP <?php echo e($s['ip'] ?: '-'); ?> · aktif <?php echo e($s['aktif']->locale('id')->diffForHumans()); ?>

                            </p>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="px-4 py-6 text-center text-sm text-[#7A9290]">Tidak ada sesi tercatat.</li>
                <?php endif; ?>
            </ul>

            <?php if($sesi->where('ini', false)->count() > 0): ?>
                <form action="<?php echo e(route('profile.sesi.keluar-lainnya')); ?>" method="POST"
                      class="mt-5 flex flex-col gap-3 sm:flex-row sm:items-end"
                      onsubmit="return confirm('Keluarkan akun dari semua perangkat lain?');">
                    <?php echo csrf_field(); ?>
                    <div class="form-group flex-1">
                        <label for="password_sesi">Password saat ini</label>
                        <input type="password" id="password_sesi" name="password_sesi"
                               placeholder="Untuk konfirmasi" autocomplete="current-password" required>
                    </div>
                    <button type="submit" class="btn-secondary" style="color:#a33232;border-color:#f0cece;">
                        Keluarkan dari perangkat lain
                    </button>
                </form>
            <?php endif; ?>
        <?php else: ?>
            <p class="rounded-xl bg-[#F8FAF9] px-4 py-6 text-center text-sm text-[#7A9290]">
                Daftar sesi tersedia bila sesi disimpan di database (<code>SESSION_DRIVER=database</code>).
            </p>
        <?php endif; ?>
    </section>

    
    <section class="profile-card" id="preferensi">
        <div class="section-heading">
            <div class="section-icon">⚙</div>
            <div>
                <h2>Preferensi</h2>
                <p>Atur pengalaman penggunaan AeroTrack.</p>
            </div>
        </div>

        <form action="<?php echo e(route('profile.preferences.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>

            <div class="preference-row" style="align-items: flex-start;">
                <div class="preference-description">
                    <h3>Tampilan Aplikasi</h3>
                    <p>Pilih tema terang atau gelap. Pilihan langsung tersimpan dan berlaku di semua halaman.</p>
                </div>

                <?php $tema = old('theme_preference', auth()->user()->theme_preference ?? 'light'); ?>
                <div class="grid w-full max-w-[360px] grid-cols-2 gap-3">
                    <?php $__currentLoopData = [['light', 'Terang', 'Cerah, nyaman di ruangan terang'], ['dark', 'Gelap', 'Redup, nyaman di malam hari']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$nilai, $nama, $ket]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="cursor-pointer">
                            <input type="radio" name="theme_preference" value="<?php echo e($nilai); ?>" class="peer sr-only"
                                   <?php if($tema === $nilai): echo 'checked'; endif; ?>
                                   onchange="pilihTema(this)">
                            <div class="rounded-2xl border border-[#DCE6E4] bg-white p-2.5 transition peer-checked:border-[#527D82] peer-checked:ring-2 peer-checked:ring-[#527D82]/30 peer-focus-visible:ring-2">
                                <?php if($nilai === 'light'): ?>
                            <div class="flex h-16 w-full overflow-hidden rounded-lg border border-black/10" style="background: rgb(243,246,245)">
                                <div class="w-5" style="background: rgb(54,95,101)"></div>
                                <div class="flex-1 space-y-1.5 p-2">
                                    <div class="h-1.5 w-10 rounded" style="background: rgb(54,95,101)"></div>
                                    <div class="h-4 rounded" style="background: rgb(255,255,255)"></div>
                                    <div class="h-1.5 w-7 rounded" style="background: rgb(184,206,202)"></div>
                                </div>
                            </div>
                                <?php else: ?>
                            <div class="flex h-16 w-full overflow-hidden rounded-lg border border-black/10" style="background: rgb(14,26,28)">
                                <div class="w-5" style="background: rgb(17,35,38)"></div>
                                <div class="flex-1 space-y-1.5 p-2">
                                    <div class="h-1.5 w-10 rounded" style="background: rgb(143,195,189)"></div>
                                    <div class="h-4 rounded" style="background: rgb(22,36,39)"></div>
                                    <div class="h-1.5 w-7 rounded" style="background: rgb(60,90,95)"></div>
                                </div>
                            </div>
                                <?php endif; ?>
                                <p class="mt-2 text-sm font-bold text-[#365F65]"><?php echo e($nama); ?></p>
                                <p class="text-[11px] leading-snug text-[#8BA5A2]"><?php echo e($ket); ?></p>
                            </div>
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="preference-row">
                <div class="preference-description">
                    <h3>Ringkasan Email Harian</h3>
                    <p>Kirim email setiap pagi (07.00) berisi hal yang perlu tindakan dan belum dibaca. Email hanya dikirim bila ada isinya.</p>
                </div>

                <label class="switch">
                    <input
                        type="checkbox"
                        name="email_notifications"
                        value="1"
                        <?php if(old('email_notifications', auth()->user()->email_notifications ?? true)): echo 'checked'; endif; ?>
                    >
                    <span class="slider"></span>
                </label>
            </div>

            <div class="mt-6">
                <h3 class="text-sm font-bold text-[#365F65]">Jenis notifikasi yang ingin diterima</h3>
                <p class="mt-1 text-xs text-[#8BA5A2]">Berlaku untuk lonceng di header, halaman Notifikasi, dan email ringkasan.</p>

                <?php $__currentLoopData = ['tindakan' => 'Perlu tindakan', 'info' => 'Informasi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori => $judulKategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="mb-1 mt-5 text-[11px] font-bold uppercase tracking-wide text-[#8BA5A2]"><?php echo e($judulKategori); ?></p>

                    <?php $__currentLoopData = $jenisNotifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kode => $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($info['kategori'] !== $kategori) continue; ?>
                        <div class="preference-row">
                            <div class="preference-description">
                                <h3><?php echo e($info['label']); ?></h3>
                                <p><?php echo e($info['deskripsi']); ?></p>
                            </div>

                            <label class="switch">
                                <input
                                    type="checkbox"
                                    name="notif[<?php echo e($kode); ?>]"
                                    value="1"
                                    <?php if($preferensiNotifikasi[$kode] ?? true): echo 'checked'; endif; ?>
                                >
                                <span class="slider"></span>
                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="form-footer">
                <button type="submit" class="btn-primary">
                    Simpan Preferensi
                </button>
            </div>
        </form>
    </section>

    <section class="profile-card system-info">
        <div class="system-info-icon">i</div>
        <div>
            <h3>Akun AeroTrack</h3>
            <p>
                Informasi profil digunakan untuk mengidentifikasi pengguna
                dalam sistem monitoring persewaan tenant bandara.
            </p>
        </div>
        <span class="system-version">AeroTrack</span>
    </section>

</div>

<script>
    function pilihTema(el) {
        document.documentElement.dataset.theme = el.value;

        fetch("<?php echo e(route('profile.theme.update')); ?>", {
            method: 'PATCH',
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                'Content-Type': 'application/json',
                'Accept': 'application/json',
            },
            body: JSON.stringify({ theme_preference: el.value }),
        }).catch(() => {});
    }
</script>

<style>
    .profile-page {
        --profile-green: #365F65;
        --profile-green-dark: #294F55;
        --profile-bg: #f3f6f5;
        --profile-border: #E2EBE9;
        --profile-text: #365F65;
        --profile-muted: #7A9290;
        color: var(--profile-text);
        width: 100%;
        max-width: 1200px;
        margin: 0 auto;
        padding-bottom: 32px;
    }

    .profile-page * {
        box-sizing: border-box;
    }

    .profile-heading {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 16px;
        margin-bottom: 24px;
    }

    .profile-heading h1 {
        margin: 0 0 8px;
        font-size: clamp(22px, 3vw, 28px);
        font-weight: 750;
        letter-spacing: -0.7px;
    }

    .profile-heading p,
    .section-heading p {
        margin: 0;
        color: var(--profile-muted);
        font-size: 13px;
        line-height: 1.7;
    }

    .profile-role,
    .profile-role-small {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 8px 12px;
        border-radius: 999px;
        background: #EAF2F1;
        color: var(--profile-green);
        font-size: 12px;
        font-weight: 700;
        white-space: nowrap;
    }

    .status-dot {
        width: 7px;
        height: 7px;
        border-radius: 50%;
        background: #4F8189;
    }

    .profile-card {
        padding: 24px;
        margin-bottom: 20px;
        border: 1px solid var(--profile-border);
        border-radius: 16px;
        background: #fff;
        box-shadow: 0 3px 12px rgba(54, 95, 101, 0.04);
    }

    .profile-overview {
        display: flex;
        align-items: center;
        gap: 20px;
    }

    .avatar-wrapper {
        flex-shrink: 0;
    }

    .profile-avatar {
        display: flex;
        width: 76px;
        height: 76px;
        border-radius: 50%;
        object-fit: cover;
        border: 3px solid #DCE9E7;
    }

    .avatar-placeholder {
        justify-content: center;
        align-items: center;
        background: #DCE9E7;
        color: var(--profile-green);
        font-size: 30px;
        font-weight: 750;
    }

    .profile-overview-info {
        flex: 1;
        min-width: 0;
    }

    .profile-overview-info h2 {
        margin: 0 0 6px;
        font-size: 19px;
        font-weight: 750;
        overflow-wrap: anywhere;
    }

    .profile-overview-info p {
        margin: 0 0 10px;
        color: var(--profile-muted);
        font-size: 13px;
        overflow-wrap: anywhere;
    }

    .profile-role-small {
        padding: 5px 10px;
        font-size: 11px;
    }

    .btn-primary,
    .btn-secondary {
        display: inline-flex;
        justify-content: center;
        align-items: center;
        gap: 8px;
        min-height: 42px;
        padding: 11px 18px;
        border-radius: 9px;
        font: inherit;
        font-size: 13px;
        font-weight: 650;
        cursor: pointer;
        transition: background 0.2s, border-color 0.2s;
    }

    .btn-primary {
        border: 1px solid var(--profile-green);
        background: var(--profile-green);
        color: white;
    }

    .btn-primary:hover {
        background: var(--profile-green-dark);
    }

    .btn-secondary {
        border: 1px solid #DCE6E4;
        background: #fff;
        color: var(--profile-green);
    }

    .btn-secondary:hover {
        background: #F3F6F5;
    }

    .section-heading {
        display: flex;
        align-items: center;
        gap: 13px;
        margin-bottom: 25px;
    }

    .section-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        width: 42px;
        height: 42px;
        border-radius: 12px;
        background: #EAF2F1;
        color: var(--profile-green);
        font-size: 22px;
    }

    .section-heading h2 {
        margin: 0 0 5px;
        font-size: 16px;
        font-weight: 750;
    }

    .form-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 20px;
    }

    .form-group {
        display: flex;
        flex-direction: column;
        min-width: 0;
        gap: 8px;
    }

    .form-group label {
        color: #527D82;
        font-size: 12px;
        font-weight: 700;
    }

    .form-group input,
    .preference-row select {
        width: 100%;
        min-width: 0;
        min-height: 44px;
        padding: 11px 13px;
        border: 1px solid #DCE6E4;
        border-radius: 9px;
        background: #fff;
        color: #365F65;
        font: inherit;
        font-size: 13px;
        outline: none;
        transition: border-color 0.2s, box-shadow 0.2s;
    }

    .form-group input:focus,
    .preference-row select:focus {
        border-color: var(--profile-green);
        box-shadow: 0 0 0 3px rgba(82, 125, 130, 0.15);
    }

    .form-group input:disabled {
        background: #F3F6F5;
        color: #7A9290;
        cursor: not-allowed;
    }

    .form-group small {
        color: var(--profile-muted);
        font-size: 11px;
    }

    .full-width {
        grid-column: 1 / -1;
    }

    .form-footer {
        display: flex;
        justify-content: flex-end;
        margin-top: 24px;
        padding-top: 20px;
        border-top: 1px solid #E2EBE9;
    }

    .preference-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 20px;
        padding: 17px 0;
        border-bottom: 1px solid #E2EBE9;
    }

    .preference-row:first-of-type {
        padding-top: 0;
    }

    .preference-row select {
        width: 150px;
    }

    .preference-description h3 {
        margin: 0 0 6px;
        font-size: 13px;
        font-weight: 700;
    }

    .preference-description p {
        margin: 0;
        color: var(--profile-muted);
        font-size: 12px;
        line-height: 1.6;
    }

    .switch {
        position: relative;
        display: inline-flex;
        width: 44px;
        height: 25px;
        flex-shrink: 0;
    }

    .switch input {
        width: 0;
        height: 0;
        opacity: 0;
    }

    .slider {
        position: absolute;
        inset: 0;
        border-radius: 99px;
        background: #C9D6D3;
        cursor: pointer;
        transition: background 0.2s;
    }

    .slider::before {
        content: "";
        position: absolute;
        width: 19px;
        height: 19px;
        top: 3px;
        left: 3px;
        border-radius: 50%;
        background: #fff;
        box-shadow: 0 1px 3px #0002;
        transition: transform 0.2s;
    }

    .switch input:checked + .slider {
        background: var(--profile-green);
    }

    .switch input:checked + .slider::before {
        transform: translateX(19px);
    }

    .switch input:focus-visible + .slider {
        outline: 3px solid #B6C7C4;
        outline-offset: 2px;
    }

    .system-info {
        display: flex;
        align-items: flex-start;
        gap: 14px;
        background: #F8FAF9;
    }

    .system-info-icon {
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        width: 30px;
        height: 30px;
        border: 1px solid #DCE6E4;
        border-radius: 50%;
        color: var(--profile-green);
        font-weight: 750;
    }

    .system-info h3 {
        margin: 0 0 6px;
        font-size: 13px;
    }

    .system-info p {
        margin: 0;
        color: var(--profile-muted);
        font-size: 12px;
        line-height: 1.7;
    }

    .system-version {
        margin-left: auto;
        color: var(--profile-muted);
        font-size: 11px;
        white-space: nowrap;
    }

    .alert {
        padding: 14px 16px;
        margin-bottom: 18px;
        border-radius: 10px;
        font-size: 13px;
        line-height: 1.7;
    }

    .alert ul {
        margin: 8px 0 0;
        padding-left: 20px;
    }

    .alert-success {
        border: 1px solid #c7e5d1;
        background: #eef9f1;
        color: #226c40;
    }

    .alert-error {
        border: 1px solid #f0cece;
        background: #fff2f2;
        color: #a33232;
    }

    .hidden-form {
        display: none;
    }

    @media (max-width: 640px) {
        .profile-heading {
            align-items: flex-start;
            flex-direction: column;
        }

        .profile-card {
            padding: 18px;
            border-radius: 13px;
        }

        .profile-overview {
            flex-wrap: wrap;
            gap: 14px;
        }

        .profile-avatar {
            width: 62px;
            height: 62px;
        }

        .profile-overview-info {
            flex-basis: calc(100% - 80px);
        }

        .profile-overview-action {
            width: 100%;
        }

        .profile-overview-action button {
            width: 100%;
        }

        .form-grid {
            grid-template-columns: minmax(0, 1fr);
            gap: 17px;
        }

        .full-width {
            grid-column: auto;
        }

        .preference-row {
            align-items: flex-start;
            gap: 12px;
        }

        .preference-row select {
            width: 115px;
        }

        .form-footer .btn-primary {
            width: 100%;
        }

        .system-version {
            display: none;
        }
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\AeroTrack\resources\views/profile/index.blade.php ENDPATH**/ ?>