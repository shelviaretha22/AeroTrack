<?php $__env->startSection('page-title', 'Pendapatan'); ?>

<?php $__env->startSection('content'); ?>

<?php
    $namaBulan = [
        1 => 'Januari',
        2 => 'Februari',
        3 => 'Maret',
        4 => 'April',
        5 => 'Mei',
        6 => 'Juni',
        7 => 'Juli',
        8 => 'Agustus',
        9 => 'September',
        10 => 'Oktober',
        11 => 'November',
        12 => 'Desember',
    ];
?>

<div class="min-h-screen bg-[#F3F6F5] py-6">

    <div class="mx-auto max-w-7xl">

        
        <div class="mb-8 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h1 class="text-2xl font-bold text-[#365F65]">
                    Pendapatan
                </h1>

                <p class="mt-1 text-sm text-[#8BA5A2]">
                    Monitoring tagihan dan penyerahan invoice tenant.
                </p>
            </div>

            <div class="rounded-xl border border-[#DCE6E4] bg-white px-5 py-3 shadow-sm">
                <p class="text-xs text-[#8BA5A2]">Periode laporan</p>

                <p class="text-lg font-bold text-[#365F65]">
                    <?php echo e($namaBulan[$bulanAwal]); ?> -
                    <?php echo e($namaBulan[$bulanAkhir]); ?>

                    <?php echo e($tahun); ?>

                </p>
            </div>
        </div>

        
        <?php if(session('success')): ?>
            <div class="mb-6 rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-700">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="mb-6 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                <?php echo e($errors->first()); ?>

            </div>
        <?php endif; ?>

        
        <div class="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">

            
            <div class="rounded-2xl border border-[#DCE6E4] bg-white p-5 shadow-sm">
                <div class="flex items-center justify-between">
                    <p class="text-sm font-medium text-[#8BA5A2]">
                        Total Tagihan
                    </p>

                    <div class="rounded-xl bg-blue-50 p-3 text-blue-600">
                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                stroke-width="2"
                                d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8V6m0 2v8m0 0v2m0-2c-1.657 0-3-.895-3-2m6 0c0 1.105-1.343 2-3 2m9-4a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    </div>
                </div>

                <h2 class="mt-4 text-xl font-bold text-[#365F65]">
                    Rp <?php echo e(number_format($totalTagihan, 0, ',', '.')); ?>

                </h2>

                <p class="mt-1 text-xs text-[#A0B3B0]">
                    Total tagihan <?php echo e($namaBulan[$bulanAwal]); ?> -
                    <?php echo e($namaBulan[$bulanAkhir]); ?> <?php echo e($tahun); ?>

                </p>
            </div>

            
            <div class="rounded-2xl border border-[#DCE6E4] bg-white p-5 shadow-sm">
                <div class="flex items-center justify-between">
                    <p class="text-sm font-medium text-[#8BA5A2]">
                        Invoice Diberikan
                    </p>

                    <div class="rounded-xl bg-green-50 p-3 text-green-600">
                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                stroke-width="2" d="M5 13l4 4L19 7" />
                        </svg>
                    </div>
                </div>

                <h2 class="mt-4 text-xl font-bold text-green-600">
                    Rp <?php echo e(number_format($totalInvoiceDiberikan, 0, ',', '.')); ?>

                </h2>

                <p class="mt-1 text-xs text-[#A0B3B0]">
                    <?php echo e($jumlahInvoiceDiberikan); ?> invoice sudah diberikan
                </p>
            </div>

            
            <div class="rounded-2xl border border-[#DCE6E4] bg-white p-5 shadow-sm">
                <div class="flex items-center justify-between">
                    <p class="text-sm font-medium text-[#8BA5A2]">
                        Pending Meter
                    </p>

                    <div class="rounded-xl bg-orange-50 p-3 text-orange-500">
                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                stroke-width="2"
                                d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                    </div>
                </div>

                <h2 class="mt-4 text-xl font-bold text-orange-500">
                    Rp <?php echo e(number_format($totalInvoiceBelumDiberikan, 0, ',', '.')); ?>

                </h2>

                <p class="mt-1 text-xs text-[#A0B3B0]">
                    <?php echo e($jumlahInvoiceBelumDiberikan); ?> invoice belum diberikan
                </p>
            </div>

            
            <div class="rounded-2xl border border-[#DCE6E4] bg-white p-5 shadow-sm">
                <div class="flex items-center justify-between">
                    <p class="text-sm font-medium text-[#8BA5A2]">
                        Tenant Periode
                    </p>

                    <div class="rounded-xl bg-purple-50 p-3 text-purple-600">
                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                stroke-width="2"
                                d="M17 20h5V4H2v16h5m10 0v-5a3 3 0 00-3-3H10a3 3 0 00-3 3v5m10 0H7m5-11a3 3 0 100-6 3 3 0 000 6z" />
                        </svg>
                    </div>
                </div>

                <h2 class="mt-4 text-xl font-bold text-[#365F65]">
                    <?php echo e($pendapatanPerTenant->count()); ?> Tenant
                </h2>

                <p class="mt-1 text-xs text-[#A0B3B0]">
                    Memiliki tagihan pada periode terpilih
                </p>
            </div>

        </div>

        
        <div class="mb-8 rounded-2xl border border-[#DCE6E4] bg-white p-5 shadow-sm">

            <form action="<?php echo e(route('pendapatan')); ?>" method="GET"
                class="flex flex-col gap-4">

                <div class="grid grid-cols-1 gap-4 md:grid-cols-4">

                    
                    <div>
                        <label class="mb-2 block text-sm font-semibold text-[#527D82]">
                            Tahun
                        </label>

                        <input
                            type="number"
                            name="tahun"
                            value="<?php echo e($tahun); ?>"
                            min="2000"
                            max="2100"
                            class="w-full rounded-xl border-[#DCE6E4] text-sm text-[#365F65] focus:border-[#527D82] focus:ring-[#527D82]"
                        >
                    </div>

                    
                    <div>
                        <label class="mb-2 block text-sm font-semibold text-[#527D82]">
                            Dari Bulan
                        </label>

                        <select
                            name="bulan_awal"
                            class="w-full rounded-xl border-[#DCE6E4] text-sm text-[#365F65] focus:border-[#527D82] focus:ring-[#527D82]"
                        >
                            <?php $__currentLoopData = $namaBulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nomor => $nama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($nomor); ?>"
                                    <?php if($bulanAwal == $nomor): echo 'selected'; endif; ?>>
                                    <?php echo e($nama); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    
                    <div>
                        <label class="mb-2 block text-sm font-semibold text-[#527D82]">
                            Sampai Bulan
                        </label>

                        <select
                            name="bulan_akhir"
                            class="w-full rounded-xl border-[#DCE6E4] text-sm text-[#365F65] focus:border-[#527D82] focus:ring-[#527D82]"
                        >
                            <?php $__currentLoopData = $namaBulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nomor => $nama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($nomor); ?>"
                                    <?php if($bulanAkhir == $nomor): echo 'selected'; endif; ?>>
                                    <?php echo e($nama); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    
                    <div>
                        <label class="mb-2 block text-sm font-semibold text-[#527D82]">
                            Cari Tenant
                        </label>

                        <input
                            type="text"
                            name="search"
                            value="<?php echo e($search); ?>"
                            placeholder="Nama tenant atau mitra..."
                            class="w-full rounded-xl border-[#DCE6E4] text-sm text-[#365F65] placeholder-[#A0B3B0] focus:border-[#527D82] focus:ring-[#527D82]"
                        >
                    </div>

                </div>

                <div class="flex flex-wrap gap-2">
                    <button
                        type="submit"
                        class="rounded-xl bg-[#365F65] px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-[#294F55]"
                    >
                        Terapkan Filter
                    </button>

                    <a
                        href="<?php echo e(route('pendapatan')); ?>"
                        class="rounded-xl border border-[#DCE6E4] bg-white px-5 py-2.5 text-sm font-semibold text-[#527D82] transition hover:bg-[#F3F6F5]"
                    >
                        Reset
                    </a>
                </div>

            </form>
        </div>

        
        <div class="mb-5">
            <h2 class="text-lg font-bold text-[#365F65]">
                Daftar Tagihan Tenant
            </h2>

            <p class="mt-1 text-sm text-[#8BA5A2]">
                Menampilkan tagihan <?php echo e($namaBulan[$bulanAwal]); ?> -
                <?php echo e($namaBulan[$bulanAkhir]); ?> <?php echo e($tahun); ?>.
                Centang status setelah invoice diberikan kepada tenant.
            </p>
        </div>

        
        <?php $__empty_1 = true; $__currentLoopData = $pendapatanPerTenant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenantId => $daftarTagihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <?php
                $tagihanPertama = $daftarTagihan->first();

                $tenant = $tagihanPertama->tenant;
                $kerjaSama = $tagihanPertama->kerjaSama;

                $totalTenant = $daftarTagihan->sum('jumlah_tagihan');

                $sudahDiberikan = $daftarTagihan
                    ->where('status_invoice', true)
                    ->count();

                $belumDiberikan = $daftarTagihan
                    ->where('status_invoice', false)
                    ->count();
            ?>

            <div class="mb-6 overflow-hidden rounded-2xl border border-[#DCE6E4] bg-white shadow-sm">

                
                <div class="border-b border-[#E6EEEC] px-5 py-5">

                    <div class="flex flex-col justify-between gap-4 md:flex-row md:items-center">

                        <div>
                            <div class="flex flex-wrap items-center gap-2">

                                <h3 class="text-lg font-bold text-[#365F65]">
                                    <?php echo e($tenant->nama_tenant ?? '-'); ?>

                                </h3>

                                <span class="rounded-full bg-[#EAF1F0] px-3 py-1 text-xs font-semibold text-[#527D82]">
                                    <?php echo e($tenant->bentuk_kerja_sama ?? '-'); ?>

                                </span>

                            </div>

                            <p class="mt-1 text-sm text-[#8BA5A2]">
                                <?php echo e($tenant->mitra_usaha ?? '-'); ?>

                            </p>

                            <p class="mt-1 text-xs text-[#A0B3B0]">
                                <?php echo e($kerjaSama->nomor_kerja_sama ?? '-'); ?>

                            </p>
                        </div>

                        <div class="grid grid-cols-2 gap-5 md:text-right">

                            <div>
                                <p class="text-xs text-[#A0B3B0]">
                                    GTO
                                </p>

                                <p class="mt-1 font-semibold text-[#365F65]">
                                    Rp <?php echo e(number_format($tenant->gto ?? 0, 0, ',', '.')); ?>

                                </p>
                            </div>

                            <div>
                                <p class="text-xs text-[#A0B3B0]">
                                    Revenue Sharing
                                </p>

                                <p class="mt-1 font-semibold text-[#365F65]">
                                    <?php echo e(number_format($tenant->revenue_sharing ?? 0, 2, ',', '.')); ?>%
                                </p>
                            </div>

                        </div>

                    </div>

                    
                    <div class="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 border-t border-[#E6EEEC] pt-4 text-sm">

                        <p class="text-[#8BA5A2]">
                            Total tagihan:

                            <span class="font-bold text-[#365F65]">
                                Rp <?php echo e(number_format($totalTenant, 0, ',', '.')); ?>

                            </span>
                        </p>

                        <p class="font-medium text-green-600">
                            <?php echo e($sudahDiberikan); ?> invoice diberikan
                        </p>

                        <p class="font-medium text-orange-500">
                            <?php echo e($belumDiberikan); ?> belum diberikan
                        </p>

                    </div>

                </div>

                
                <div class="overflow-x-auto">

                    <table class="w-full text-left text-sm">

                        <thead class="bg-[#F3F6F5] text-xs uppercase tracking-wide text-[#8BA5A2]">
                            <tr>
                                <th class="whitespace-nowrap px-5 py-4 font-semibold">
                                    Bulan
                                </th>

                                <th class="whitespace-nowrap px-5 py-4 font-semibold">
                                    Nominal Tagihan
                                </th>

                                <th class="whitespace-nowrap px-5 py-4 font-semibold">
                                    Status Invoice
                                </th>

                                <th class="whitespace-nowrap px-5 py-4 font-semibold">
                                    Tanggal Diberikan
                                </th>
                            </tr>
                        </thead>

                        <tbody class="divide-y divide-[#EDF2F1]">

                            <?php $__currentLoopData = $daftarTagihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr class="transition hover:bg-[#F8FAF9]">

                                    <td class="whitespace-nowrap px-5 py-4 font-semibold text-[#365F65]">
                                        <?php echo e($namaBulan[$tagihan->bulan] ?? '-'); ?>

                                        <?php echo e($tagihan->tahun); ?>

                                    </td>

                                    <td class="whitespace-nowrap px-5 py-4 font-semibold text-[#365F65]">
                                        Rp <?php echo e(number_format($tagihan->jumlah_tagihan, 0, ',', '.')); ?>

                                    </td>

                                    <td class="whitespace-nowrap px-5 py-4">

                                        <form
                                            action="<?php echo e(route('pendapatan.status-invoice', $tagihan->id)); ?>"
                                            method="POST"
                                        >
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>

                                            <input
                                                type="hidden"
                                                name="status_invoice"
                                                value="0"
                                            >

                                            <input
                                                type="hidden"
                                                name="search"
                                                value="<?php echo e($search); ?>"
                                            >

                                            <input
                                                type="hidden"
                                                name="bulan_awal"
                                                value="<?php echo e($bulanAwal); ?>"
                                            >

                                            <input
                                                type="hidden"
                                                name="bulan_akhir"
                                                value="<?php echo e($bulanAkhir); ?>"
                                            >

                                            <label class="inline-flex cursor-pointer items-center gap-2">

                                                <input
                                                    type="checkbox"
                                                    name="status_invoice"
                                                    value="1"
                                                    onchange="this.form.submit()"
                                                    <?php if($tagihan->status_invoice): echo 'checked'; endif; ?>
                                                    class="h-4 w-4 cursor-pointer rounded border-[#B8CECA] text-green-600 focus:ring-green-500"
                                                >

                                                <?php if($tagihan->status_invoice): ?>
                                                    <span class="rounded-full bg-green-50 px-3 py-1 text-xs font-semibold text-green-700">
                                                        Sudah Diberikan
                                                    </span>
                                                <?php else: ?>
                                                    <span class="rounded-full bg-orange-50 px-3 py-1 text-xs font-semibold text-orange-700">
                                                        Belum Diberikan
                                                    </span>
                                                <?php endif; ?>

                                            </label>

                                        </form>

                                    </td>

                                    <td class="whitespace-nowrap px-5 py-4 text-[#8BA5A2]">

                                        <?php if($tagihan->tanggal_diberikan): ?>
                                            <?php echo e($tagihan->tanggal_diberikan->format('d/m/Y')); ?>

                                        <?php else: ?>
                                            -
                                        <?php endif; ?>

                                    </td>

                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table>

                </div>

            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            
            <div class="rounded-2xl border border-dashed border-[#C8D8D5] bg-white px-6 py-16 text-center">

                <div class="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-[#F3F6F5]">

                    <svg class="h-7 w-7 text-[#8BA5A2]" fill="none"
                        stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            stroke-width="2"
                            d="M9 14l2 2 4-4m6-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>

                </div>

                <h3 class="text-lg font-bold text-[#365F65]">
                    Belum Ada Data Pendapatan
                </h3>

                <p class="mx-auto mt-2 max-w-md text-sm text-[#8BA5A2]">
                    Tidak ditemukan tagihan untuk periode
                    <?php echo e($namaBulan[$bulanAwal]); ?> -
                    <?php echo e($namaBulan[$bulanAkhir]); ?> <?php echo e($tahun); ?>.
                    Pastikan aktivasi sudah disetujui pusat, kontrak tenant mencakup periode tersebut, dan data GTO
                    serta Revenue Sharing sudah diisi.
                </p>

            </div>

        <?php endif; ?>

        
        <div class="mt-6 rounded-2xl border border-[#DCE6E4] bg-[#EAF1F0] p-5">

            <h4 class="text-sm font-bold text-[#365F65]">
                Informasi Perhitungan
            </h4>

            <p class="mt-2 text-sm leading-relaxed text-[#527D82]">
                Tagihan bulanan dihitung menggunakan rumus:
                <strong>GTO × Revenue Sharing (%)</strong>.
                Tagihan hanya dibuat untuk kerja sama yang aktivasinya sudah disetujui oleh pusat, dan hanya pada bulan yang termasuk dalam periode kontrak tenant.
                Filter tahun dan rentang bulan digunakan untuk menampilkan total tagihan
                pada periode yang dipilih.
                Status invoice menunjukkan apakah invoice sudah diberikan kepada tenant,
                bukan status pembayaran.
            </p>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\AeroTrack\resources\views/pendapatan/index.blade.php ENDPATH**/ ?>