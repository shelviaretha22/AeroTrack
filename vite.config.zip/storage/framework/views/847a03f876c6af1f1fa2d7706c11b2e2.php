<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<?php
    $pct = fn ($a, $t) => $t > 0 ? round($a / $t * 100, 1) : 0;
    $rp  = fn ($n) => 'Rp ' . number_format($n, 0, ',', '.');

    // Warna status kontrak: dipakai SAMA di semua kartu, tabel, dan badge.
    $warnaStatus = [
        'Aktif'              => '#2F9E5A',
        'Proses Pusat'       => '#D6A14D',
        'Proses Cabang'      => '#527D82',
        'Negosiasi'          => '#8A6BB5',
    ];
    $warnaTerminal = ['#365F65', '#D6A14D', '#8FB339', '#8A6BB5'];

    $ikon = [
        'doc'   => 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z',
        'check' => 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z',
        'x'     => 'M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z',
        'build' => 'M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5',
        'touch' => 'M7 11.5V14m0-2.5v-6a1.5 1.5 0 113 0m-3 6a1.5 1.5 0 00-3 0v2a7 7 0 007 7h3a7 7 0 007-7v-3.5a1.5 1.5 0 00-3 0m-6-3V11m0-5.5v-1a1.5 1.5 0 013 0v1m0 0V11m0-5.5a1.5 1.5 0 013 0v3m0 0V11',
        'hash'  => 'M7 20l4-16m2 16l4-16M6 9h14M4 15h14',
    ];

    $segmenLokasi = $distribusiLokasi->keys()->values()->map(fn ($n, $i) => [
        'label' => $n,
        'value' => $distribusiLokasi[$n],
        'color' => $warnaTerminal[$i % count($warnaTerminal)],
    ])->all();

    $pctAktif = $pct($aktif, $total);
    $selectCls = 'w-full rounded-lg border border-[#DCE6E4] bg-white px-2.5 py-2 text-xs text-[#365F65] focus:border-[#527D82] focus:outline-none';

    // Badge status (warna dari $warnaStatus, latar transparan agar aman di tema gelap)
    $badge = function (string $s) use ($warnaStatus) {
        $c = $warnaStatus[$s] ?? '#7A9290';
        return '<span class="inline-flex items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-0.5 text-[11px] font-semibold" style="color:' . $c . ';background:' . $c . '22">'
            . '<span class="h-1.5 w-1.5 rounded-full" style="background:' . $c . '"></span>' . e($s) . '</span>';
    };
?>

<div class="min-h-screen bg-[#F3F6F5] py-6">
<div class="mx-auto max-w-[1400px] space-y-4">

    <div>
        <h1 class="text-2xl font-bold text-[#365F65]">Dashboard Kontrak</h1>
        <p class="mt-1 text-sm text-[#8BA5A2]">Monitoring kontrak, aktivasi, dan potensi pendapatan mitra.</p>
    </div>

    
    <form method="GET" action="<?php echo e(route('dashboard')); ?>" class="rounded-2xl border border-[#DCE6E4] bg-white p-4 shadow-sm">
        <div class="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-[repeat(5,minmax(0,1fr))_auto]">
            <label class="block">
                <span class="mb-1 block text-[11px] font-semibold text-[#527D82]">Terminal</span>
                <select name="terminal" class="<?php echo e($selectCls); ?>" onchange="this.form.submit()">
                    <option value="">Semua terminal</option>
                    <?php $__currentLoopData = $opsiTerminal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($o); ?>" <?php if($filter['terminal'] === $o): echo 'selected'; endif; ?>><?php echo e($o); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label>
            <label class="block">
                <span class="mb-1 block text-[11px] font-semibold text-[#527D82]">Lokasi</span>
                <select name="lokasi" class="<?php echo e($selectCls); ?>" onchange="this.form.submit()">
                    <option value="">Semua lokasi</option>
                    <?php $__currentLoopData = $opsiLokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($o); ?>" <?php if($filter['lokasi'] === $o): echo 'selected'; endif; ?>><?php echo e($o); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label>
            <label class="block">
                <span class="mb-1 block text-[11px] font-semibold text-[#527D82]">Kategori Tenant</span>
                <select name="kategori" class="<?php echo e($selectCls); ?>" onchange="this.form.submit()">
                    <option value="">Semua kategori</option>
                    <?php $__currentLoopData = $opsiKategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kunci => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($kunci); ?>" <?php if($filter['kategori'] === $kunci): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label>
            <label class="block">
                <span class="mb-1 block text-[11px] font-semibold text-[#527D82]">Status Kontrak</span>
                <select name="status" class="<?php echo e($selectCls); ?>" onchange="this.form.submit()">
                    <option value="">Semua status</option>
                    <?php $__currentLoopData = $opsiStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($o); ?>" <?php if($filter['status'] === $o): echo 'selected'; endif; ?>><?php echo e($o); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label>
            <label class="block">
                <span class="mb-1 block text-[11px] font-semibold text-[#527D82]">Periode Kontrak</span>
                <select name="periode" class="<?php echo e($selectCls); ?>" onchange="this.form.submit()">
                    <option value="">Semua periode</option>
                    <?php $__currentLoopData = $opsiPeriode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($o); ?>" <?php if($filter['periode'] === $o): echo 'selected'; endif; ?>><?php echo e($o); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </label>
            <div class="flex items-end gap-2">
                <noscript><button class="rounded-lg bg-[#527D82] px-3 py-2 text-xs font-semibold text-white">Terapkan</button></noscript>
                <?php if($adaFilter): ?>
                    <a href="<?php echo e(route('dashboard')); ?>" class="inline-flex w-full items-center justify-center rounded-lg border border-[#DCE6E4] px-3 py-2 text-xs font-semibold text-[#B96B60] hover:bg-[#F3F6F5]">Reset filter</a>
                <?php endif; ?>
            </div>
        </div>
    </form>

    
    <div class="grid grid-cols-2 gap-3 lg:grid-cols-4 xl:grid-cols-6">
        <?php $__currentLoopData = [['Total Kontrak', $total, 'doc'], ['Kontrak Aktif', $aktif, 'check']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$lbl, $val, $ic]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex flex-col items-center justify-center rounded-2xl border border-[#DCE6E4] bg-white p-4 shadow-sm">
                <div class="flex items-center gap-2 text-[#527D82]">
                    <svg class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="1.6" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="<?php echo e($ikon[$ic]); ?>"/></svg>
                    <span class="text-sm font-semibold"><?php echo e($lbl); ?></span>
                </div>
                <p class="mt-2 text-4xl font-bold text-[#365F65]"><?php echo e($val); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <div class="col-span-2 rounded-2xl border border-[#EBD9AE] bg-[#FBF1DC] p-4 shadow-sm lg:col-span-2">
            <p class="text-xs font-semibold text-[#527D82]">Progress Aktivasi Kontrak SUB</p>
            <div class="mt-1 flex items-end justify-between">
                <p class="text-3xl font-bold text-[#365F65]"><?php echo e($aktif); ?><span class="text-base font-semibold text-[#8BA5A2]"> / <?php echo e($total); ?></span></p>
                <p class="text-lg font-bold text-[#2F9E5A]"><?php echo e($pctAktif); ?>%</p>
            </div>
            <div class="mt-2 h-2.5 overflow-hidden rounded-full bg-white/70">
                <div class="h-full rounded-full bg-[#2F9E5A]" style="width: <?php echo e($pctAktif); ?>%"></div>
            </div>
            <p class="mt-1 text-[11px] text-[#8BA5A2]">Kontrak teraktivasi dari seluruh kontrak</p>
        </div>

        
        <?php $__currentLoopData = $perTerminal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nama => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $w = $warnaTerminal[$loop->index % count($warnaTerminal)]; $pt = $pct($d['aktif'], $d['total']); ?>
            <div class="rounded-2xl border border-[#DCE6E4] bg-white p-4 shadow-sm">
                <p class="truncate text-xs font-semibold text-[#527D82]"><?php echo e($nama); ?></p>
                <div class="mt-1 flex items-end justify-between">
                    <p class="text-3xl font-bold text-[#365F65]"><?php echo e($d['total']); ?></p>
                    <p class="text-sm font-bold" style="color: <?php echo e($w); ?>"><?php echo e($pt); ?>%</p>
                </div>
                <div class="mt-2 h-2 overflow-hidden rounded-full bg-[#E2EBE9]">
                    <div class="h-full rounded-full" style="width: <?php echo e($pt); ?>%; background: <?php echo e($w); ?>"></div>
                </div>
                <p class="mt-1 text-[11px] text-[#8BA5A2]"><?php echo e($d['aktif']); ?> aktif dari <?php echo e($d['total']); ?> kontrak</p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <div class="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">

        <div class="rounded-2xl border border-[#DCE6E4] bg-white p-4 shadow-sm">
            <p class="text-sm font-bold text-[#365F65]">Distribusi Kontrak per Lokasi</p>
            <?php if($total > 0): ?>
                <div class="mt-3 flex flex-col items-center gap-5 sm:flex-row sm:justify-center">
                    <?php if (isset($component)) { $__componentOriginald5f32726a5285808210280700aa275b5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald5f32726a5285808210280700aa275b5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pie','data' => ['segments' => $segmenLokasi,'size' => 'h-44 w-44']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pie'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['segments' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($segmenLokasi),'size' => 'h-44 w-44']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald5f32726a5285808210280700aa275b5)): ?>
<?php $attributes = $__attributesOriginald5f32726a5285808210280700aa275b5; ?>
<?php unset($__attributesOriginald5f32726a5285808210280700aa275b5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald5f32726a5285808210280700aa275b5)): ?>
<?php $component = $__componentOriginald5f32726a5285808210280700aa275b5; ?>
<?php unset($__componentOriginald5f32726a5285808210280700aa275b5); ?>
<?php endif; ?>
                    <ul class="w-full space-y-2 text-xs sm:w-auto">
                        <?php $__currentLoopData = $segmenLokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="flex items-center gap-2">
                                <span class="h-3 w-3 shrink-0 rounded-full" style="background: <?php echo e($s['color']); ?>"></span>
                                <span class="flex-1 text-[#527D82]"><?php echo e($s['label']); ?></span>
                                <span class="font-bold text-[#365F65]"><?php echo e($s['value']); ?></span>
                                <span class="w-12 text-right font-semibold text-[#7A9290]"><?php echo e($pct($s['value'], $total)); ?>%</span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php else: ?>
                <p class="py-12 text-center text-sm text-[#8BA5A2]">Tidak ada data untuk filter ini.</p>
            <?php endif; ?>
        </div>

        <div class="rounded-2xl border border-[#C9DAD7] bg-[#DCE9E6] p-4 shadow-sm">
            <p class="mb-3 text-sm font-bold text-[#365F65]">Informasi Kontrak</p>
            <div class="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <?php $__currentLoopData = [
                    ['Belum Aktif', $info['belumAktif'], 'x', '#B96B60', 'Belum teraktivasi'],
                    ['Pusat', $info['pusat'], 'build', $warnaStatus['Proses Pusat'], 'Menunggu keputusan Commercial Pusat'],
                    ['Proses Aktivasi', $info['prosesAktivasi'], 'touch', $warnaStatus['Proses Cabang'], 'Sedang di cabang atau pusat'],
                    ['No Kontrak / No Konsumen Sistem', $info['noKontrak'] . ' / ' . $info['noKonsumen'], 'hash', '#2F9E5A', $info['noKontrak'] . ' kontrak bernomor, ' . $info['noKonsumen'] . ' terdaftar di sistem'],
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$lbl, $val, $ic, $warna, $ket]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center gap-3 rounded-xl bg-white/70 px-3 py-3">
                        <svg class="h-9 w-9 shrink-0" style="color: <?php echo e($warna); ?>" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="<?php echo e($ikon[$ic]); ?>"/></svg>
                        <div class="min-w-0 flex-1">
                            <p class="text-xs font-semibold text-[#527D82]"><?php echo e($lbl); ?></p>
                            <p class="text-2xl font-bold text-[#365F65]"><?php echo e($val); ?></p>
                            <p class="truncate text-[10px] text-[#8BA5A2]" title="<?php echo e($ket); ?>"><?php echo e($ket); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    
    <div>
        <p class="mb-2 text-sm font-bold text-[#365F65]">Monitoring per Kategori Tenant</p>
        <div class="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
            <?php $__currentLoopData = $perKategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kunci => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $p = $pct($d['aktif'], $d['total']); ?>
                <div class="rounded-2xl border border-[#DCE6E4] bg-white p-3.5 shadow-sm">
                    <p class="truncate text-xs font-semibold text-[#527D82]"><?php echo e($d['label']); ?></p>
                    <div class="mt-1 flex items-end justify-between">
                        <p class="text-2xl font-bold text-[#365F65]"><?php echo e($d['total']); ?></p>
                        <p class="text-sm font-bold <?php echo e($d['total'] > 0 && $p >= 100 ? 'text-[#2F9E5A]' : 'text-[#D6812B]'); ?>"><?php echo e($p); ?>%</p>
                    </div>
                    <div class="mt-1.5 h-1.5 overflow-hidden rounded-full bg-[#E2EBE9]">
                        <div class="h-full rounded-full bg-[#2F9E5A]" style="width: <?php echo e($p); ?>%"></div>
                    </div>
                    <p class="mt-1 text-[10px] text-[#8BA5A2]"><?php echo e($d['aktif']); ?> aktif dari <?php echo e($d['total']); ?> kontrak</p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    
    <div class="grid grid-cols-1 gap-4 xl:grid-cols-[minmax(0,6fr)_minmax(0,6fr)]">
        <div id="tbl-potensi" class="flex flex-col overflow-hidden rounded-2xl border border-[#DCE6E4] bg-white shadow-sm">
            <div class="flex items-center justify-between bg-[#527D82] px-4 py-2.5 text-xs font-bold text-white">
                <span>Potensi Pendapatan Kontrak</span><span class="font-medium opacity-80">Rupiah</span>
            </div>
            <?php $pctTerima = $grandTotalPotensi > 0 ? min(100, round($grandTotalDiterima / $grandTotalPotensi * 100, 1)) : 0; ?>
            <div class="border-b border-[#E2EBE9] px-4 py-3">
                <div class="flex flex-wrap items-end justify-between gap-2 text-xs">
                    <span class="text-[#527D82]">Sudah diterima <b class="text-[#2F9E5A]"><?php echo e($rp($grandTotalDiterima)); ?></b> dari potensi <?php echo e($rp($grandTotalPotensi)); ?> per bulan</span>
                    <b class="text-[#365F65]"><?php echo e($pctTerima); ?>%</b>
                </div>
                <div class="mt-1.5 h-2 overflow-hidden rounded-full bg-[#E2EBE9]"><div class="h-full rounded-full bg-[#2F9E5A]" style="width: <?php echo e($pctTerima); ?>%"></div></div>
                <p class="mt-1 text-[10px] text-[#8BA5A2]">Diterima = tagihan yang invoicenya sudah diberikan (menu Pendapatan), seluruh periode.</p>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-xs">
                    <thead class="bg-[#F3F6F5] text-[#365F65]">
                        <tr>
                            <th class="px-4 py-2 text-left font-bold">Mitra / Tenant</th>
                            <th class="px-4 py-2 text-right font-bold">Potensi / Bulan</th>
                            <th class="px-4 py-2 text-right font-bold">Sudah Diterima</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $potensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="<?php echo e($loop->even ? 'bg-[#F8FAF9]' : ''); ?>">
                                <td class="px-4 py-2 text-[#527D82]"><?php echo e($b['mitra']); ?></td>
                                <td class="whitespace-nowrap px-4 py-2 text-right text-[#365F65]"><?php echo e($rp($b['potensi'])); ?></td>
                                <td class="whitespace-nowrap px-4 py-2 text-right font-semibold <?php echo e($b['diterima'] > 0 ? 'text-[#2F9E5A]' : 'text-[#B7C6C3]'); ?>"><?php echo e($rp($b['diterima'])); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="3" class="px-4 py-8 text-center text-[#8BA5A2]">Belum ada data GTO / revenue sharing.</td></tr>
                        <?php endif; ?>
                    </tbody>
                    <tfoot>
                        <tr class="border-t border-[#DCE6E4] font-bold text-[#365F65]">
                            <td class="px-4 py-2.5">Grand Total (<?php echo e($jumlahPotensi); ?> mitra)</td>
                            <td class="whitespace-nowrap px-4 py-2.5 text-right"><?php echo e($rp($grandTotalPotensi)); ?></td>
                            <td class="whitespace-nowrap px-4 py-2.5 text-right text-[#2F9E5A]"><?php echo e($rp($grandTotalDiterima)); ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
            <div class="mt-auto"><?php if (isset($component)) { $__componentOriginal1667981b6c071c5a4f4cc9ecb2627444 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1667981b6c071c5a4f4cc9ecb2627444 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pager','data' => ['paginator' => $potensi]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pager'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($potensi)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1667981b6c071c5a4f4cc9ecb2627444)): ?>
<?php $attributes = $__attributesOriginal1667981b6c071c5a4f4cc9ecb2627444; ?>
<?php unset($__attributesOriginal1667981b6c071c5a4f4cc9ecb2627444); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1667981b6c071c5a4f4cc9ecb2627444)): ?>
<?php $component = $__componentOriginal1667981b6c071c5a4f4cc9ecb2627444; ?>
<?php unset($__componentOriginal1667981b6c071c5a4f4cc9ecb2627444); ?>
<?php endif; ?></div>
        </div>

        
        <div class="space-y-4">
            <div class="overflow-hidden rounded-2xl border border-[#DCE6E4] bg-white shadow-sm">
                <div class="flex justify-between bg-[#D6A14D] px-4 py-2.5 text-xs font-bold text-white">
                    <span>Monitoring Status Kontrak</span><span>Jumlah Kontrak</span>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-xs">
                        <thead class="bg-[#F3F6F5] text-[#365F65]">
                            <tr>
                                <th class="px-4 py-2 text-left font-bold">Update Status Kontrak</th>
                                <th class="px-4 py-2 text-left font-bold">Nomor Kontrak</th>
                                <th class="px-4 py-2 text-right font-bold">Jumlah</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $tabelStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="align-top <?php echo e($loop->even ? 'bg-[#F8FAF9]' : ''); ?>">
                                    <td class="px-4 py-2"><?php echo $badge($r['status']); ?></td>
                                    <td class="px-4 py-2 text-[#527D82]">
                                        <?php if($r['nomor']->isEmpty()): ?>
                                            <span class="text-[#B7C6C3]">-</span>
                                        <?php else: ?>
                                            <?php echo e($r['nomor']->take(2)->implode(', ')); ?>

                                            <?php if($r['nomor']->count() > 2): ?>
                                                <span class="text-[#8BA5A2]" title="<?php echo e($r['nomor']->implode(', ')); ?>">+<?php echo e($r['nomor']->count() - 2); ?> lagi</span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-4 py-2 text-right font-semibold text-[#365F65]"><?php echo e($r['jumlah']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr class="border-t border-[#DCE6E4] font-bold text-[#365F65]">
                                <td class="px-4 py-2.5" colspan="2">Grand Total</td>
                                <td class="px-4 py-2.5 text-right"><?php echo e($total); ?></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>

            <div class="overflow-hidden rounded-2xl border border-[#DCE6E4] bg-white shadow-sm">
                <div class="flex justify-between bg-[#527D82] px-4 py-2.5 text-xs font-bold text-white">
                    <span>Status Periode Kontrak</span><span>Jumlah Kontrak</span>
                </div>
                <table class="w-full text-sm">
                    <?php $__currentLoopData = $perPeriode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s => $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="<?php echo e($loop->even ? 'bg-[#F8FAF9]' : ''); ?>">
                            <td class="w-10 px-4 py-2 text-[#8BA5A2]"><?php echo e($loop->iteration); ?>.</td>
                            <td class="py-2 text-[#527D82]"><?php echo e($s); ?></td>
                            <td class="px-4 py-2 text-right font-semibold text-[#365F65]"><?php echo e($n); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-t border-[#DCE6E4] font-bold text-[#365F65]">
                        <td></td><td class="py-2.5">Grand Total</td><td class="px-4 py-2.5 text-right"><?php echo e($total); ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    
    <div id="tbl-detail" class="overflow-hidden rounded-2xl border border-[#DCE6E4] bg-white shadow-sm">
        <div class="bg-[#365F65] px-4 py-2.5 text-xs font-bold text-white">Detail Monitoring Tenant</div>
        <div class="overflow-x-auto">
            <table class="w-full text-xs">
                <thead class="bg-[#E2EBE9] text-[#365F65]">
                    <tr>
                        <th class="px-4 py-2.5 text-left">No</th>
                        <th class="px-4 py-2.5 text-left">No Konsumen</th>
                        <th class="px-4 py-2.5 text-left">Mitra / Tenant</th>
                        <th class="px-4 py-2.5 text-left">Kode Ruang</th>
                        <th class="px-4 py-2.5 text-left">Status Kontrak</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="<?php echo e($loop->even ? 'bg-[#F8FAF9]' : ''); ?>">
                            <td class="px-4 py-2 text-[#8BA5A2]"><?php echo e($detail->firstItem() + $loop->index); ?>.</td>
                            <td class="whitespace-nowrap px-4 py-2 text-[#365F65]"><?php echo e($b['no_konsumen'] ?: '-'); ?></td>
                            <td class="px-4 py-2 text-[#527D82]">
                                <a href="<?php echo e(route('aktivasi.show', $b['id'])); ?>" class="hover:underline"><?php echo e($b['mitra']); ?></a>
                                <?php if($b['brand']): ?><span class="text-[#8BA5A2]"> · <?php echo e($b['brand']); ?></span><?php endif; ?>
                            </td>
                            <td class="whitespace-nowrap px-4 py-2 text-[#527D82]"><?php echo e($b['kode_ruang'] ?: '-'); ?></td>
                            <td class="px-4 py-2"><?php echo $badge($b['status']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="px-4 py-8 text-center text-[#8BA5A2]">Tidak ada data untuk filter ini.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if (isset($component)) { $__componentOriginal1667981b6c071c5a4f4cc9ecb2627444 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1667981b6c071c5a4f4cc9ecb2627444 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pager','data' => ['paginator' => $detail]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pager'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($detail)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1667981b6c071c5a4f4cc9ecb2627444)): ?>
<?php $attributes = $__attributesOriginal1667981b6c071c5a4f4cc9ecb2627444; ?>
<?php unset($__attributesOriginal1667981b6c071c5a4f4cc9ecb2627444); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1667981b6c071c5a4f4cc9ecb2627444)): ?>
<?php $component = $__componentOriginal1667981b6c071c5a4f4cc9ecb2627444; ?>
<?php unset($__componentOriginal1667981b6c071c5a4f4cc9ecb2627444); ?>
<?php endif; ?>
    </div>

</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\AeroTrack\resources\views/dashboard.blade.php ENDPATH**/ ?>