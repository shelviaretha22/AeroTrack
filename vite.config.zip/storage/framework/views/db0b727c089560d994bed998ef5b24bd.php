<?php $__env->startSection('title', 'Detail Laporan'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full px-6 py-6">

    
    <div class="mb-6">
        <a
            href="<?php echo e(route('laporan', ['tahun' => $tahun])); ?>"
            class="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-blue-600 mb-4"
        >
            <span>&larr;</span>
            Kembali ke Laporan
        </a>

        <div class="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h1 class="text-2xl font-bold text-gray-800">
                    <?php echo e($judul); ?>

                </h1>

                <p class="mt-1 text-sm text-gray-500">
                    <?php echo e($deskripsi); ?>

                </p>
            </div>

            <div class="text-sm text-gray-500">
                Periode: <span class="font-semibold text-gray-700"><?php echo e($tahun); ?></span>
            </div>
        </div>
    </div>

    
    <div class="mb-5 rounded-xl border border-gray-200 bg-white p-5">
        <p class="text-sm text-gray-500">Total Data</p>

        <p class="mt-1 text-2xl font-bold text-gray-800">
            <?php echo e($data->count()); ?>

        </p>
    </div>

    
    <div class="overflow-hidden rounded-xl border border-gray-200 bg-white">

        <div class="border-b border-gray-200 px-5 py-4">
            <h2 class="font-semibold text-gray-800">
                Daftar Data Laporan
            </h2>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full min-w-[1100px] text-left text-sm">

                <thead class="bg-gray-50 text-gray-600">
                    <tr>
                        <th class="px-5 py-4 font-semibold">No</th>
                        <th class="px-5 py-4 font-semibold">No. Kerja Sama</th>
                        <th class="px-5 py-4 font-semibold">Mitra Usaha</th>
                        <th class="px-5 py-4 font-semibold">Brand</th>
                        <th class="px-5 py-4 font-semibold">Jenis Usaha</th>
                        <th class="px-5 py-4 font-semibold">Terminal</th>
                        <th class="px-5 py-4 font-semibold">Kode Ruang</th>
                        <th class="px-5 py-4 font-semibold">No. Kontrak Mitra</th>
                        <th class="px-5 py-4 font-semibold">Status</th>
                        <th class="px-5 py-4 text-center font-semibold">Aksi</th>
                    </tr>
                </thead>

                <tbody class="divide-y divide-gray-100">

                    <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50">

                            <td class="whitespace-nowrap px-5 py-4 text-gray-600">
                                <?php echo e($index + 1); ?>

                            </td>

                            <td class="whitespace-nowrap px-5 py-4 font-medium text-gray-700">
                                <?php echo e($item['nomor_kerja_sama']); ?>

                            </td>

                            <td class="whitespace-nowrap px-5 py-4 text-gray-700">
                                <?php echo e($item['mitra_usaha']); ?>

                            </td>

                            <td class="whitespace-nowrap px-5 py-4 text-gray-700">
                                <?php echo e($item['brand']); ?>

                            </td>

                            <td class="whitespace-nowrap px-5 py-4 text-gray-700">
                                <?php echo e($item['jenis_usaha']); ?>

                            </td>

                            <td class="whitespace-nowrap px-5 py-4 text-gray-700">
                                <?php echo e($item['terminal']); ?>

                            </td>

                            <td class="whitespace-nowrap px-5 py-4 text-gray-700">
                                <?php echo e($item['kode_ruang']); ?>

                            </td>

                            <td class="whitespace-nowrap px-5 py-4 text-gray-700">
                                <?php echo e($item['nomor_kontrak']); ?>

                            </td>

                            <td class="whitespace-nowrap px-5 py-4">
                                <span class="inline-flex rounded-full bg-gray-100 px-3 py-1 text-xs font-medium text-gray-700">
                                    <?php echo e($item['status']); ?>

                                </span>
                            </td>

                            <td class="whitespace-nowrap px-5 py-4 text-center">
                                <a
                                    href="<?php echo e($item['url']); ?>"
                                    class="font-medium text-blue-600 hover:text-blue-800"
                                >
                                    Detail
                                </a>
                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="10" class="px-5 py-12 text-center text-gray-500">
                                Tidak ada data yang ditemukan untuk kategori ini.
                            </td>
                        </tr>
                    <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\AeroTrack\resources\views/laporan/drilldown.blade.php ENDPATH**/ ?>