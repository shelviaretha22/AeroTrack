<?php $__env->startSection('page-title', 'Laporan Lokasi & Aktivasi'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $fmt = fn ($v, $d = 0) => number_format((float) $v, $d, ',', '.');
    $kelasInput = 'rounded-xl border border-[#DCE6E4] bg-[#F8FAF9] px-3.5 py-2.5 text-sm text-[#365F65] outline-none transition focus:border-[#527D82] focus:bg-white focus:ring-2 focus:ring-[#527D82]/15';
    $adaData = $data['tanggal_okupansi'] !== null || $data['tanggal_aktivasi'] !== null;
    $parameter = $terminal ? ['terminal' => $terminal] : [];
    $run = $data['etl_terakhir'];
?>

<div class="space-y-6">

    
    <div class="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div>
            <p class="text-sm text-[#8BA5A2]">Management / Lokasi / Laporan</p>
            <h1 class="mt-1 text-2xl font-bold text-[#365F65]">Laporan Lokasi &amp; Aktivasi</h1>
            <p class="mt-1 text-sm text-[#7A9290]">
                Dibaca dari tabel ringkasan hasil ETL
                <?php if($data['tanggal_okupansi']): ?>
                    (data per <?php echo e(\Illuminate\Support\Carbon::parse($data['tanggal_okupansi'])->translatedFormat('d F Y')); ?>).
                <?php else: ?>
                    (belum ada data).
                <?php endif; ?>
            </p>
        </div>

        <div class="flex flex-wrap items-center gap-2">
            <a href="<?php echo e(route('lokasi.laporan.excel', $parameter)); ?>"
               class="inline-flex items-center justify-center rounded-xl border border-[#DCE6E4] bg-white px-4 py-2.5 text-sm font-semibold text-[#365F65] shadow-sm hover:bg-[#F3F6F5]">
                Unduh Excel
            </a>
            <a href="<?php echo e(route('lokasi.laporan.pdf', $parameter)); ?>"
               class="inline-flex items-center justify-center rounded-xl border border-[#DCE6E4] bg-white px-4 py-2.5 text-sm font-semibold text-[#365F65] shadow-sm hover:bg-[#F3F6F5]">
                Unduh PDF
            </a>
            <form method="POST" action="<?php echo e(route('lokasi.laporan.etl')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit"
                        class="inline-flex items-center justify-center rounded-xl bg-[#365F65] px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-[#294F55]">
                    Jalankan ETL
                </button>
            </form>
        </div>
    </div>

    
    <?php $__currentLoopData = [
        'success' => 'border-emerald-200 bg-emerald-50 text-emerald-800',
        'error'   => 'border-red-200 bg-red-50 text-red-700',
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kunci => $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(session($kunci)): ?>
            <div class="rounded-xl border px-4 py-3 text-sm <?php echo e($kelas); ?>"><?php echo e(session($kunci)); ?></div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <form method="GET" action="<?php echo e(route('lokasi.laporan')); ?>" class="flex flex-wrap items-center gap-2">
        <label for="terminal" class="text-sm font-semibold text-[#365F65]">Terminal</label>
        <select id="terminal" name="terminal" class="<?php echo e($kelasInput); ?>" onchange="this.form.submit()">
            <option value="">Semua</option>
            <option value="T1" <?php if($terminal === 'T1'): echo 'selected'; endif; ?>>T1</option>
            <option value="T2" <?php if($terminal === 'T2'): echo 'selected'; endif; ?>>T2</option>
        </select>
        <noscript><button type="submit" class="<?php echo e($kelasInput); ?>">Terapkan</button></noscript>
    </form>

    <?php if(! $adaData): ?>
        <div class="rounded-2xl border border-dashed border-[#DCE6E4] bg-white px-6 py-12 text-center">
            <p class="font-semibold text-[#365F65]">Belum ada data laporan</p>
            <p class="mt-1 text-sm text-[#7A9290]">Tekan "Jalankan ETL" untuk menyusun ringkasan dari data Lokasi dan Aktivasi.</p>
        </div>
    <?php else: ?>
        
        <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div class="rounded-2xl border border-[#E2EBE9] bg-white p-5 shadow-sm">
                <p class="text-sm text-[#7A9290]">Total ruangan</p>
                <p class="mt-1 text-3xl font-bold text-[#365F65]"><?php echo e($fmt($data['kpi']['total_ruangan'])); ?></p>
            </div>
            <div class="rounded-2xl border border-[#E2EBE9] bg-white p-5 shadow-sm">
                <p class="text-sm text-[#7A9290]">Okupansi</p>
                <p class="mt-1 text-3xl font-bold text-[#365F65]"><?php echo e($fmt($data['kpi']['okupansi'], 1)); ?>%</p>
                <p class="mt-1 text-xs text-[#8BA5A2]"><?php echo e($fmt($data['kpi']['terisi'])); ?> ruangan terisi</p>
            </div>
            <div class="rounded-2xl border border-[#E2EBE9] bg-white p-5 shadow-sm">
                <p class="text-sm text-[#7A9290]">Total pengajuan aktivasi</p>
                <p class="mt-1 text-3xl font-bold text-[#365F65]"><?php echo e($fmt($data['kpi']['total_aktivasi'])); ?></p>
            </div>
            <div class="rounded-2xl border border-[#E2EBE9] bg-white p-5 shadow-sm">
                <p class="text-sm text-[#7A9290]">Disetujui</p>
                <p class="mt-1 text-3xl font-bold text-[#365F65]"><?php echo e($fmt($data['kpi']['disetujui'])); ?></p>
                <p class="mt-1 text-xs text-[#8BA5A2]"><?php echo e($fmt($data['kpi']['persen_setuju'], 1)); ?>% dari yang sudah diputuskan</p>
            </div>
        </div>

        
        <section class="rounded-2xl border border-[#E2EBE9] bg-white shadow-sm">
            <h2 class="border-b border-[#E2EBE9] px-5 py-4 font-bold text-[#365F65]">Okupansi per Terminal</h2>
            <div class="overflow-x-auto">
                <table class="min-w-full text-sm">
                    <thead class="bg-[#F8FAF9] text-left text-xs uppercase tracking-wide text-[#7A9290]">
                        <tr>
                            <th class="px-5 py-3">Terminal</th>
                            <th class="px-5 py-3 text-right">Total</th>
                            <th class="px-5 py-3 text-right">Terisi</th>
                            <th class="px-5 py-3 text-right">Kosong</th>
                            <th class="px-5 py-3 text-right">Okupansi</th>
                            <th class="px-5 py-3 text-right">Luas total (m²)</th>
                            <th class="px-5 py-3 text-right">Luas terisi (m²)</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-[#EEF3F2] text-[#365F65]">
                        <?php $__empty_1 = true; $__currentLoopData = $data['per_terminal']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="px-5 py-3 font-semibold"><?php echo e($r['nama']); ?></td>
                                <td class="px-5 py-3 text-right"><?php echo e($fmt($r['total'])); ?></td>
                                <td class="px-5 py-3 text-right"><?php echo e($fmt($r['terisi'])); ?></td>
                                <td class="px-5 py-3 text-right"><?php echo e($fmt($r['kosong'])); ?></td>
                                <td class="px-5 py-3 text-right font-semibold"><?php echo e($fmt($r['okupansi'], 1)); ?>%</td>
                                <td class="px-5 py-3 text-right"><?php echo e($fmt($r['luas_total'], 2)); ?></td>
                                <td class="px-5 py-3 text-right"><?php echo e($fmt($r['luas_terisi'], 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="7" class="px-5 py-8 text-center text-[#7A9290]">Tidak ada data.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        
        <section class="rounded-2xl border border-[#E2EBE9] bg-white shadow-sm">
            <h2 class="border-b border-[#E2EBE9] px-5 py-4 font-bold text-[#365F65]">Okupansi per Lantai</h2>
            <div class="overflow-x-auto">
                <table class="min-w-full text-sm">
                    <thead class="bg-[#F8FAF9] text-left text-xs uppercase tracking-wide text-[#7A9290]">
                        <tr>
                            <th class="px-5 py-3">Terminal / Lantai</th>
                            <th class="px-5 py-3 text-right">Total</th>
                            <th class="px-5 py-3 text-right">Terisi</th>
                            <th class="px-5 py-3 text-right">Kosong</th>
                            <th class="px-5 py-3 text-right">Okupansi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-[#EEF3F2] text-[#365F65]">
                        <?php $__empty_1 = true; $__currentLoopData = $data['per_lantai']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="px-5 py-3 font-semibold"><?php echo e($r['nama']); ?></td>
                                <td class="px-5 py-3 text-right"><?php echo e($fmt($r['total'])); ?></td>
                                <td class="px-5 py-3 text-right"><?php echo e($fmt($r['terisi'])); ?></td>
                                <td class="px-5 py-3 text-right"><?php echo e($fmt($r['kosong'])); ?></td>
                                <td class="px-5 py-3 text-right font-semibold"><?php echo e($fmt($r['okupansi'], 1)); ?>%</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="5" class="px-5 py-8 text-center text-[#7A9290]">Tidak ada data.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        
        <section class="rounded-2xl border border-[#E2EBE9] bg-white shadow-sm">
            <h2 class="border-b border-[#E2EBE9] px-5 py-4 font-bold text-[#365F65]">Aktivasi per Periode dan Status</h2>

            <div class="flex flex-wrap gap-2 px-5 pt-4">
                <?php $__currentLoopData = $data['per_status']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="rounded-full bg-[#F3F6F5] px-3 py-1 text-xs font-semibold text-[#365F65]">
                        <?php echo e($s['nama']); ?>: <?php echo e($fmt($s['jumlah'])); ?>

                    </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="overflow-x-auto">
                <table class="mt-3 min-w-full text-sm">
                    <thead class="bg-[#F8FAF9] text-left text-xs uppercase tracking-wide text-[#7A9290]">
                        <tr>
                            <th class="px-5 py-3">Periode pengajuan</th>
                            <th class="px-5 py-3">Status</th>
                            <th class="px-5 py-3 text-right">Jumlah</th>
                            <th class="px-5 py-3 text-right">Rata-rata hari ke keputusan</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-[#EEF3F2] text-[#365F65]">
                        <?php $__empty_1 = true; $__currentLoopData = $data['aktivasi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="px-5 py-3 font-semibold"><?php echo e($r->periode === '-' ? 'Belum diajukan' : $r->periode); ?></td>
                                <td class="px-5 py-3"><?php echo e($r->status); ?></td>
                                <td class="px-5 py-3 text-right"><?php echo e($fmt($r->jumlah)); ?></td>
                                <td class="px-5 py-3 text-right"><?php echo e($r->rata_hari_keputusan !== null ? $fmt($r->rata_hari_keputusan, 1) : '-'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="4" class="px-5 py-8 text-center text-[#7A9290]">Tidak ada data.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    <?php endif; ?>

    
    <section class="rounded-2xl border border-[#E2EBE9] bg-white shadow-sm">
        <h2 class="border-b border-[#E2EBE9] px-5 py-4 font-bold text-[#365F65]">Catatan ETL</h2>
        <div class="overflow-x-auto">
            <table class="min-w-full text-sm">
                <thead class="bg-[#F8FAF9] text-left text-xs uppercase tracking-wide text-[#7A9290]">
                    <tr>
                        <th class="px-5 py-3">Mulai</th>
                        <th class="px-5 py-3">Pemicu</th>
                        <th class="px-5 py-3">Status</th>
                        <th class="px-5 py-3 text-right">Diekstrak</th>
                        <th class="px-5 py-3 text-right">Dimuat</th>
                        <th class="px-5 py-3">Pesan</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-[#EEF3F2] text-[#365F65]">
                    <?php $__empty_1 = true; $__currentLoopData = $data['riwayat_etl']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="px-5 py-3"><?php echo e($e->mulai_at ? \Illuminate\Support\Carbon::parse($e->mulai_at)->format('d/m/Y H:i') : '-'); ?></td>
                            <td class="px-5 py-3"><?php echo e($e->pemicu); ?></td>
                            <td class="px-5 py-3 font-semibold <?php echo e($e->status === 'gagal' ? 'text-red-600' : ($e->status === 'berhasil' ? 'text-emerald-600' : '')); ?>"><?php echo e($e->status); ?></td>
                            <td class="px-5 py-3 text-right"><?php echo e($fmt($e->baris_diekstrak)); ?></td>
                            <td class="px-5 py-3 text-right"><?php echo e($fmt($e->baris_dimuat)); ?></td>
                            <td class="px-5 py-3 text-[#7A9290]"><?php echo e($e->pesan ?? '-'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6" class="px-5 py-8 text-center text-[#7A9290]">ETL belum pernah dijalankan.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\AeroTrack\resources\views/lokasi/laporan.blade.php ENDPATH**/ ?>