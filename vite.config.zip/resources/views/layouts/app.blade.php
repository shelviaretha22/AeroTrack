<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" data-theme="{{ auth()->check() && auth()->user()->theme_preference === 'dark' ? 'dark' : 'light' }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'AeroTrack') }}</title>

    {{-- Google Font --}}
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link
        href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap"
        rel="stylesheet"
    >

    {{-- Vite --}}
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    {{-- Alpine.js --}}
    <script
        defer
        src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"
    ></script>
    {{-- Tema gelap (aktif hanya jika data-theme="dark") --}}
    <link rel="stylesheet" href="{{ asset('css/dark.css') }}?v=2">
</head>

<body
    class="font-['Plus_Jakarta_Sans'] bg-[#F3F6F5] text-[#365F65] antialiased"
>
    <div
        x-data="{ sidebarOpen: false }"
        class="min-h-screen"
    >

        {{-- =========================================================
             MOBILE SIDEBAR OVERLAY
        ========================================================== --}}
        <div
            x-show="sidebarOpen"
            x-transition.opacity
            @click="sidebarOpen = false"
            class="fixed inset-0 z-40 bg-[#294F55]/40 backdrop-blur-sm lg:hidden"
            style="display: none;"
        ></div>

        {{-- =========================================================
             SIDEBAR
        ========================================================== --}}
        <aside
            class="fixed inset-y-0 left-0 z-50 w-[260px] bg-[#365F65] text-white transform transition-transform duration-300 lg:translate-x-0"
            :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'"
        >
            {{-- SIDEBAR INNER --}}
            <div class="flex h-full flex-col">

                {{-- =================================================
                     LOGO
                ================================================== --}}
                <div
                    class="flex h-[90px] items-center justify-between px-7 border-b border-white/10"
                >
                    <a
                        href="{{ route('dashboard') }}"
                        class="flex items-center"
                    >
                        <img
                            src="{{ asset('images/aerotrack-logo.png') }}"
                            alt="AeroTrack"
                            class="w-[145px] h-auto object-contain brightness-0 invert"
                        >
                    </a>

                    {{-- Close Sidebar Mobile --}}
                    <button
                        @click="sidebarOpen = false"
                        class="lg:hidden text-white/70 hover:text-white"
                    >
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            class="w-6 h-6"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            stroke-width="1.8"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                d="M6 18L18 6M6 6l12 12"
                            />
                        </svg>
                    </button>
                </div>

                {{-- =================================================
                     SYSTEM LABEL
                ================================================== --}}
                <div class="px-7 pt-6 pb-3">
                    <p
                        class="text-[9px] font-bold tracking-[0.2em] uppercase text-[#B8CECA]"
                    >
                        Commercial Management
                    </p>

                    <p class="mt-1 text-[11px] text-white/50">
                        Airport Tenant System
                    </p>
                </div>

                {{-- =================================================
                     NAVIGATION
                ================================================== --}}
                <nav class="flex-1 overflow-y-auto px-4 py-3">

                    {{-- DASHBOARD --}}
                    <a
                        href="{{ route('dashboard') }}"
                        @click="sidebarOpen = false"
                        class="group flex items-center gap-3 px-4 py-3 mb-1 rounded-xl text-sm font-medium {{ request()->routeIs('dashboard') ? 'bg-white/10 text-white' : 'text-white/75 hover:bg-white/10 hover:text-white' }} transition"
                            >
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            class="w-[19px] h-[19px] shrink-0"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            stroke-width="1.8"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                d="M3 12l9-9 9 9M5 10v10a1 1 0 001 1h4v-6h4v6h4a1 1 0 001-1V10"
                            />
                        </svg>

                        <span>Dashboard</span>
                    </a>

                    {{-- SECTION LABEL --}}
                    <div class="px-4 pt-5 pb-2">
                        <p
                            class="text-[9px] font-bold tracking-[0.18em] uppercase text-white/35"
                        >
                            Management
                        </p>
                    </div>

                    {{-- TENANT --}}
                    <a
                        href="{{ route('tenant.index') }}"
                        @click="sidebarOpen = false"
                        class="group flex items-center gap-3 px-4 py-3 mb-1 rounded-xl text-sm font-medium {{ request()->routeIs('tenant.*') ? 'bg-white/10 text-white' : 'text-white/75 hover:bg-white/10 hover:text-white' }} transition"
                        >
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            class="w-[19px] h-[19px] shrink-0"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            stroke-width="1.8"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2M9 11a4 4 0 100-8 4 4 0 000 8zM22 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"
                            />
                        </svg>

                        <span>Tenant</span>
                    </a>

                    {{-- LOKASI --}}
                    <a
                        href="{{ route('lokasi.index') }}"
                        class="group flex items-center gap-3 px-4 py-3 mb-1 rounded-xl text-sm font-medium {{ request()->routeIs('lokasi.*', 'kerja-sama.lokasi.*') ? 'bg-white/10 text-white' : 'text-white/75 hover:bg-white/10 hover:text-white' }} transition"
                    >
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            class="w-[19px] h-[19px] shrink-0"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            stroke-width="1.8"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                d="M12 21s7-5.25 7-12a7 7 0 10-14 0c0 6.75 7 12 7 12z"
                            />
                            <circle cx="12" cy="9" r="2.5" />
                        </svg>

                        <span>Lokasi</span>
                    </a>

                    {{-- KERJA SAMA --}}
                    <a
                        href="{{ route('kerja-sama') }}"
                        class="group flex items-center gap-3 px-4 py-3 mb-1 rounded-xl text-sm font-medium {{ (request()->routeIs('kerja-sama*') && ! request()->routeIs('kerja-sama.lokasi.*')) ? 'bg-white/10 text-white' : 'text-white/75 hover:bg-white/10 hover:text-white' }} transition"
                    >
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            class="w-[19px] h-[19px] shrink-0"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            stroke-width="1.8"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                d="M8 12h8M12 8v8M7 3h10a4 4 0 014 4v10a4 4 0 01-4 4H7a4 4 0 01-4-4V7a4 4 0 014-4z"
                            />
                        </svg>

                        <span>Kerja Sama</span>
                    </a>

                    {{-- KONTRAK --}}
                    <a
                         href="{{ route('kontrak') }}"
                         @click="sidebarOpen = false"
                         class="group flex items-center gap-3 px-4 py-3 mb-1 rounded-xl text-sm font-medium {{ request()->routeIs('kontrak*') ? 'bg-white/10 text-white' : 'text-white/75 hover:bg-white/10 hover:text-white' }} transition"
                        >
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            class="w-[19px] h-[19px] shrink-0"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            stroke-width="1.8"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                d="M7 3h8l4 4v14H7a2 2 0 01-2-2V5a2 2 0 012-2z"
                            />
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                d="M15 3v5h5M9 13h6M9 17h6"
                            />
                        </svg>

                        <span>Kontrak</span>
                    </a>

                    {{-- AKTIVASI --}}
                    <a
                     href="{{ route('aktivasi') }}"
                     @click="sidebarOpen = false"
                     class="group flex items-center gap-3 px-4 py-3 mb-1 rounded-xl text-sm font-medium {{ request()->routeIs('aktivasi*') ? 'bg-white/10 text-white' : 'text-white/75 hover:bg-white/10 hover:text-white' }} transition"
                    >
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            class="w-[19px] h-[19px] shrink-0"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            stroke-width="1.8"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                d="M13 2L4 14h7l-1 8 9-12h-7l1-8z"
                            />
                        </svg>

                        <span>Aktivasi</span>
                    </a>

                    {{-- PENDAPATAN --}}
                    <a
                        href="{{ route('pendapatan') }}"
                        @click="sidebarOpen = false"
                        class="group flex items-center gap-3 px-4 py-3 mb-1 rounded-xl text-sm font-medium {{ request()->routeIs('pendapatan*') ? 'bg-white/10 text-white' : 'text-white/75 hover:bg-white/10 hover:text-white' }} transition"
                    >
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            class="w-[19px] h-[19px] shrink-0"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            stroke-width="1.8"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                d="M12 2v20M17 5.5C16.2 4.55 14.8 4 13 4h-2a4 4 0 000 8h2a4 4 0 010 8h-2c-1.8 0-3.2-.55-4-1.5"
                            />
                        </svg>

                        <span>Pendapatan</span>
                    </a>

                    {{-- LAPORAN --}}
<a
    href="{{ route('laporan') }}"
    @click="sidebarOpen = false"
    class="group flex items-center gap-3 px-4 py-3 mb-1 rounded-xl text-sm font-medium {{ request()->routeIs('laporan*') ? 'bg-white/10 text-white' : 'text-white/75 hover:bg-white/10 hover:text-white' }} transition"
>
    <svg
        xmlns="http://www.w3.org/2000/svg"
        class="w-[19px] h-[19px] shrink-0"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
        stroke-width="1.8"
    >
        <path
            stroke-linecap="round"
            stroke-linejoin="round"
            d="M6 3h12a2 2 0 012 2v14a2 2 0 01-2 2H6a2 2 0 01-2-2V5a2 2 0 012-2z"
        />
        <path
            stroke-linecap="round"
            stroke-linejoin="round"
            d="M8 8h8M8 12h8M8 16h5"
        />
    </svg>

    <span>Laporan</span>
</a>
                </nav>

                {{-- =================================================
                     BOTTOM SIDEBAR
                ================================================== --}}
                <div class="px-4 pb-5">

                    {{-- DIVIDER --}}
                    <div class="border-t border-white/10 mb-3"></div>

                    {{-- PROFILE --}}
                    <a
                        href="{{ route('profile.index') }}"
                        class="flex items-center gap-3 px-4 py-3 rounded-xl text-sm transition {{ request()->routeIs('profile.*') ? 'bg-white/10 text-white' : 'text-white/70 hover:bg-white/10 hover:text-white' }}"
                    >
                        <div
                            class="w-8 h-8 rounded-lg bg-[#B8CECA]/20 flex items-center justify-center"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                class="w-4 h-4"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                                stroke-width="1.8"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    d="M20 21a8 8 0 00-16 0M12 13a4 4 0 100-8 4 4 0 000 8z"
                                />
                            </svg>
                        </div>

                        <span>Profile</span>
                    </a>

                    {{-- LOGOUT --}}
                    <form
                        method="POST"
                        action="{{ route('logout') }}"
                    >
                        @csrf

                        <button
                            type="submit"
                            class="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm text-white/60 hover:bg-white/10 hover:text-white transition"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                class="w-[19px] h-[19px]"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                                stroke-width="1.8"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    d="M10 17l5-5-5-5M15 12H3"
                                />
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    d="M21 19V5a2 2 0 00-2-2h-6"
                                />
                            </svg>

                            <span>Logout</span>
                        </button>
                    </form>

                </div>
            </div>
        </aside>

        {{-- =========================================================
             MAIN AREA
        ========================================================== --}}
        <div class="lg:pl-[260px] min-h-screen">

            {{-- =====================================================
                 TOPBAR
            ====================================================== --}}
            <header
                class="h-[76px] bg-white border-b border-[#DCE6E4] flex items-center justify-between px-5 sm:px-7 lg:px-9 sticky top-0 z-30"
            >

                {{-- LEFT TOPBAR --}}
                <div class="flex items-center gap-4">

                    {{-- Mobile Menu --}}
                    <button
                        @click="sidebarOpen = true"
                        class="lg:hidden w-10 h-10 rounded-xl bg-[#F3F6F5] flex items-center justify-center text-[#365F65]"
                    >
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            class="w-5 h-5"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            stroke-width="1.8"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                d="M4 6h16M4 12h16M4 18h16"
                            />
                        </svg>
                    </button>

                    {{-- Page Title --}}
                    <div>
                        <p
                            class="text-[10px] font-semibold uppercase tracking-[0.15em] text-[#8BA5A2]"
                        >
                            AeroTrack
                        </p>

                        <h1
                            class="text-base sm:text-lg font-bold text-[#365F65]"
                        >
                            @yield('page-title', 'Dashboard')
                        </h1>
                    </div>
                </div>

                {{-- RIGHT TOPBAR --}}
                <div class="flex items-center gap-3 sm:gap-5">

                    {{-- SEARCH --}}
                    <div
                        class="hidden md:flex items-center w-[220px] h-10 px-3 rounded-xl bg-[#F3F6F5] border border-[#E2EBE9]"
                    >
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            class="w-4 h-4 text-[#8BA5A2]"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor"
                            stroke-width="1.8"
                        >
                            <circle cx="11" cy="11" r="7" />
                            <path
                                stroke-linecap="round"
                                d="M20 20l-3.5-3.5"
                            />
                        </svg>

                        <input
                            type="text"
                            placeholder="Search..."
                            class="ml-2 w-full bg-transparent border-0 outline-none focus:ring-0 text-xs text-[#365F65] placeholder-[#9AAEAB]"
                        >
                    </div>

                    {{-- NOTIFICATION --}}
                    @include('notifikasi._dropdown')

                    {{-- USER --}}
                    @auth
                    <div class="relative" x-data="{ buka: false }" @keydown.escape.window="buka = false" @click.outside="buka = false">
                        <button type="button" @click="buka = !buka" :aria-expanded="buka" aria-haspopup="true"
                                class="flex items-center gap-3 rounded-xl py-1 pl-1 pr-2 transition hover:bg-[#F3F6F5]">
                            @if (auth()->user()->avatar_path)
                                <img src="{{ route('profile.foto', ['v' => md5(auth()->user()->avatar_path)]) }}" alt=""
                                     class="h-9 w-9 rounded-xl object-cover">
                            @else
                                <span class="flex h-9 w-9 items-center justify-center rounded-xl bg-[#D9E5E3] text-sm font-bold text-[#365F65]">
                                    {{ auth()->user()->inisial }}
                                </span>
                            @endif

                            <span class="hidden text-left lg:block">
                                <span class="block max-w-[140px] truncate text-xs font-bold text-[#365F65]">{{ auth()->user()->name }}</span>
                                <span class="block text-[10px] text-[#8BA5A2]">{{ auth()->user()->peran }}</span>
                            </span>

                            <svg class="hidden h-4 w-4 text-[#8BA5A2] transition sm:block" :class="buka ? 'rotate-180' : ''" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>
                        </button>

                        <div x-show="buka" x-transition.origin.top.right style="display: none;"
                             class="absolute right-0 z-50 mt-3 w-60 overflow-hidden rounded-2xl border border-[#E2EBE9] bg-white shadow-xl">
                            <div class="border-b border-[#E2EBE9] px-4 py-3">
                                <p class="truncate text-sm font-bold text-[#365F65]">{{ auth()->user()->name }}</p>
                                <p class="truncate text-xs text-[#8BA5A2]">{{ auth()->user()->email }}</p>
                            </div>

                            <div class="p-1.5 text-sm font-medium text-[#527D82]">
                                <a href="{{ route('profile.index') }}" class="flex items-center gap-3 rounded-xl px-3 py-2.5 transition hover:bg-[#F3F6F5]">
                                    <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>
                                    Profile &amp; Pengaturan
                                </a>
                                <a href="{{ route('notifikasi.index') }}" class="flex items-center gap-3 rounded-xl px-3 py-2.5 transition hover:bg-[#F3F6F5]">
                                    <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/></svg>
                                    Semua notifikasi
                                    @if (($notifRingkas['belum'] ?? 0) > 0)
                                        <span class="ml-auto rounded-full bg-red-50 px-2 py-0.5 text-[10px] font-bold text-red-600">{{ $notifRingkas['belum'] }}</span>
                                    @endif
                                </a>
                            </div>

                            <form action="{{ route('logout') }}" method="POST" class="border-t border-[#E2EBE9] p-1.5">
                                @csrf
                                <button type="submit" class="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-red-600 transition hover:bg-red-50">
                                    <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/></svg>
                                    Keluar
                                </button>
                            </form>
                        </div>
                    </div>
                    @endauth

                </div>
            </header>

            {{-- =====================================================
                 PAGE CONTENT
            ====================================================== --}}
            <main class="p-5 sm:p-7 lg:p-9">
                @yield('content')
            </main>

        </div>
    </div>
</body>

</html>