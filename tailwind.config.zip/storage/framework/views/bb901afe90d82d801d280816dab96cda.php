<?php $__env->startSection('page-title', 'Data Lokasi'); ?>

<?php $__env->startSection('content'); ?>
<?php
    // Pengurutan lewat judul kolom: klik sekali menaik, klik lagi menurun.
    $sortAktif = request('sort', 'newest');
    $urlUrut = function (string $naik, string $turun) use ($sortAktif) {
        return request()->fullUrlWithQuery([
            'sort' => $sortAktif === $naik ? $turun : $naik,
            'page' => null,
        ]);
    };
    $panahUrut = function (string $naik, string $turun) use ($sortAktif) {
        return $sortAktif === $naik ? '↑' : ($sortAktif === $turun ? '↓' : '');
    };

    $filterAktif = collect([
        'search' => 'Cari',
        'terminal' => 'Terminal',
        'lantai' => 'Lantai',
        'jenis_ruangan' => 'Jenis',
        'status' => 'Status',
    ])->filter(fn ($label, $key) => request()->filled($key));

    $kelasInput = 'w-full rounded-xl border border-[#DCE6E4] bg-[#F8FAF9] px-3.5 py-2.5 text-sm text-[#365F65] outline-none transition focus:border-[#527D82] focus:bg-white focus:ring-2 focus:ring-[#527D82]/15';

    $luasFormat = fn ($v) => number_format((float) $v, 0, ',', '.');
?>

<div class="space-y-6">

    
    <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
            <p class="text-sm text-[#8BA5A2]">Management / Lokasi</p>
            <h1 class="mt-1 text-2xl font-bold text-[#365F65]">Data Lokasi</h1>
            <p class="mt-1 text-sm text-[#7A9290]">
                Kelola data ruangan fisik yang tersedia di bandara.
            </p>
        </div>

        <a href="<?php echo e(route('lokasi.create')); ?>"
           class="inline-flex items-center justify-center gap-2 rounded-xl bg-[#365F65] px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-[#294F55]">
            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round">
                <path d="M12 5v14M5 12h14"/>
            </svg>
            Tambah Lokasi
        </a>
    </div>

    
    <?php $__currentLoopData = [
        'success' => 'border-emerald-200 bg-emerald-50 text-emerald-800',
        'error' => 'border-red-200 bg-red-50 text-red-700',
        'info' => 'border-blue-200 bg-blue-50 text-blue-800',
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(session($type)): ?>
            <div class="rounded-xl border px-4 py-3 text-sm <?php echo e($kelas); ?>" role="status">
                <?php echo e(session($type)); ?>

            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <section class="grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4" aria-label="Ringkasan lokasi">

        
        <div class="rounded-2xl border border-[#E2EBE9] bg-white p-4 shadow-sm sm:p-5">
            <div class="flex items-center justify-between gap-3">
                <p class="text-sm font-medium text-[#7A9290]">Total Lokasi</p>
                <span class="flex h-9 w-9 items-center justify-center rounded-lg bg-[#EAF2F1] text-[#365F65]">
                    <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>
                    </svg>
                </span>
            </div>
            <p class="mt-2 text-3xl font-bold text-[#365F65]"><?php echo e(number_format($totalLokasi, 0, ',', '.')); ?></p>
            <p class="mt-1 text-xs text-[#8BA5A2]">Total luas <?php echo e($luasFormat($totalLuas)); ?> m²</p>
        </div>

        
        <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'Kosong', 'page' => null])); ?>"
                class="block rounded-2xl border border-[#E2EBE9] bg-white p-4 text-left sm:p-5 shadow-sm transition hover:border-emerald-300 hover:shadow">
            <div class="flex items-center justify-between gap-3">
                <p class="text-sm font-medium text-[#7A9290]">Lokasi Kosong</p>
                <span class="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-50 text-emerald-700">
                    <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="9"/><path d="m8 12 2.5 2.5L16 9"/>
                    </svg>
                </span>
            </div>
            <p class="mt-2 text-3xl font-bold text-emerald-700"><?php echo e(number_format($totalKosong, 0, ',', '.')); ?></p>
            <p class="mt-1 text-xs text-[#8BA5A2]"><?php echo e($persentaseKosong); ?>% · siap ditempati</p>
        </a>

        
        <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'Terisi', 'page' => null])); ?>"
                class="block rounded-2xl border border-[#E2EBE9] bg-white p-4 text-left sm:p-5 shadow-sm transition hover:border-amber-300 hover:shadow">
            <div class="flex items-center justify-between gap-3">
                <p class="text-sm font-medium text-[#7A9290]">Lokasi Terisi</p>
                <span class="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-50 text-amber-700">
                    <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                        <rect x="4" y="3" width="16" height="18" rx="2"/><path d="M9 21v-5h6v5M9 7h.01M15 7h.01M9 11h.01M15 11h.01"/>
                    </svg>
                </span>
            </div>
            <p class="mt-2 text-3xl font-bold text-amber-700"><?php echo e(number_format($totalTerisi, 0, ',', '.')); ?></p>
            <div class="mt-2 h-1.5 overflow-hidden rounded-full bg-[#E7EFEC]">
                <div class="h-full rounded-full bg-amber-500" style="width: <?php echo e($persentaseTerisi); ?>%"></div>
            </div>
            <p class="mt-1 text-xs text-[#8BA5A2]">Okupansi <?php echo e($persentaseTerisi); ?>%</p>
        </a>

        
        <div class="rounded-2xl border border-[#E2EBE9] bg-white p-4 shadow-sm sm:p-5">
            <div class="flex items-center justify-between gap-3">
                <p class="text-sm font-medium text-[#7A9290]">Jenis Ruangan</p>
                <span class="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-50 text-blue-700">
                    <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                        <rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/>
                        <rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>
                    </svg>
                </span>
            </div>
            <p class="mt-2 text-3xl font-bold text-blue-700"><?php echo e(number_format($totalJenisRuangan, 0, ',', '.')); ?></p>
            <p class="mt-1 text-xs text-[#8BA5A2]">Kategori ruangan terdaftar</p>
        </div>
    </section>

    
    <?php
        $warnaUsaha = ['#365F65', '#D6A14D', '#31966A', '#527D82', '#B5503C', '#6C8EBF', '#A47720', '#8BA5A2'];
        $segmenStatus = [
            ['label' => 'Terisi', 'value' => $totalTerisi, 'color' => '#D6A14D'],
            ['label' => 'Kosong', 'value' => $totalKosong, 'color' => '#31966A'],
        ];
        $segmenUsaha = $perJenisUsaha->values()->map(fn ($r, $i) => [
            'label' => $r->jenis_usaha,
            'value' => (int) $r->total,
            'color' => $r->jenis_usaha === 'Belum diisi' ? '#C9D6D3' : $warnaUsaha[$i % count($warnaUsaha)],
        ])->all();
        $persenLuas = $totalLuas > 0 ? round(($luasTerisi / $totalLuas) * 100, 1) : 0;

        // Warna sel heatmap: makin penuh makin pekat.
        $gayaPanas = fn ($persen) => 'background-color: rgba(54,95,101,' . round(0.10 + ($persen / 100) * 0.80, 2) . ');';
    ?>

    <section x-data="{ buka: true, tab: 'ringkasan' }" class="rounded-2xl border border-[#E2EBE9] bg-white shadow-sm">
        <div class="flex flex-col gap-3 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="font-bold text-[#365F65]">Analisis Lokasi</h2>
                <p class="mt-0.5 text-sm text-[#7A9290]">Komposisi status, okupansi per lantai, dan denah seluruh ruangan.</p>
            </div>

            <div class="flex items-center gap-2">
                <div x-show="buka" class="inline-flex rounded-xl bg-[#F3F6F5] p-1 text-sm font-semibold" role="tablist">
                    <button type="button" role="tab" @click="tab = 'ringkasan'"
                            :aria-selected="tab === 'ringkasan'"
                            :class="tab === 'ringkasan' ? 'bg-white text-[#365F65] shadow-sm' : 'text-[#7A9290] hover:text-[#365F65]'"
                            class="rounded-lg px-3.5 py-1.5 transition">Ringkasan</button>
                    <button type="button" role="tab" @click="tab = 'denah'"
                            :aria-selected="tab === 'denah'"
                            :class="tab === 'denah' ? 'bg-white text-[#365F65] shadow-sm' : 'text-[#7A9290] hover:text-[#365F65]'"
                            class="rounded-lg px-3.5 py-1.5 transition">Denah Okupansi</button>
                </div>

                <button type="button" @click="buka = !buka" :aria-expanded="buka" aria-label="Buka atau tutup analisis"
                        class="flex h-9 w-9 items-center justify-center rounded-xl text-[#527D82] transition hover:bg-[#F3F6F5]">
                    <svg class="h-5 w-5 transition" :class="buka ? 'rotate-180' : ''" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="m6 9 6 6 6-6"/>
                    </svg>
                </button>
            </div>
        </div>

        <div x-show="buka" x-transition class="border-t border-[#E2EBE9] p-5 sm:p-6">

            
            <div x-show="tab === 'ringkasan'" class="space-y-6">

                <div class="grid grid-cols-1 gap-6 xl:grid-cols-3">

                    
                    <div class="rounded-xl border border-[#E2EBE9] p-5">
                        <h3 class="font-bold text-[#365F65]">Komposisi Status</h3>
                        <p class="mt-1 text-sm text-[#7A9290]">Perbandingan lokasi terisi dan kosong.</p>

                        <div class="mt-5 flex flex-col items-center gap-5">
                            <?php if (isset($component)) { $__componentOriginal0e1bcee2085a0cf16601584b1c042f15 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0e1bcee2085a0cf16601584b1c042f15 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.donut','data' => ['segments' => $segmenStatus,'center' => $totalLokasi,'sub' => 'Total lokasi']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('donut'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['segments' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($segmenStatus),'center' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($totalLokasi),'sub' => 'Total lokasi']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0e1bcee2085a0cf16601584b1c042f15)): ?>
<?php $attributes = $__attributesOriginal0e1bcee2085a0cf16601584b1c042f15; ?>
<?php unset($__attributesOriginal0e1bcee2085a0cf16601584b1c042f15); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0e1bcee2085a0cf16601584b1c042f15)): ?>
<?php $component = $__componentOriginal0e1bcee2085a0cf16601584b1c042f15; ?>
<?php unset($__componentOriginal0e1bcee2085a0cf16601584b1c042f15); ?>
<?php endif; ?>

                            <div class="w-full space-y-3">
                                <div class="flex items-center gap-3">
                                    <span class="h-3 w-3 shrink-0 rounded-full bg-[#D6A14D]"></span>
                                    <span class="flex-1 text-sm text-[#527D82]">Terisi</span>
                                    <span class="text-sm font-bold text-[#365F65]"><?php echo e($totalTerisi); ?></span>
                                    <span class="w-14 text-right text-sm font-semibold text-amber-700"><?php echo e($persentaseTerisi); ?>%</span>
                                </div>
                                <div class="flex items-center gap-3">
                                    <span class="h-3 w-3 shrink-0 rounded-full bg-[#31966A]"></span>
                                    <span class="flex-1 text-sm text-[#527D82]">Kosong</span>
                                    <span class="text-sm font-bold text-[#365F65]"><?php echo e($totalKosong); ?></span>
                                    <span class="w-14 text-right text-sm font-semibold text-emerald-700"><?php echo e($persentaseKosong); ?>%</span>
                                </div>

                                <div class="border-t border-[#E2EBE9] pt-3">
                                    <div class="mb-1.5 flex items-center justify-between text-xs text-[#7A9290]">
                                        <span>Okupansi luas</span>
                                        <span class="font-semibold text-[#365F65]"><?php echo e($persenLuas); ?>%</span>
                                    </div>
                                    <div class="h-2 overflow-hidden rounded-full bg-[#E7EFEC]">
                                        <div class="h-full rounded-full bg-[#365F65]" style="width: <?php echo e($persenLuas); ?>%"></div>
                                    </div>
                                    <p class="mt-1.5 text-xs text-[#8BA5A2]">
                                        <?php echo e($luasFormat($luasTerisi)); ?> dari <?php echo e($luasFormat($totalLuas)); ?> m² terisi
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="rounded-xl border border-[#E2EBE9] p-5">
                        <h3 class="font-bold text-[#365F65]">Okupansi Terminal × Lantai</h3>
                        <p class="mt-1 text-sm text-[#7A9290]">Makin pekat, makin penuh. Klik sel untuk menyaring tabel.</p>

                        <?php if($matriksLantai->isNotEmpty()): ?>
                            <div class="mt-5 overflow-x-auto">
                                <table class="w-full border-separate border-spacing-1 text-center text-xs">
                                    <thead>
                                        <tr>
                                            <th></th>
                                            <?php $__currentLoopData = $daftarLantai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <th class="px-1 pb-1 font-semibold text-[#7A9290]">Lt. <?php echo e($l); ?></th>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $daftarTerminal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th class="pr-2 text-left font-bold text-[#365F65]"><?php echo e($t); ?></th>
                                                <?php $__currentLoopData = $daftarLantai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $sel = $matriksLantai->get($t . '|' . $l);
                                                        $pSel = $sel && $sel->total > 0 ? round(($sel->terisi / $sel->total) * 100) : 0;
                                                    ?>
                                                    <td>
                                                        <?php if($sel): ?>
                                                            <a href="<?php echo e(request()->fullUrlWithQuery(['terminal' => $t, 'lantai' => $l, 'page' => null])); ?>"
                                                               style="<?php echo e($gayaPanas($pSel)); ?>"
                                                               title="<?php echo e($t); ?> Lt. <?php echo e($l); ?>: <?php echo e($sel->terisi); ?> terisi dari <?php echo e($sel->total); ?> ruangan"
                                                               class="block rounded-lg px-2 py-2.5 transition hover:ring-2 hover:ring-[#527D82] <?php echo e($pSel >= 45 ? 'text-white' : 'text-[#365F65]'); ?>">
                                                                <span class="block text-sm font-bold"><?php echo e($pSel); ?>%</span>
                                                                <span class="block text-[10px] opacity-80"><?php echo e($sel->terisi); ?>/<?php echo e($sel->total); ?></span>
                                                            </a>
                                                        <?php else: ?>
                                                            <div class="rounded-lg border border-dashed border-[#DCE6E4] py-3.5 text-[#B6C7C4]">–</div>
                                                        <?php endif; ?>
                                                    </td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                            <div class="mt-4 flex items-center gap-2 text-[11px] text-[#8BA5A2]">
                                <span>0%</span>
                                <span class="h-2 flex-1 rounded-full" style="background: linear-gradient(to right, rgba(54,95,101,.10), rgba(54,95,101,.90));"></span>
                                <span>100%</span>
                            </div>
                        <?php else: ?>
                            <p class="mt-5 rounded-xl bg-[#F8FAF9] px-4 py-8 text-center text-sm text-[#7A9290]">Belum ada data terminal dan lantai.</p>
                        <?php endif; ?>
                    </div>

                    
                    <div class="rounded-xl border border-[#E2EBE9] p-5">
                        <h3 class="font-bold text-[#365F65]">Jenis Usaha Tenant</h3>
                        <p class="mt-1 text-sm text-[#7A9290]">Siapa yang menempati lokasi terisi.</p>

                        <?php if(count($segmenUsaha) > 0): ?>
                            <div class="mt-5 flex flex-col items-center gap-5">
                                <?php if (isset($component)) { $__componentOriginal0e1bcee2085a0cf16601584b1c042f15 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0e1bcee2085a0cf16601584b1c042f15 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.donut','data' => ['segments' => $segmenUsaha,'center' => $totalTerisi,'sub' => 'Lokasi terisi']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('donut'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['segments' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($segmenUsaha),'center' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($totalTerisi),'sub' => 'Lokasi terisi']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0e1bcee2085a0cf16601584b1c042f15)): ?>
<?php $attributes = $__attributesOriginal0e1bcee2085a0cf16601584b1c042f15; ?>
<?php unset($__attributesOriginal0e1bcee2085a0cf16601584b1c042f15); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0e1bcee2085a0cf16601584b1c042f15)): ?>
<?php $component = $__componentOriginal0e1bcee2085a0cf16601584b1c042f15; ?>
<?php unset($__componentOriginal0e1bcee2085a0cf16601584b1c042f15); ?>
<?php endif; ?>

                                <ul class="w-full space-y-2">
                                    <?php $__currentLoopData = $segmenUsaha; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="flex items-center gap-3 text-sm">
                                            <span class="h-3 w-3 shrink-0 rounded-full" style="background: <?php echo e($seg['color']); ?>"></span>
                                            <span class="min-w-0 flex-1 truncate text-[#527D82]"><?php echo e($seg['label']); ?></span>
                                            <span class="font-bold text-[#365F65]"><?php echo e($seg['value']); ?></span>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php else: ?>
                            <p class="mt-5 rounded-xl bg-[#F8FAF9] px-4 py-8 text-center text-sm text-[#7A9290]">Belum ada lokasi yang ditempati tenant.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="grid grid-cols-1 gap-6 xl:grid-cols-2">

                    
                    <div class="rounded-xl border border-[#E2EBE9] p-5">
                        <div class="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
                            <div>
                                <h3 class="font-bold text-[#365F65]">Lokasi per Terminal</h3>
                                <p class="mt-1 text-sm text-[#7A9290]">Jumlah ruangan dan okupansi tiap terminal.</p>
                            </div>
                            <div class="flex items-center gap-4 text-xs text-[#7A9290]">
                                <span class="inline-flex items-center gap-1.5"><span class="h-2.5 w-2.5 rounded-full bg-amber-500"></span>Terisi</span>
                                <span class="inline-flex items-center gap-1.5"><span class="h-2.5 w-2.5 rounded-full bg-emerald-600"></span>Kosong</span>
                            </div>
                        </div>

                        <?php $maksTerminal = max(1, (int) $lokasiPerTerminal->max('total')); ?>

                        <div class="mt-5 space-y-5">
                            <?php $__empty_1 = true; $__currentLoopData = $lokasiPerTerminal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php $kosongItem = $item->total - $item->terisi; ?>
                                <div>
                                    <div class="mb-1.5 flex items-center justify-between gap-3 text-sm">
                                        <a href="<?php echo e(request()->fullUrlWithQuery(['terminal' => $item->terminal, 'page' => null])); ?>"
                                           class="font-semibold text-[#527D82] hover:underline"><?php echo e($item->terminal); ?></a>
                                        <span class="font-bold text-[#365F65]"><?php echo e($item->total); ?> lokasi</span>
                                    </div>
                                    <div class="flex h-3 overflow-hidden rounded-full bg-[#E7EFEC]"
                                         style="width: <?php echo e(max(8, ($item->total / $maksTerminal) * 100)); ?>%"
                                         role="img" aria-label="<?php echo e($item->terminal); ?>: <?php echo e($item->terisi); ?> terisi, <?php echo e($kosongItem); ?> kosong">
                                        <div class="bg-amber-500" style="width: <?php echo e($item->total ? ($item->terisi / $item->total) * 100 : 0); ?>%"></div>
                                        <div class="bg-emerald-600" style="width: <?php echo e($item->total ? ($kosongItem / $item->total) * 100 : 0); ?>%"></div>
                                    </div>
                                    <p class="mt-1 text-xs text-[#8BA5A2]"><?php echo e($item->terisi); ?> terisi · <?php echo e($kosongItem); ?> kosong</p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="rounded-xl bg-[#F8FAF9] px-4 py-8 text-center text-sm text-[#7A9290]">Belum ada data terminal.</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    
                    <div class="rounded-xl border border-[#E2EBE9] p-5">
                        <h3 class="font-bold text-[#365F65]">Lokasi per Jenis Ruangan</h3>
                        <p class="mt-1 text-sm text-[#7A9290]">Klik nama jenis untuk menyaring tabel.</p>

                        <?php $maksJenis = max(1, (int) $lokasiPerJenis->max('total')); ?>

                        <?php if($lokasiPerJenis->isNotEmpty()): ?>
                            <div class="mt-5 space-y-4">
                                <?php $__currentLoopData = $lokasiPerJenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $kosongItem = $item->total - $item->terisi; ?>
                                    <div>
                                        <div class="mb-1.5 flex items-center justify-between gap-3 text-sm">
                                            <a href="<?php echo e(request()->fullUrlWithQuery(['jenis_ruangan' => $item->jenis_ruangan, 'page' => null])); ?>"
                                               class="break-words font-semibold text-[#527D82] hover:underline"><?php echo e($item->jenis_ruangan); ?></a>
                                            <span class="shrink-0 text-xs text-[#8BA5A2]">
                                                <?php echo e($item->terisi); ?>/<?php echo e($item->total); ?> terisi
                                            </span>
                                        </div>
                                        <div class="flex h-3 overflow-hidden rounded-full bg-[#E7EFEC]"
                                             style="width: <?php echo e(max(6, ($item->total / $maksJenis) * 100)); ?>%"
                                             role="img" aria-label="<?php echo e($item->jenis_ruangan); ?>: <?php echo e($item->terisi); ?> terisi, <?php echo e($kosongItem); ?> kosong">
                                            <div class="bg-amber-500" style="width: <?php echo e(($item->terisi / $item->total) * 100); ?>%"></div>
                                            <div class="bg-emerald-600" style="width: <?php echo e(($kosongItem / $item->total) * 100); ?>%"></div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            <p class="mt-5 rounded-xl bg-[#F8FAF9] px-4 py-8 text-center text-sm text-[#7A9290]">Belum ada data jenis ruangan.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            
            <div x-show="tab === 'denah'" style="display: none;" class="space-y-6">

                <div class="flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-[#7A9290]">
                    <span class="inline-flex items-center gap-2">
                        <span class="h-4 w-5 rounded bg-amber-500"></span> Terisi
                    </span>
                    <span class="inline-flex items-center gap-2">
                        <span class="h-4 w-5 rounded bg-emerald-50 ring-1 ring-emerald-300"></span> Kosong
                    </span>
                    <span>Angka di kotak = nomor urut ruangan. Arahkan kursor untuk detail, klik untuk membuka.</span>
                </div>

                <?php $__empty_1 = true; $__currentLoopData = $denah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $namaTerminal => $perLantai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="rounded-xl border border-[#E2EBE9] p-5">
                        <div class="mb-4 flex items-center justify-between gap-3">
                            <h3 class="font-bold text-[#365F65]">Terminal <?php echo e($namaTerminal); ?></h3>
                            <?php
                                $semuaRuang = $perLantai->flatten(1);
                                $terisiT = $semuaRuang->where('status', 'Terisi')->count();
                            ?>
                            <span class="text-xs text-[#8BA5A2]"><?php echo e($terisiT); ?> dari <?php echo e($semuaRuang->count()); ?> ruangan terisi</span>
                        </div>

                        <div class="divide-y divide-[#E2EBE9]">
                            <?php $__currentLoopData = $perLantai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $namaLantai => $ruangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $terisiL = $ruangan->where('status', 'Terisi')->count();
                                    $persenL = round(($terisiL / max(1, $ruangan->count())) * 100);
                                ?>
                                <div class="flex flex-col gap-3 py-4 first:pt-0 last:pb-0 sm:flex-row sm:items-start">
                                    <div class="w-full shrink-0 sm:w-28">
                                        <p class="text-sm font-bold text-[#365F65]"><?php echo e($namaLantai === '-' ? 'Tanpa lantai' : 'Lantai ' . $namaLantai); ?></p>
                                        <p class="text-xs text-[#8BA5A2]"><?php echo e($terisiL); ?>/<?php echo e($ruangan->count()); ?> · <?php echo e($persenL); ?>%</p>
                                        <div class="mt-1.5 h-1.5 overflow-hidden rounded-full bg-[#E7EFEC]">
                                            <div class="h-full rounded-full bg-amber-500" style="width: <?php echo e($persenL); ?>%"></div>
                                        </div>
                                    </div>

                                    <div class="flex flex-1 flex-wrap gap-1.5">
                                        <?php $__currentLoopData = $ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $nomorUrut = last(explode('-', $r->kode_ruang));
                                                $isi = $r->status === 'Terisi';
                                                $infoLuas = $r->luas_area !== null ? ' · ' . number_format((float) $r->luas_area, 0, ',', '.') . ' m²' : '';
                                            ?>
                                            <a href="<?php echo e(route('lokasi.show', $r->id)); ?>"
                                               title="<?php echo e($r->kode_ruang); ?> · <?php echo e($r->jenis_ruangan ?: 'Tanpa jenis'); ?><?php echo e($infoLuas); ?> · <?php echo e($isi ? 'Terisi' : 'Kosong'); ?>"
                                               class="flex h-8 min-w-9 items-center justify-center rounded-md px-1 text-[10px] font-bold tabular-nums transition hover:-translate-y-0.5 hover:shadow
                                                      <?php echo e($isi ? 'bg-amber-500 text-white' : 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-300'); ?>">
                                                <?php echo e($nomorUrut); ?>

                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="rounded-xl bg-[#F8FAF9] px-4 py-10 text-center text-sm text-[#7A9290]">Belum ada ruangan untuk digambarkan.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    
    <form method="GET" action="<?php echo e(route('lokasi.index')); ?>"
          class="rounded-2xl border border-[#E2EBE9] bg-white p-4 shadow-sm sm:p-5">

        <div class="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-6">

            <div class="sm:col-span-2 lg:col-span-2">
                <label for="search" class="mb-1 block text-xs font-semibold text-[#527D82]">Pencarian</label>
                <div class="relative">
                    <svg class="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#8BA5A2]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                        <circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>
                    </svg>
                    <input type="search" id="search" name="search" value="<?php echo e(request('search')); ?>"
                           placeholder="Kode, lokasi, nomor RO, atau nama tenant…"
                           class="<?php echo e($kelasInput); ?> pl-10">
                </div>
            </div>

            <div>
                <label for="terminal" class="mb-1 block text-xs font-semibold text-[#527D82]">Terminal</label>
                <select id="terminal" name="terminal" onchange="this.form.submit()" class="<?php echo e($kelasInput); ?>">
                    <option value="">Semua</option>
                    <?php $__currentLoopData = $pilihanTerminal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($t); ?>" <?php if(request('terminal') === $t): echo 'selected'; endif; ?>><?php echo e($t); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <label for="lantai" class="mb-1 block text-xs font-semibold text-[#527D82]">Lantai</label>
                <select id="lantai" name="lantai" onchange="this.form.submit()" class="<?php echo e($kelasInput); ?>">
                    <option value="">Semua</option>
                    <?php $__currentLoopData = $pilihanLantai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($l); ?>" <?php if((string) request('lantai') === (string) $l): echo 'selected'; endif; ?>>Lantai <?php echo e($l); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <label for="jenis_ruangan" class="mb-1 block text-xs font-semibold text-[#527D82]">Jenis</label>
                <select id="jenis_ruangan" name="jenis_ruangan" onchange="this.form.submit()" class="<?php echo e($kelasInput); ?>">
                    <option value="">Semua</option>
                    <?php $__currentLoopData = $pilihanJenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($j); ?>" <?php if(request('jenis_ruangan') === $j): echo 'selected'; endif; ?>><?php echo e($j); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <label for="status" class="mb-1 block text-xs font-semibold text-[#527D82]">Status</label>
                <select id="status" name="status" onchange="this.form.submit()" class="<?php echo e($kelasInput); ?>">
                    <option value="">Semua</option>
                    <option value="Kosong" <?php if(request('status') === 'Kosong'): echo 'selected'; endif; ?>>Kosong</option>
                    <option value="Terisi" <?php if(request('status') === 'Terisi'): echo 'selected'; endif; ?>>Terisi</option>
                </select>
            </div>
        </div>

        <div class="mt-3 flex flex-wrap items-end justify-between gap-3">
            <div class="flex flex-wrap items-end gap-3">
                <div>
                    <label for="sort" class="mb-1 block text-xs font-semibold text-[#527D82]">Urutkan</label>
                    <select id="sort" name="sort" onchange="this.form.submit()" class="<?php echo e($kelasInput); ?>">
                        <option value="newest" <?php if($sortAktif === 'newest'): echo 'selected'; endif; ?>>Terbaru</option>
                        <option value="oldest" <?php if($sortAktif === 'oldest'): echo 'selected'; endif; ?>>Terlama</option>
                        <option value="az" <?php if($sortAktif === 'az'): echo 'selected'; endif; ?>>Kode A–Z</option>
                        <option value="za" <?php if($sortAktif === 'za'): echo 'selected'; endif; ?>>Kode Z–A</option>
                        <option value="luas_desc" <?php if($sortAktif === 'luas_desc'): echo 'selected'; endif; ?>>Luas terbesar</option>
                        <option value="luas_asc" <?php if($sortAktif === 'luas_asc'): echo 'selected'; endif; ?>>Luas terkecil</option>
                    </select>
                </div>

                <div>
                    <label for="per_page" class="mb-1 block text-xs font-semibold text-[#527D82]">Per halaman</label>
                    <select id="per_page" name="per_page" onchange="this.form.submit()" class="<?php echo e($kelasInput); ?>">
                        <?php $__currentLoopData = [10, 15, 25, 50, 100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($n); ?>" <?php if($perPage === $n): echo 'selected'; endif; ?>><?php echo e($n); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="flex items-center gap-2">
                <?php if($filterAktif->isNotEmpty()): ?>
                    <a href="<?php echo e(route('lokasi.index')); ?>"
                       class="inline-flex items-center rounded-xl border border-[#DCE6E4] px-4 py-2.5 text-sm font-semibold text-[#527D82] transition hover:bg-[#F5F8F7]">
                        Reset
                    </a>
                <?php endif; ?>
                <button type="submit"
                        class="inline-flex items-center rounded-xl bg-[#365F65] px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-[#294F55]">
                    Cari
                </button>
            </div>
        </div>

        <?php if($filterAktif->isNotEmpty()): ?>
            <div class="mt-3 flex flex-wrap items-center gap-2 border-t border-[#E2EBE9] pt-3">
                <span class="text-xs text-[#8BA5A2]">Filter aktif:</span>
                <?php $__currentLoopData = $filterAktif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(request()->fullUrlWithQuery([$key => null, 'page' => null])); ?>"
                       class="inline-flex items-center gap-1.5 rounded-full bg-[#EAF2F1] px-3 py-1 text-xs font-semibold text-[#365F65] transition hover:bg-[#DCE9E7]"
                       title="Hapus filter ini">
                        <?php echo e($label); ?>: <?php echo e(request($key)); ?>

                        <span aria-hidden="true">×</span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </form>

    
    <section class="overflow-hidden rounded-2xl border border-[#E2EBE9] bg-white shadow-sm">

        <div class="flex flex-col gap-1 border-b border-[#E2EBE9] px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="font-bold text-[#365F65]">Daftar Ruangan</h2>
                <p class="mt-0.5 text-sm text-[#8BA5A2]">
                    <?php if($lokasis->total() > 0): ?>
                        Menampilkan <?php echo e($lokasis->firstItem()); ?>–<?php echo e($lokasis->lastItem()); ?>

                        dari <?php echo e(number_format($lokasis->total(), 0, ',', '.')); ?> lokasi
                        <?php if($filterAktif->isNotEmpty()): ?> (sesuai filter) <?php endif; ?>
                    <?php else: ?>
                        Tidak ada lokasi yang cocok.
                    <?php endif; ?>
                </p>
            </div>
            <p class="text-xs text-[#8BA5A2]">
                Hapus hanya tersedia untuk lokasi yang masih kosong.
            </p>
        </div>

        
        <div class="hidden max-h-[680px] overflow-auto md:block">
            <table class="w-full text-left text-sm">
                <thead class="sticky top-0 z-10 bg-[#F3F6F5] text-xs uppercase tracking-wide text-[#527D82]">
                    <tr>
                        <th class="whitespace-nowrap px-4 py-3.5 font-semibold">No.</th>
                        <th class="whitespace-nowrap px-4 py-3.5 font-semibold">
                            <a href="<?php echo e($urlUrut('az', 'za')); ?>" class="inline-flex items-center gap-1 hover:text-[#294F55]">
                                Kode &amp; Lokasi <span><?php echo e($panahUrut('az', 'za')); ?></span>
                            </a>
                        </th>
                        <th class="whitespace-nowrap px-4 py-3.5 font-semibold">Tenant</th>
                        <th class="whitespace-nowrap px-4 py-3.5 font-semibold">Terminal / Lantai</th>
                        <th class="whitespace-nowrap px-4 py-3.5 font-semibold">Jenis</th>
                        <th class="whitespace-nowrap px-4 py-3.5 text-right font-semibold">
                            <a href="<?php echo e($urlUrut('luas_desc', 'luas_asc')); ?>" class="inline-flex items-center gap-1 hover:text-[#294F55]">
                                Luas (m²) <span><?php echo e($panahUrut('luas_desc', 'luas_asc')); ?></span>
                            </a>
                        </th>
                        <th class="whitespace-nowrap px-4 py-3.5 font-semibold">Status</th>
                        <th class="whitespace-nowrap px-4 py-3.5 text-right font-semibold">Aksi</th>
                    </tr>
                </thead>

                <tbody class="divide-y divide-[#E2EBE9]">
                    <?php $__empty_1 = true; $__currentLoopData = $lokasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lokasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $terisi = $lokasi->status === 'Terisi';
                            $namaTenant = $lokasi->tenant?->nama_tenant
                                ?? $lokasi->tenant?->mitra_usaha;
                            $bisaHapus = $lokasi->status === 'Kosong' && $lokasi->tenant_id === null;
                        ?>
                        <tr class="transition hover:bg-[#F8FAF9]">
                            <td class="whitespace-nowrap px-4 py-3.5 text-[#8BA5A2]">
                                <?php echo e($lokasis->firstItem() + $loop->index); ?>

                            </td>

                            <td class="min-w-52 px-4 py-3.5">
                                <a href="<?php echo e(route('lokasi.show', $lokasi->id)); ?>"
                                   class="font-semibold text-[#365F65] hover:underline">
                                    <?php echo e($lokasi->kode_tampilan ?? $lokasi->kode_ruang); ?>

                                </a>
                                <p class="mt-0.5 text-xs text-[#7A9290]"><?php echo e($lokasi->lokasi ?: '-'); ?></p>
                                <?php if($lokasi->tenant_id && $lokasi->kode_tampilan && $lokasi->kode_tampilan !== $lokasi->kode_ruang): ?>
                                    <p class="mt-0.5 text-[11px] text-[#8BA5A2]">Kode asli: <?php echo e($lokasi->kode_ruang); ?></p>
                                <?php endif; ?>
                            </td>

                            <td class="min-w-40 px-4 py-3.5">
                                <?php if($lokasi->tenant): ?>
                                    <a href="<?php echo e(route('tenant.show', $lokasi->tenant->id)); ?>"
                                       class="font-medium text-[#365F65] hover:underline">
                                        <?php echo e($namaTenant ?: 'Tenant #' . $lokasi->tenant->id); ?>

                                    </a>
                                <?php else: ?>
                                    <span class="text-[#8BA5A2]">Belum ditempati</span>
                                <?php endif; ?>
                            </td>

                            <td class="whitespace-nowrap px-4 py-3.5 text-[#527D82]">
                                <?php echo e($lokasi->terminal ?: '-'); ?>

                                <span class="text-[#B6C7C4]">·</span>
                                <?php echo e($lokasi->lantai ? 'Lt. ' . $lokasi->lantai : '-'); ?>

                            </td>

                            <td class="whitespace-nowrap px-4 py-3.5">
                                <?php if($lokasi->jenis_ruangan): ?>
                                    <span class="rounded-md bg-[#F3F6F5] px-2 py-1 text-xs font-medium text-[#527D82]">
                                        <?php echo e($lokasi->jenis_ruangan); ?>

                                    </span>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>

                            <td class="whitespace-nowrap px-4 py-3.5 text-right tabular-nums">
                                <?php echo e($lokasi->luas_area !== null
                                    ? number_format((float) $lokasi->luas_area, 2, ',', '.')
                                    : '-'); ?>

                            </td>

                            <td class="whitespace-nowrap px-4 py-3.5">
                                <span class="inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold
                                    <?php echo e($terisi ? 'bg-amber-50 text-amber-700' : 'bg-emerald-50 text-emerald-700'); ?>">
                                    <span class="h-1.5 w-1.5 rounded-full <?php echo e($terisi ? 'bg-amber-500' : 'bg-emerald-500'); ?>"></span>
                                    <?php echo e($terisi ? 'Terisi' : 'Kosong'); ?>

                                </span>
                            </td>

                            <td class="whitespace-nowrap px-4 py-3.5">
                                <div class="flex items-center justify-end gap-1.5">
                                    <a href="<?php echo e(route('lokasi.show', $lokasi->id)); ?>" title="Lihat detail" aria-label="Lihat detail <?php echo e($lokasi->kode_ruang); ?>"
                                       class="flex h-8 w-8 items-center justify-center rounded-lg text-[#527D82] transition hover:bg-[#EAF2F1]">
                                        <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">
                                            <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>
                                        </svg>
                                    </a>
                                    <a href="<?php echo e(route('lokasi.edit', $lokasi->id)); ?>" title="Edit lokasi" aria-label="Edit <?php echo e($lokasi->kode_ruang); ?>"
                                       class="flex h-8 w-8 items-center justify-center rounded-lg text-amber-700 transition hover:bg-amber-50">
                                        <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">
                                            <path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>
                                        </svg>
                                    </a>
                                    <?php if($bisaHapus): ?>
                                        <form action="<?php echo e(route('lokasi.destroy', $lokasi->id)); ?>" method="POST"
                                              onsubmit="return confirm('Hapus lokasi <?php echo e($lokasi->kode_ruang); ?>? Tindakan ini tidak dapat dibatalkan.');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" title="Hapus lokasi" aria-label="Hapus <?php echo e($lokasi->kode_ruang); ?>"
                                                    class="flex h-8 w-8 items-center justify-center rounded-lg text-red-600 transition hover:bg-red-50">
                                                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">
                                                    <path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 10v6M14 10v6"/>
                                                </svg>
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span title="Lokasi terisi tidak dapat dihapus" aria-label="Tidak dapat dihapus"
                                              class="flex h-8 w-8 cursor-not-allowed items-center justify-center rounded-lg text-[#C4D2CF]">
                                            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">
                                                <rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>
                                            </svg>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="px-4 py-14 text-center">
                                <p class="font-semibold text-[#365F65]">Lokasi tidak ditemukan</p>
                                <p class="mt-1 text-sm text-[#8BA5A2]">
                                    <?php if($filterAktif->isNotEmpty()): ?>
                                        Coba ubah kata pencarian atau hapus sebagian filter.
                                    <?php else: ?>
                                        Belum ada lokasi. Mulai dengan menambahkan ruangan pertama.
                                    <?php endif; ?>
                                </p>
                                <div class="mt-4 flex items-center justify-center gap-3">
                                    <?php if($filterAktif->isNotEmpty()): ?>
                                        <a href="<?php echo e(route('lokasi.index')); ?>" class="text-sm font-semibold text-[#527D82] hover:underline">Reset filter</a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('lokasi.create')); ?>" class="rounded-xl bg-[#365F65] px-4 py-2 text-sm font-semibold text-white hover:bg-[#294F55]">+ Tambah Lokasi</a>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        
        <div class="divide-y divide-[#E2EBE9] md:hidden">
            <?php $__empty_1 = true; $__currentLoopData = $lokasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lokasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $terisi = $lokasi->status === 'Terisi';
                    $namaTenant = $lokasi->tenant?->nama_tenant ?? $lokasi->tenant?->mitra_usaha;
                    $bisaHapus = $lokasi->status === 'Kosong' && $lokasi->tenant_id === null;
                ?>
                <div class="p-4">
                    <div class="flex items-start justify-between gap-3">
                        <div class="min-w-0">
                            <a href="<?php echo e(route('lokasi.show', $lokasi->id)); ?>" class="font-semibold text-[#365F65]">
                                <?php echo e($lokasi->kode_tampilan ?? $lokasi->kode_ruang); ?>

                            </a>
                            <p class="mt-0.5 break-words text-xs text-[#7A9290]"><?php echo e($lokasi->lokasi ?: '-'); ?></p>
                        </div>
                        <span class="inline-flex shrink-0 items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold
                            <?php echo e($terisi ? 'bg-amber-50 text-amber-700' : 'bg-emerald-50 text-emerald-700'); ?>">
                            <span class="h-1.5 w-1.5 rounded-full <?php echo e($terisi ? 'bg-amber-500' : 'bg-emerald-500'); ?>"></span>
                            <?php echo e($terisi ? 'Terisi' : 'Kosong'); ?>

                        </span>
                    </div>

                    <dl class="mt-3 grid grid-cols-2 gap-x-4 gap-y-2 text-xs">
                        <div><dt class="text-[#8BA5A2]">Terminal / Lantai</dt>
                            <dd class="font-medium text-[#365F65]"><?php echo e($lokasi->terminal ?: '-'); ?> · <?php echo e($lokasi->lantai ? 'Lt. ' . $lokasi->lantai : '-'); ?></dd></div>
                        <div><dt class="text-[#8BA5A2]">Jenis</dt>
                            <dd class="font-medium text-[#365F65]"><?php echo e($lokasi->jenis_ruangan ?: '-'); ?></dd></div>
                        <div><dt class="text-[#8BA5A2]">Luas</dt>
                            <dd class="font-medium text-[#365F65]"><?php echo e($lokasi->luas_area !== null ? number_format((float) $lokasi->luas_area, 2, ',', '.') . ' m²' : '-'); ?></dd></div>
                        <div><dt class="text-[#8BA5A2]">Tenant</dt>
                            <dd class="font-medium text-[#365F65]"><?php echo e($namaTenant ?: 'Belum ditempati'); ?></dd></div>
                    </dl>

                    <div class="mt-3 flex items-center gap-4 text-sm font-semibold">
                        <a href="<?php echo e(route('lokasi.show', $lokasi->id)); ?>" class="text-[#527D82]">Detail</a>
                        <a href="<?php echo e(route('lokasi.edit', $lokasi->id)); ?>" class="text-amber-700">Edit</a>
                        <?php if($bisaHapus): ?>
                            <form action="<?php echo e(route('lokasi.destroy', $lokasi->id)); ?>" method="POST"
                                  onsubmit="return confirm('Hapus lokasi <?php echo e($lokasi->kode_ruang); ?>?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600">Hapus</button>
                            </form>
                        <?php else: ?>
                            <span class="text-xs font-normal text-[#B6C7C4]">Terisi, tidak dapat dihapus</span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="px-4 py-12 text-center">
                    <p class="font-semibold text-[#365F65]">Lokasi tidak ditemukan</p>
                    <a href="<?php echo e(route('lokasi.index')); ?>" class="mt-2 inline-block text-sm font-semibold text-[#527D82] hover:underline">Reset filter</a>
                </div>
            <?php endif; ?>
        </div>

        <?php if($lokasis->hasPages()): ?>
            <div class="border-t border-[#E2EBE9] px-5 py-4">
                <?php echo e($lokasis->links()); ?>

            </div>
        <?php endif; ?>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\AeroTrack\resources\views/lokasi/index.blade.php ENDPATH**/ ?>