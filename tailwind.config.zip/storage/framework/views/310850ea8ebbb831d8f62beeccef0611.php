<?php $__env->startSection('page-title', 'Notifikasi'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $jenisInfo = \App\Services\NotifikasiService::JENIS;

    $chip = function (bool $aktif) {
        return 'inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-xs font-semibold transition '
            . ($aktif ? 'bg-[#365F65] text-white' : 'bg-[#F3F6F5] text-[#527D82] hover:bg-[#E8F0EE]');
    };

    $adaFilter = $tampil === 'belum' || $kategori || $jenis;
    $gayaLevel = [
        'penting' => ['teks' => 'Mendesak', 'kelas' => 'bg-red-50 text-red-700'],
        'sedang' => ['teks' => 'Perlu tindakan', 'kelas' => 'bg-amber-50 text-amber-700'],
        'info' => ['teks' => 'Informasi', 'kelas' => 'bg-[#EAF2F1] text-[#365F65]'],
    ];
?>

<div class="space-y-6">

    
    <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
            <p class="text-sm text-[#8BA5A2]">AeroTrack / Notifikasi</p>
            <h1 class="mt-1 text-2xl font-bold text-[#365F65]">Notifikasi</h1>
            <p class="mt-1 text-sm text-[#7A9290]">Hal-hal yang perlu perhatian dari data kontrak, aktivasi, dan lokasi.</p>
        </div>

        <div class="flex flex-wrap items-center gap-2">
            <a href="<?php echo e(route('profile.index')); ?>#preferensi"
               class="inline-flex items-center justify-center rounded-xl border border-[#DCE6E4] bg-white px-4 py-2.5 text-sm font-semibold text-[#527D82] transition hover:bg-[#F5F8F7]">
                Atur notifikasi
            </a>

            <?php if($belumDibaca > 0): ?>
                <form action="<?php echo e(route('notifikasi.baca-semua')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit"
                            class="inline-flex items-center justify-center rounded-xl bg-[#365F65] px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-[#294F55]">
                        Tandai semua dibaca
                    </button>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <?php $__currentLoopData = ['success' => 'border-emerald-200 bg-emerald-50 text-emerald-800', 'info' => 'border-blue-200 bg-blue-50 text-blue-800']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipe => $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(session($tipe)): ?>
            <div class="rounded-xl border px-4 py-3 text-sm <?php echo e($kelas); ?>" role="status"><?php echo e(session($tipe)); ?></div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <section class="grid grid-cols-1 gap-3 sm:grid-cols-3 sm:gap-4" aria-label="Ringkasan notifikasi">
        <div class="rounded-2xl border border-[#E2EBE9] bg-white p-5 shadow-sm">
            <p class="text-sm font-medium text-[#7A9290]">Belum dibaca</p>
            <p class="mt-2 text-3xl font-bold text-[#365F65]"><?php echo e($belumDibaca); ?></p>
            <p class="mt-1 text-xs text-[#8BA5A2]">dari <?php echo e($total); ?> notifikasi aktif</p>
        </div>

        <div class="rounded-2xl border border-[#E2EBE9] bg-white p-5 shadow-sm">
            <p class="text-sm font-medium text-[#7A9290]">Perlu tindakan</p>
            <p class="mt-2 text-3xl font-bold text-amber-700"><?php echo e($perTindakan); ?></p>
            <p class="mt-1 text-xs text-[#8BA5A2]">belum dibaca, butuh dikerjakan</p>
        </div>

        <div class="rounded-2xl border border-[#E2EBE9] bg-white p-5 shadow-sm">
            <p class="mb-3 text-sm font-medium text-[#7A9290]">Sebaran jenis</p>
            <?php if($total > 0): ?>
                <div class="flex h-3 overflow-hidden rounded-full bg-[#E7EFEC]" role="img" aria-label="Sebaran jenis notifikasi">
                    <?php $__currentLoopData = $jenisInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kode => $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $n = $perJenis[$kode] ?? 0; ?>
                        <?php if($n > 0): ?>
                            <div style="width: <?php echo e(($n / $total) * 100); ?>%; background: <?php echo e($info['kategori'] === 'tindakan' ? '#D6A14D' : '#527D82'); ?>; opacity: <?php echo e(0.55 + (array_search($kode, array_keys($jenisInfo)) % 3) * 0.2); ?>"
                                 title="<?php echo e($info['label']); ?>: <?php echo e($n); ?>"></div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="mt-2 flex items-center gap-4 text-xs text-[#7A9290]">
                    <span class="inline-flex items-center gap-1.5"><span class="h-2.5 w-2.5 rounded-full bg-[#D6A14D]"></span>Perlu tindakan</span>
                    <span class="inline-flex items-center gap-1.5"><span class="h-2.5 w-2.5 rounded-full bg-[#527D82]"></span>Informasi</span>
                </div>
            <?php else: ?>
                <p class="text-sm text-[#8BA5A2]">Belum ada data.</p>
            <?php endif; ?>
        </div>
    </section>

    
    <section class="rounded-2xl border border-[#E2EBE9] bg-white p-4 shadow-sm sm:p-5">
        <div class="flex flex-wrap items-center gap-2">
            <a href="<?php echo e(request()->fullUrlWithQuery(['tampil' => null])); ?>" class="<?php echo e($chip($tampil === 'semua')); ?>">Semua</a>
            <a href="<?php echo e(request()->fullUrlWithQuery(['tampil' => 'belum'])); ?>" class="<?php echo e($chip($tampil === 'belum')); ?>">
                Belum dibaca
                <?php if($belumDibaca > 0): ?>
                    <span class="rounded-full bg-white/25 px-1.5 text-[10px]"><?php echo e($belumDibaca); ?></span>
                <?php endif; ?>
            </a>

            <span class="mx-1 hidden h-5 w-px bg-[#E2EBE9] sm:block"></span>

            <a href="<?php echo e(request()->fullUrlWithQuery(['kategori' => $kategori === 'tindakan' ? null : 'tindakan', 'jenis' => null])); ?>"
               class="<?php echo e($chip($kategori === 'tindakan')); ?>">Perlu tindakan</a>
            <a href="<?php echo e(request()->fullUrlWithQuery(['kategori' => $kategori === 'info' ? null : 'info', 'jenis' => null])); ?>"
               class="<?php echo e($chip($kategori === 'info')); ?>">Informasi</a>
        </div>

        <div class="mt-3 flex flex-wrap items-center gap-2 border-t border-[#E2EBE9] pt-3">
            <span class="text-xs text-[#8BA5A2]">Jenis:</span>
            <?php $__currentLoopData = $jenisInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kode => $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(! ($jenisAktif[$kode] ?? true)) continue; ?>
                <a href="<?php echo e(request()->fullUrlWithQuery(['jenis' => $jenis === $kode ? null : $kode, 'kategori' => null])); ?>"
                   class="<?php echo e($chip($jenis === $kode)); ?>">
                    <?php echo e($info['label']); ?>

                    <span class="opacity-70"><?php echo e($perJenis[$kode] ?? 0); ?></span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if($adaFilter): ?>
                <a href="<?php echo e(route('notifikasi.index')); ?>" class="ml-auto text-xs font-semibold text-[#527D82] hover:underline">Reset filter</a>
            <?php endif; ?>
        </div>
    </section>

    
    <section class="overflow-hidden rounded-2xl border border-[#E2EBE9] bg-white shadow-sm">
        <div class="border-b border-[#E2EBE9] px-5 py-4">
            <h2 class="font-bold text-[#365F65]">Daftar Notifikasi</h2>
            <p class="mt-0.5 text-sm text-[#8BA5A2]">
                <?php echo e($daftar->count()); ?> notifikasi<?php echo e($adaFilter ? ' sesuai filter' : ''); ?>. Klik untuk membuka halaman terkait.
            </p>
        </div>

        <div class="divide-y divide-[#E2EBE9]">
            <?php $__empty_1 = true; $__currentLoopData = $daftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php $gaya = $gayaLevel[$n['level']] ?? $gayaLevel['info']; ?>
                <div class="flex items-start gap-4 px-5 py-4 transition hover:bg-[#F8FAF9] <?php echo e($n['dibaca'] ? '' : 'bg-[#F8FBFA]'); ?>">
                    <?php if (isset($component)) { $__componentOriginal6ebcfe4cdda59dadbf9997ea22f8f370 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6ebcfe4cdda59dadbf9997ea22f8f370 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.notif-icon','data' => ['jenis' => $n['jenis'],'level' => $n['level'],'ukuran' => 'h-10 w-10']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('notif-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['jenis' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($n['jenis']),'level' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($n['level']),'ukuran' => 'h-10 w-10']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6ebcfe4cdda59dadbf9997ea22f8f370)): ?>
<?php $attributes = $__attributesOriginal6ebcfe4cdda59dadbf9997ea22f8f370; ?>
<?php unset($__attributesOriginal6ebcfe4cdda59dadbf9997ea22f8f370); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6ebcfe4cdda59dadbf9997ea22f8f370)): ?>
<?php $component = $__componentOriginal6ebcfe4cdda59dadbf9997ea22f8f370; ?>
<?php unset($__componentOriginal6ebcfe4cdda59dadbf9997ea22f8f370); ?>
<?php endif; ?>

                    <a href="<?php echo e(route('notifikasi.buka', ['k' => $n['kunci']])); ?>" class="min-w-0 flex-1">
                        <div class="flex flex-wrap items-center gap-2">
                            <p class="text-sm text-[#365F65] <?php echo e($n['dibaca'] ? 'font-medium' : 'font-bold'); ?>"><?php echo e($n['judul']); ?></p>
                            <?php if (! ($n['dibaca'])): ?>
                                <span class="h-2 w-2 rounded-full bg-[#4F8189]" title="Belum dibaca"></span>
                            <?php endif; ?>
                        </div>
                        <p class="mt-1 text-sm text-[#7A9290]"><?php echo e($n['pesan']); ?></p>
                        <div class="mt-2 flex flex-wrap items-center gap-2 text-xs">
                            <span class="rounded-full px-2.5 py-1 font-semibold <?php echo e($gaya['kelas']); ?>"><?php echo e($gaya['teks']); ?></span>
                            <span class="rounded-full bg-[#F3F6F5] px-2.5 py-1 font-medium text-[#527D82]"><?php echo e($jenisInfo[$n['jenis']]['label']); ?></span>
                            <span class="text-[#8BA5A2]"><?php echo e(\Illuminate\Support\Carbon::parse($n['waktu'])->locale('id')->isoFormat('D MMM YYYY')); ?></span>
                        </div>
                    </a>

                    <?php if (! ($n['dibaca'])): ?>
                        <form action="<?php echo e(route('notifikasi.baca')); ?>" method="POST" class="shrink-0">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="kunci" value="<?php echo e($n['kunci']); ?>">
                            <button type="submit" title="Tandai dibaca" aria-label="Tandai dibaca"
                                    class="flex h-9 w-9 items-center justify-center rounded-lg text-[#527D82] transition hover:bg-[#EAF2F1]">
                                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 4 4L19 6"/></svg>
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="px-5 py-16 text-center">
                    <p class="font-semibold text-[#365F65]">
                        <?php echo e($adaFilter ? 'Tidak ada notifikasi yang cocok' : 'Tidak ada notifikasi'); ?>

                    </p>
                    <p class="mt-1 text-sm text-[#8BA5A2]">
                        <?php echo e($adaFilter ? 'Coba ubah atau reset filter.' : 'Semua urusan kontrak dan aktivasi sedang beres.'); ?>

                    </p>
                    <?php if($adaFilter): ?>
                        <a href="<?php echo e(route('notifikasi.index')); ?>" class="mt-3 inline-block text-sm font-semibold text-[#527D82] hover:underline">Reset filter</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\AeroTrack\resources\views/notifikasi/index.blade.php ENDPATH**/ ?>