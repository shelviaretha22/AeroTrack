<?php $__env->startSection('page-title', 'Edit Lokasi'); ?>

<?php $__env->startSection('content'); ?>
<div class="w-full max-w-none space-y-6">

    
    <div>
        <p class="text-sm text-[#8BA5A2]">Management / Lokasi / Edit</p>

        <h1 class="mt-1 text-2xl font-bold text-[#365F65]">
            Edit Lokasi
        </h1>

        <p class="mt-1 text-sm text-[#7A9290]">
            Perbarui informasi lokasi tenant bandara.
        </p>
    </div>

    
    <div class="w-full rounded-2xl border border-[#E2EBE9] bg-white p-6 sm:p-8">
        <div class="flex flex-wrap items-center justify-between gap-4">
            <div>
                <p class="text-sm text-[#8BA5A2]">Kode Ruang Asli</p>

                <h2 class="mt-1 text-xl font-bold text-[#365F65]">
                    <?php echo e($lokasi->kode_ruang); ?>

                </h2>

                <p class="mt-1 text-xs text-[#7A9290]">
                    Kode ruang tidak berubah ketika data lokasi diedit.
                </p>
            </div>

            <?php if($lokasi->status === 'Terisi'): ?>
                <span class="rounded-full bg-blue-50 px-4 py-2 text-sm font-semibold text-blue-700">
                    Terisi
                </span>
            <?php else: ?>
                <span class="rounded-full bg-emerald-50 px-4 py-2 text-sm font-semibold text-emerald-700">
                    <?php echo e($lokasi->status ?? 'Kosong'); ?>

                </span>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="w-full rounded-2xl border border-[#E2EBE9] bg-white p-6 sm:p-8 lg:p-10">

        <?php if($errors->any()): ?>
            <div class="mb-6 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
                <p class="font-semibold">Data belum berhasil disimpan.</p>
                <ul class="mt-2 list-inside list-disc">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('lokasi.update', $lokasi)); ?>"
              method="POST"
              class="space-y-6">

            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div>
                <h2 class="text-base font-bold text-[#365F65]">
                    Informasi Ruangan
                </h2>

                <p class="mt-1 text-sm text-[#8BA5A2]">
                    Pastikan informasi ruangan sudah sesuai sebelum menyimpan perubahan.
                </p>
            </div>

            <div class="grid grid-cols-1 gap-x-6 gap-y-5 md:grid-cols-2 xl:grid-cols-3">

                
                <div>
                    <label for="terminal"
                           class="mb-2 block text-sm font-semibold text-[#365F65]">
                        Terminal <span class="text-red-500">*</span>
                    </label>

                    <select id="terminal"
                            name="terminal"
                            required
                            class="w-full rounded-xl border border-[#DCE6E4] bg-[#F8FAF9] px-4 py-3 text-sm text-[#365F65] outline-none focus:border-[#527D82] focus:ring-2 focus:ring-[#527D82]/20">
                        <option value="">Pilih Terminal</option>
                        <option value="T1"
                            <?php echo e(old('terminal', $lokasi->terminal) === 'T1' ? 'selected' : ''); ?>>
                            Terminal 1
                        </option>
                        <option value="T2"
                            <?php echo e(old('terminal', $lokasi->terminal) === 'T2' ? 'selected' : ''); ?>>
                            Terminal 2
                        </option>
                    </select>

                    <?php $__errorArgs = ['terminal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div>
                    <label for="lantai"
                           class="mb-2 block text-sm font-semibold text-[#365F65]">
                        Lantai <span class="text-red-500">*</span>
                    </label>

                    <input type="text"
                           id="lantai"
                           name="lantai"
                           value="<?php echo e(old('lantai', $lokasi->lantai)); ?>"
                           placeholder="Contoh: 1"
                           required
                           class="w-full rounded-xl border border-[#DCE6E4] bg-[#F8FAF9] px-4 py-3 text-sm text-[#365F65] placeholder:text-[#A3B5B2] outline-none focus:border-[#527D82] focus:ring-2 focus:ring-[#527D82]/20">

                    <?php $__errorArgs = ['lantai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div>
                    <label for="jenis_ruangan"
                           class="mb-2 block text-sm font-semibold text-[#365F65]">
                        Jenis Ruangan <span class="text-red-500">*</span>
                    </label>

                    <select id="jenis_ruangan"
                            name="jenis_ruangan"
                            required
                            class="w-full rounded-xl border border-[#DCE6E4] bg-[#F8FAF9] px-4 py-3 text-sm text-[#365F65] outline-none focus:border-[#527D82] focus:ring-2 focus:ring-[#527D82]/20">
                        <option value="">Pilih Jenis Ruangan</option>

                        <?php $__currentLoopData = [
                            'Retail',
                            'F&B',
                            'Service',
                            'Lounge',
                            'Duty Free',
                            'UMKM',
                            'Kantor',
                            'Gudang',
                            'Lainnya'
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($jenis); ?>"
                                <?php echo e(old('jenis_ruangan', $lokasi->jenis_ruangan) === $jenis ? 'selected' : ''); ?>>
                                <?php echo e($jenis); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                        <?php if(
                            $lokasi->jenis_ruangan &&
                            !in_array($lokasi->jenis_ruangan, [
                                'Retail', 'F&B', 'Service', 'Lounge',
                                'Duty Free', 'UMKM', 'Kantor',
                                'Gudang', 'Lainnya'
                            ])
                        ): ?>
                            <option value="<?php echo e($lokasi->jenis_ruangan); ?>"
                                selected>
                                <?php echo e($lokasi->jenis_ruangan); ?>

                            </option>
                        <?php endif; ?>
                    </select>

                    <?php $__errorArgs = ['jenis_ruangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div>
                    <label for="nomor_ro"
                           class="mb-2 block text-sm font-semibold text-[#365F65]">
                        Nomor RO
                    </label>

                    <input type="text"
                           id="nomor_ro"
                           name="nomor_ro"
                           value="<?php echo e(old('nomor_ro', $lokasi->nomor_ro)); ?>"
                           placeholder="Masukkan nomor RO"
                           class="w-full rounded-xl border border-[#DCE6E4] bg-[#F8FAF9] px-4 py-3 text-sm text-[#365F65] placeholder:text-[#A3B5B2] outline-none focus:border-[#527D82] focus:ring-2 focus:ring-[#527D82]/20">

                    <?php $__errorArgs = ['nomor_ro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="md:col-span-2 xl:col-span-2">
                    <label for="lokasi"
                           class="mb-2 block text-sm font-semibold text-[#365F65]">
                        Nama / Area Lokasi <span class="text-red-500">*</span>
                    </label>

                    <input type="text"
                           id="lokasi"
                           name="lokasi"
                           value="<?php echo e(old('lokasi', $lokasi->lokasi)); ?>"
                           placeholder="Contoh: Area Keberangkatan, dekat Gate 3"
                           required
                           maxlength="255"
                           class="w-full rounded-xl border border-[#DCE6E4] bg-[#F8FAF9] px-4 py-3 text-sm text-[#365F65] placeholder:text-[#A3B5B2] outline-none focus:border-[#527D82] focus:ring-2 focus:ring-[#527D82]/20">

                    <?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div>
                    <label for="luas_area"
                           class="mb-2 block text-sm font-semibold text-[#365F65]">
                        Luas Area (m²)
                    </label>

                    <input type="number"
                           id="luas_area"
                           name="luas_area"
                           value="<?php echo e(old('luas_area', $lokasi->luas_area)); ?>"
                           placeholder="Contoh: 25"
                           min="0"
                           step="0.01"
                           class="w-full rounded-xl border border-[#DCE6E4] bg-[#F8FAF9] px-4 py-3 text-sm text-[#365F65] placeholder:text-[#A3B5B2] outline-none focus:border-[#527D82] focus:ring-2 focus:ring-[#527D82]/20">

                    <?php $__errorArgs = ['luas_area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="md:col-span-2 xl:col-span-3">
                    <label for="catatan"
                           class="mb-2 block text-sm font-semibold text-[#365F65]">
                        Keterangan
                    </label>

                    <textarea id="catatan"
                              name="catatan"
                              rows="4"
                              placeholder="Tambahkan keterangan lokasi jika diperlukan"
                              class="w-full resize-y rounded-xl border border-[#DCE6E4] bg-[#F8FAF9] px-4 py-3 text-sm text-[#365F65] placeholder:text-[#A3B5B2] outline-none focus:border-[#527D82] focus:ring-2 focus:ring-[#527D82]/20"><?php echo e(old('catatan', $lokasi->catatan)); ?></textarea>

                    <?php $__errorArgs = ['catatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

            </div>

            
            <div class="flex flex-col-reverse gap-3 border-t border-[#E2EBE9] pt-6 sm:flex-row sm:justify-end">
                <a href="<?php echo e(route('lokasi.show', $lokasi)); ?>"
                   class="inline-flex justify-center rounded-xl border border-[#DCE6E4] bg-white px-5 py-3 text-sm font-semibold text-[#527D82] hover:bg-[#F5F8F7]">
                    Batal
                </a>

                <button type="submit"
                        class="inline-flex justify-center rounded-xl bg-[#365F65] px-5 py-3 text-sm font-semibold text-white hover:bg-[#294F55] focus:outline-none focus:ring-2 focus:ring-[#527D82]/30">
                    Simpan Perubahan
                </button>
            </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\AeroTrack\resources\views/lokasi/edit.blade.php ENDPATH**/ ?>