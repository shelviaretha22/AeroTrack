<?php $__env->startSection('page-title', 'Input Data Kerja Sama'); ?>

<?php $__env->startSection('content'); ?>
<div class="py-2">
    <div class="max-w-6xl mx-auto">

        
        <div class="mb-6">
            <h1 class="text-2xl font-bold text-[#365F65]">
                Input Data Kerja Sama
            </h1>
            <p class="mt-1 text-sm text-[#8BA5A2]">
                Tambahkan data kerja sama dengan mitra usaha.
            </p>
        </div>

        
        <?php if($errors->any()): ?>
            <div class="mb-6 rounded-xl border border-red-200 bg-red-50 p-4">
                <p class="font-semibold text-red-700 mb-2">
                    Terdapat kesalahan:
                </p>
                <ul class="list-disc list-inside text-sm text-red-600 space-y-1">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        
        <form action="<?php echo e(route('kerja-sama.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            
            <div class="bg-[#E8F0EF] rounded-2xl border border-[#DCE6E4] p-5 mb-6">
                <div class="flex items-start gap-3">
                    <div class="w-10 h-10 rounded-xl bg-white flex items-center justify-center shrink-0">
                        <svg class="w-5 h-5 text-[#365F65]"
                             fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                  stroke-width="2"
                                  d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
                        </svg>
                    </div>
                    <div>
                        <h2 class="font-bold text-[#365F65]">
                            Nomor Kerja Sama
                        </h2>
                        <p class="text-sm text-[#607D79] mt-1">
                            Nomor dibuat otomatis oleh sistem setelah data berhasil disimpan.
                        </p>
                        <p class="text-sm font-semibold text-[#365F65] mt-2">
                            Contoh format: KS-001
                        </p>
                    </div>
                </div>
            </div>

            
            <div class="bg-white rounded-2xl border border-[#DCE6E4] shadow-sm p-6 mb-6">

                <div class="flex items-center gap-3 mb-6">
                    <div class="w-10 h-10 rounded-xl bg-[#E8F0EF] flex items-center justify-center">
                        <svg class="w-5 h-5 text-[#365F65]"
                             fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                  stroke-width="2"
                                  d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0H5m14 0h2m-2 0h-4m-6 0H3m3 0h4M9 7h6m-6 4h6m-6 4h6"/>
                        </svg>
                    </div>
                    <div>
                        <h2 class="text-base font-bold text-[#365F65]">
                            Informasi Mitra
                        </h2>
                        <p class="text-xs text-[#8BA5A2]">
                            Informasi dasar mengenai mitra usaha.
                        </p>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-5">

                    
                    <div>
                        <label for="mitra_usaha"
                               class="block text-sm font-semibold text-[#365F65] mb-2">
                            Mitra Usaha <span class="text-red-500">*</span>
                        </label>
                        <input type="text" id="mitra_usaha" name="mitra_usaha"
                               value="<?php echo e(old('mitra_usaha')); ?>"
                               placeholder="Contoh: PT ABC Indonesia"
                               required
                               class="w-full rounded-xl border border-[#DCE6E4] bg-[#F9FBFA] px-4 py-3 text-sm text-[#365F65] placeholder:text-[#A7B9B7] focus:border-[#365F65] focus:ring-2 focus:ring-[#B8CECA]/50 outline-none transition">
                    </div>

                    
                    <div>
                        <label for="brand"
                               class="block text-sm font-semibold text-[#365F65] mb-2">
                            Brand
                        </label>
                        <input type="text" id="brand" name="brand"
                               value="<?php echo e(old('brand')); ?>"
                               placeholder="Contoh: ABC Coffee"
                               class="w-full rounded-xl border border-[#DCE6E4] bg-[#F9FBFA] px-4 py-3 text-sm text-[#365F65] placeholder:text-[#A7B9B7] focus:border-[#365F65] focus:ring-2 focus:ring-[#B8CECA]/50 outline-none transition">
                    </div>

                    
                    <div>
                        <label for="jenis_usaha"
                               class="block text-sm font-semibold text-[#365F65] mb-2">
                            Jenis Usaha <span class="text-red-500">*</span>
                        </label>
                        <select id="jenis_usaha" name="jenis_usaha" required
                                class="w-full rounded-xl border border-[#DCE6E4] bg-[#F9FBFA] px-4 py-3 text-sm text-[#365F65] focus:border-[#365F65] focus:ring-2 focus:ring-[#B8CECA]/50 outline-none transition">
                            <option value="">Pilih jenis usaha</option>
                            <?php $__currentLoopData = ['F&B', 'Retail', 'Service', 'Lounge', 'Duty Free', 'UMKM']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($jenis); ?>"
                                    <?php echo e(old('jenis_usaha') == $jenis ? 'selected' : ''); ?>>
                                    <?php echo e($jenis); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                   
<div>
    <label for="bentuk_kerja_sama"
           class="block text-sm font-semibold text-[#365F65] mb-2">
        Bentuk Kerja Sama
    </label>

    <div class="relative">
        <input
            type="text"
            id="bentuk_kerja_sama"
            value="Revenue Sharing"
            readonly
            class="w-full rounded-xl border border-[#DCE6E4] bg-gray-100 px-4 py-3 text-sm font-semibold text-[#365F65] outline-none cursor-not-allowed"
        >

        <input
            type="hidden"
            name="bentuk_kerja_sama"
            value="Revenue Sharing"
        >
    </div>

    <p class="mt-1 text-xs text-[#8BA5A2]">
        Bentuk kerja sama ditetapkan menggunakan skema Revenue Sharing.
    </p>
</div>
                </div>
            </div>

            
            <div class="bg-white rounded-2xl border border-[#DCE6E4] shadow-sm p-6 mb-6">

                <div class="flex items-center gap-3 mb-6">
                    <div class="w-10 h-10 rounded-xl bg-[#E8F0EF] flex items-center justify-center">
                        <svg class="w-5 h-5 text-[#365F65]"
                             fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                  stroke-width="2"
                                  d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                        </svg>
                    </div>
                    <div>
                        <h2 class="text-base font-bold text-[#365F65]">
                            Informasi Periode Kerja Sama
                        </h2>
                        <p class="text-xs text-[#8BA5A2]">
                            Tanggal pengajuan dan periode kerja sama.
                        </p>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-5">

                    
                    <div>
                        <label for="tanggal_pengajuan"
                               class="block text-sm font-semibold text-[#365F65] mb-2">
                            Tanggal Pengajuan
                        </label>
                        <input type="date" id="tanggal_pengajuan"
                               name="tanggal_pengajuan"
                               value="<?php echo e(old('tanggal_pengajuan', now()->format('Y-m-d'))); ?>"
                               readonly
                               class="w-full rounded-xl border border-[#DCE6E4] bg-gray-100 px-4 py-3 text-sm text-[#365F65] outline-none">
                        <p class="text-xs text-[#8BA5A2] mt-1">
                            Diisi otomatis sesuai tanggal hari ini.
                        </p>
                    </div>

                    
                    <div>
                        <label for="tanggal_mulai"
                               class="block text-sm font-semibold text-[#365F65] mb-2">
                            Tanggal Mulai Kerja Sama
                        </label>
                        <input type="date" id="tanggal_mulai"
                               name="tanggal_mulai"
                               value="<?php echo e(old('tanggal_mulai')); ?>"
                               class="w-full rounded-xl border border-[#DCE6E4] bg-[#F9FBFA] px-4 py-3 text-sm text-[#365F65] focus:border-[#365F65] focus:ring-2 focus:ring-[#B8CECA]/50 outline-none transition">
                    </div>

                    
                    <div>
                        <label for="tanggal_berakhir"
                               class="block text-sm font-semibold text-[#365F65] mb-2">
                            Tanggal Berakhir Kerja Sama
                        </label>
                        <input type="date" id="tanggal_berakhir"
                               name="tanggal_berakhir"
                               value="<?php echo e(old('tanggal_berakhir')); ?>"
                               min="<?php echo e(old('tanggal_mulai')); ?>"
                               class="w-full rounded-xl border border-[#DCE6E4] bg-[#F9FBFA] px-4 py-3 text-sm text-[#365F65] focus:border-[#365F65] focus:ring-2 focus:ring-[#B8CECA]/50 outline-none transition">
                    </div>

                </div>
            </div>

            
            <div class="bg-white rounded-2xl border border-[#DCE6E4] shadow-sm p-6 mb-6">

                <div class="flex items-center gap-3 mb-6">
                    <div class="w-10 h-10 rounded-xl bg-[#E8F0EF] flex items-center justify-center">
                        <svg class="w-5 h-5 text-[#365F65]"
                             fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                  stroke-width="2"
                                  d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/>
                        </svg>
                    </div>
                    <div>
                        <h2 class="text-base font-bold text-[#365F65]">
                            Informasi PIC Commercial
                        </h2>
                        <p class="text-xs text-[#8BA5A2]">
                            Penanggung jawab dan keterangan kerja sama.
                        </p>
                    </div>
                </div>

                <div class="space-y-5">

                    
                    <div>
                        <label for="pic_commercial"
                               class="block text-sm font-semibold text-[#365F65] mb-2">
                            PIC dari Pihak Commercial <span class="text-red-500">*</span>
                        </label>
                        <input type="text" id="pic_commercial" name="pic_commercial"
                               value="<?php echo e(old('pic_commercial')); ?>"
                               placeholder="Contoh: Andi Pratama"
                               required
                               class="w-full rounded-xl border border-[#DCE6E4] bg-[#F9FBFA] px-4 py-3 text-sm text-[#365F65] placeholder:text-[#A7B9B7] focus:border-[#365F65] focus:ring-2 focus:ring-[#B8CECA]/50 outline-none transition">
                    </div>

                    
                    <div>
                        <label for="jabatan_pic_commercial"
                               class="block text-sm font-semibold text-[#365F65] mb-2">
                            Jabatan PIC Commercial
                        </label>
                        <input type="text"
                               id="jabatan_pic_commercial"
                               name="jabatan_pic_commercial"
                               value="<?php echo e(old('jabatan_pic_commercial')); ?>"
                               placeholder="Contoh: Manager Commercial"
                               class="w-full rounded-xl border border-[#DCE6E4] bg-[#F9FBFA] px-4 py-3 text-sm text-[#365F65] placeholder:text-[#A7B9B7] focus:border-[#365F65] focus:ring-2 focus:ring-[#B8CECA]/50 outline-none transition">
                    </div>

                    
                    <div>
                        <label for="catatan"
                               class="block text-sm font-semibold text-[#365F65] mb-2">
                            Catatan / Keterangan
                        </label>
                        <textarea id="catatan" name="catatan" rows="4"
                                  placeholder="Tambahkan catatan terkait kerja sama..."
                                  class="w-full rounded-xl border border-[#DCE6E4] bg-[#F9FBFA] px-4 py-3 text-sm text-[#365F65] placeholder:text-[#A7B9B7] focus:border-[#365F65] focus:ring-2 focus:ring-[#B8CECA]/50 outline-none transition"><?php echo e(old('catatan')); ?></textarea>
                    </div>

                </div>
            </div>

            
            <div class="flex items-center justify-end gap-3">
                <a href="<?php echo e(route('kerja-sama')); ?>"
                   class="px-5 py-3 rounded-xl border border-[#DCE6E4] bg-white text-[#365F65] text-sm font-semibold hover:bg-[#F3F6F5] transition">
                    Batal
                </a>

                <button type="submit"
                        class="px-6 py-3 rounded-xl bg-[#365F65] text-white text-sm font-semibold hover:bg-[#2D5055] shadow-sm transition">
                    Simpan Data
                </button>
            </div>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\AeroTrack\resources\views/kerja-sama/create.blade.php ENDPATH**/ ?>