<?php $__env->startSection('page-title', 'Kontrak'); ?>

<?php $__env->startSection('content'); ?>

<div class="space-y-6">

    
    <div>
        <p class="text-sm text-[#8BA5A2]">
            Management / Kontrak
        </p>

        <h2 class="mt-1 text-2xl font-bold text-[#365F65]">
            Data Kontrak
        </h2>

        <p class="mt-1 text-sm text-[#7A9290]">
            Kelola informasi kontrak tenant berdasarkan kerja sama yang telah dibuat.
        </p>
    </div>

    
    <?php if(session('success')): ?>
        <div
            id="successToast"
            role="status"
            class="fixed right-6 top-6 z-[9999] flex w-[calc(100%-3rem)] max-w-md items-start gap-3 rounded-xl border border-[#CFE0DC] bg-[#EEF6F3] p-4 shadow-lg"
        >
            <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#DCECE6]">
                <svg
                    class="h-5 w-5 text-[#087F73]"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                >
                    <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M5 13l4 4L19 7"
                    />
                </svg>
            </div>

            <div class="min-w-0 flex-1">
                <h3 class="text-sm font-bold text-[#365F65]">
                    Dokumen Berhasil Disimpan
                </h3>

                <p class="mt-1 text-sm leading-relaxed text-[#55736F]">
                    <?php echo e(session('success')); ?>

                </p>
            </div>

            <button
                type="button"
                onclick="document.getElementById('successToast').remove()"
                class="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-[#55736F] transition hover:bg-[#DCECE6]"
                aria-label="Tutup notifikasi"
            >
                ✕
            </button>
        </div>

        <script>
            setTimeout(function () {
                const toast = document.getElementById('successToast');

                if (toast) {
                    toast.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
                    toast.style.opacity = '0';
                    toast.style.transform = 'translateY(-10px)';

                    setTimeout(function () {
                        toast.remove();
                    }, 400);
                }
            }, 5000);
        </script>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div
            role="alert"
            class="rounded-xl border border-[#F0D5C9] bg-[#FFF4EF] px-4 py-3 text-sm text-[#9A4F35]"
        >
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    
    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-5">

        
        <div class="rounded-2xl border border-[#E2EBE9] bg-white p-5">
            <div class="flex items-start justify-between">
                <div>
                    <p class="text-sm font-medium text-[#7A9290]">
                        Total Kontrak
                    </p>

                    <h3 class="mt-3 text-3xl font-bold text-[#365F65]">
                        <?php echo e($totalKontrak ?? 0); ?>

                    </h3>

                    <p class="mt-2 text-xs text-[#8BA5A2]">
                        Seluruh kontrak yang tercatat
                    </p>
                </div>

                <div class="flex h-11 w-11 items-center justify-center rounded-xl bg-[#E8F0EE]">
                    <svg class="h-6 w-6 text-[#365F65]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8"
                              d="M7 3.75h7l4 4v12.5H7a2 2 0 0 1-2-2v-12.5a2 2 0 0 1 2-2Z"/>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8"
                              d="M14 3.75v4h4M9 12h6M9 16h6"/>
                    </svg>
                </div>
            </div>
        </div>

        
        <div class="rounded-2xl border border-[#E2EBE9] bg-white p-5">
            <div class="flex items-start justify-between">
                <div>
                    <p class="text-sm font-medium text-[#7A9290]">
                        Kontrak Aktif
                    </p>

                    <h3 class="mt-3 text-3xl font-bold text-[#087F73]">
                        <?php echo e($kontrakAktif ?? 0); ?>

                    </h3>

                    <p class="mt-2 text-xs text-[#8BA5A2]">
                        PDF final tersedia dan belum berakhir
                    </p>
                </div>

                <div class="flex h-11 w-11 items-center justify-center rounded-xl bg-[#E5F5EF]">
                    <svg class="h-6 w-6 text-[#087F73]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="m5 12 4 4L19 6"/>
                    </svg>
                </div>
            </div>
        </div>

        
        <div class="rounded-2xl border border-[#E2EBE9] bg-white p-5">
            <div class="flex items-start justify-between">
                <div>
                    <p class="text-sm font-medium text-[#7A9290]">
                        Kontrak Nonaktif
                    </p>

                    <h3 class="mt-3 text-3xl font-bold text-[#A47720]">
                        <?php echo e($kontrakNonAktif ?? 0); ?>

                    </h3>

                    <p class="mt-2 text-xs text-[#8BA5A2]">
                        Masa kontrak telah berakhir
                    </p>
                </div>

                <div class="flex h-11 w-11 items-center justify-center rounded-xl bg-[#FFF4DF]">
                    <svg class="h-6 w-6 text-[#A47720]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="9" stroke-width="1.8"/>
                        <path stroke-linecap="round" stroke-width="1.8"
                              d="M12 7v5l3 2"/>
                    </svg>
                </div>
            </div>
        </div>

        
        <div class="rounded-2xl border border-[#E2EBE9] bg-white p-5">
            <div class="flex items-start justify-between">
                <div>
                    <p class="text-sm font-medium text-[#7A9290]">
                        Kontrak Draft
                    </p>

                    <h3 class="mt-3 text-3xl font-bold text-[#A16207]">
                        <?php echo e($kontrakDraft ?? 0); ?>

                    </h3>

                    <p class="mt-2 text-xs text-[#8BA5A2]">
                        PDF final belum diunggah
                    </p>
                </div>

                <div class="flex h-11 w-11 items-center justify-center rounded-xl bg-[#FFF0D9]">
                    <svg class="h-6 w-6 text-[#A16207]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="9" stroke-width="1.8"/>
                        <path stroke-linecap="round" stroke-width="1.8"
                              d="M12 7v5l3 2"/>
                    </svg>
                </div>
            </div>
        </div>

        
        <div class="rounded-2xl border border-[#E2EBE9] bg-white p-5">
            <div class="flex items-start justify-between">
                <div>
                    <p class="text-sm font-medium text-[#7A9290]">
                        Belum Dibuat
                    </p>

                    <h3 class="mt-3 text-3xl font-bold text-[#527D82]">
                        <?php echo e($kontrakBelumDibuat ?? 0); ?>

                    </h3>

                    <p class="mt-2 text-xs text-[#8BA5A2]">
                        Kerja sama belum memiliki kontrak
                    </p>
                </div>

                <div class="flex h-11 w-11 items-center justify-center rounded-xl bg-[#EDF2F1]">
                    <svg class="h-6 w-6 text-[#527D82]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8"
                              d="M12 5v14M5 12h14"/>
                    </svg>
                </div>
            </div>
        </div>

    </div>
        
    <div class="grid grid-cols-1 gap-5 xl:grid-cols-2">

        
        <div class="rounded-2xl border border-[#E2EBE9] bg-white p-5">
            <div class="mb-5">
                <h3 class="text-base font-bold text-[#365F65]">
                    Komposisi Status Kontrak
                </h3>

                <p class="mt-1 text-sm text-[#7A9290]">
                    Perbandingan status seluruh kontrak
                </p>
            </div>

            <div class="relative mx-auto h-[280px] max-w-[380px]">
                <canvas id="grafikStatusKontrak"></canvas>
            </div>
        </div>

        
        <div class="rounded-2xl border border-[#E2EBE9] bg-white p-5">
            <div class="mb-5">
                <h3 class="text-base font-bold text-[#365F65]">
                    Kontrak per Tahun
                </h3>

                <p class="mt-1 text-sm text-[#7A9290]">
                    Jumlah kontrak berdasarkan tahun pengajuan
                </p>
            </div>

            <div class="relative h-[280px]">
                <canvas id="grafikKontrakTahunan"></canvas>
            </div>
        </div>

    </div>

    
    <div class="rounded-2xl border border-[#E2EBE9] bg-white p-5">
        <form
            method="GET"
            action="<?php echo e(route('kontrak')); ?>"
            class="grid grid-cols-1 gap-4 md:grid-cols-5"
        >

            
            <div class="md:col-span-2">
                <label
                    for="search"
                    class="mb-1.5 block text-xs font-semibold text-[#527D82]"
                >
                    Cari Kontrak
                </label>

                <input
                    type="text"
                    id="search"
                    name="search"
                    value="<?php echo e(request('search')); ?>"
                    placeholder="Cari nomor kerja sama, brand, atau lokasi..."
                    class="w-full rounded-xl border border-[#DCE6E4] bg-[#F8FAF9] px-4 py-3 text-sm text-[#365F65] outline-none focus:border-[#527D82] focus:ring-2 focus:ring-[#527D82]/10"
                >
            </div>

            
            <div>
                <label
                    for="sort"
                    class="mb-1.5 block text-xs font-semibold text-[#527D82]"
                >
                    Urutkan
                </label>

                <select
                    id="sort"
                    name="sort"
                    class="w-full rounded-xl border border-[#DCE6E4] bg-[#F8FAF9] px-4 py-3 text-sm text-[#365F65] outline-none focus:border-[#527D82] focus:ring-2 focus:ring-[#527D82]/10"
                >
                    <option value="newest" <?php echo e(request('sort', 'newest') === 'newest' ? 'selected' : ''); ?>>
                        Terbaru
                    </option>

                    <option value="oldest" <?php echo e(request('sort') === 'oldest' ? 'selected' : ''); ?>>
                        Terlama
                    </option>

                    <option value="az" <?php echo e(request('sort') === 'az' ? 'selected' : ''); ?>>
                        Nama Brand A-Z
                    </option>

                    <option value="za" <?php echo e(request('sort') === 'za' ? 'selected' : ''); ?>>
                        Nama Brand Z-A
                    </option>
                </select>
            </div>

            
            <div>
                <label
                    for="status"
                    class="mb-1.5 block text-xs font-semibold text-[#527D82]"
                >
                    Status Kontrak
                </label>

                <select
                    id="status"
                    name="status"
                    class="w-full rounded-xl border border-[#DCE6E4] bg-[#F8FAF9] px-4 py-3 text-sm text-[#365F65] outline-none focus:border-[#527D82] focus:ring-2 focus:ring-[#527D82]/10"
                >
                    <option value="">Semua Status</option>

                    <option value="Belum Dibuat" <?php echo e(request('status') === 'Belum Dibuat' ? 'selected' : ''); ?>>
                        Belum Dibuat
                    </option>

                    <option value="Draft" <?php echo e(request('status') === 'Draft' ? 'selected' : ''); ?>>
                        Draft
                    </option>

                    <option value="Aktif" <?php echo e(request('status') === 'Aktif' ? 'selected' : ''); ?>>
                        Aktif
                    </option>

                    <option value="Nonaktif" <?php echo e(request('status') === 'Nonaktif' ? 'selected' : ''); ?>>
                        Nonaktif
                    </option>
                </select>
            </div>

            
            <div class="flex items-end justify-end">
                <button
                    type="submit"
                    class="rounded-xl bg-[#E8F0EE] px-5 py-3 text-sm font-semibold text-[#365F65] transition hover:bg-[#DCE9E6]"
                >
                    Terapkan Filter
                </button>
            </div>

        </form>
    </div>

    
    
<?php
    $daftarKandidat = collect($kandidatKontrak ?? []);

    $daftarKontrak = collect($kontraks ?? [])
        ->sortBy(function ($kontrak) {

            $adaPdfFinal = filled($kontrak->final_pdf_path)
                && \Illuminate\Support\Facades\Storage::disk('local')
                    ->exists($kontrak->final_pdf_path);

            $tanggalAkhir = $kontrak->kerjaSama?->tanggal_berakhir;

            $isExpired = $tanggalAkhir
                ? \Carbon\Carbon::parse($tanggalAkhir)
                    ->startOfDay()
                    ->lt(now()->startOfDay())
                : false;

            if (!$adaPdfFinal) {
                return 1; // Draft
            }

            if ($isExpired) {
                return 3; // Nonaktif
            }

            return 2; // Aktif
        })
        ->values();

    $nomorBaris = 0;
?>


    <div class="overflow-hidden rounded-2xl border border-[#E2EBE9] bg-white">
        <div class="overflow-x-auto">
            <table class="w-full min-w-[1500px]">

                <thead class="bg-[#F3F6F5]">
                    <tr>
                        <?php $__currentLoopData = [
                            'No.',
                            'Nomor Kontrak',
                            'Nomor Kerja Sama',
                            'Tenant',
                            'Lokasi',
                            'Durasi',
                            'Status',
                            'Konfirmasi Perpanjangan',
                            'Note',
                            'Aksi',
                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $judul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="px-4 py-4 text-left text-xs font-bold uppercase tracking-wide text-[#7A9290]">
                                <?php echo e($judul); ?>

                            </th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>

                <tbody class="divide-y divide-[#EEF2F1]">

                    
                    <?php $__currentLoopData = $daftarKandidat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kandidat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $nomorBaris++;

                            $tenantKandidat = $kandidat->tenant;
                            $lokasiKandidat = $kandidat->lokasi;

                            $tanggalMulai = $kandidat->tanggal_mulai;
                            $tanggalBerakhir = $kandidat->tanggal_berakhir;
                        ?>

                        <tr class="transition hover:bg-[#FAFCFB]">

                            <td class="px-4 py-4 text-sm text-[#7A9290]">
                                <?php echo e($nomorBaris); ?>

                            </td>

                            <td class="px-4 py-4 text-sm text-[#9AA6A4]">
                                -
                                <p class="mt-1 text-xs italic">
                                    Belum dibuat
                                </p>
                            </td>

                            <td class="px-4 py-4 text-sm font-semibold text-[#365F65]">
                                <?php echo e($kandidat->nomor_kerja_sama ?? '-'); ?>

                            </td>

                            <td class="px-4 py-4">
                                <p class="text-sm font-semibold text-[#365F65]">
                                    <?php echo e($tenantKandidat?->mitra_usaha ?? $kandidat->mitra_usaha ?? '-'); ?>

                                </p>

                                <p class="mt-1 text-sm text-[#527D82]">
                                    <?php echo e($tenantKandidat?->nama_tenant ?? $kandidat->brand ?? '-'); ?>

                                </p>
                            </td>

                            <td class="px-4 py-4">
                                <p class="text-sm font-semibold text-[#365F65]">
                                    <?php echo e($lokasiKandidat?->kode_ruang ?? '-'); ?>

                                </p>

                                <p class="mt-1 text-xs text-[#7A9290]">
                                    <?php echo e($lokasiKandidat?->lokasi ?? '-'); ?>

                                </p>

                                <?php if($lokasiKandidat): ?>
                                    <p class="mt-1 text-xs text-[#8BA5A2]">
                                        Terminal <?php echo e($lokasiKandidat->terminal ?? '-'); ?>

                                        - Lantai <?php echo e($lokasiKandidat->lantai ?? '-'); ?>

                                    </p>
                                <?php endif; ?>
                            </td>

                            <td class="px-4 py-4 text-sm text-[#527D82]">
                                <?php if($tanggalMulai && $tanggalBerakhir): ?>
                                    <?php echo e(\Carbon\Carbon::parse($tanggalMulai)->format('d M Y')); ?>

                                    -
                                    <?php echo e(\Carbon\Carbon::parse($tanggalBerakhir)->format('d M Y')); ?>


                                    <p class="mt-1 text-xs text-[#8BA5A2]">
                                        (<?php echo e(\Carbon\Carbon::parse($tanggalMulai)
                                            ->diffInMonths(\Carbon\Carbon::parse($tanggalBerakhir))); ?> bulan)
                                    </p>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>

                            
                            <td class="px-4 py-4">
                                <span class="inline-flex rounded-lg bg-[#F3F6F5] px-3 py-1.5 text-xs font-semibold text-[#527D82]">
                                    Belum Dibuat
                                </span>
                            </td>

                            
                            <td class="px-4 py-4 text-sm text-[#8BA5A2]">
                                -
                            </td>

                            
                            <td class="px-4 py-4 text-sm text-[#527D82]">
                                Kerja sama sudah memenuhi syarat untuk dibuatkan kontrak.

                                <p class="mt-1 text-xs text-[#8BA5A2]">
                                    Aktivasi: <?php echo e($kandidat->aktivasi?->nomor_pengajuan ?? '-'); ?>

                                </p>
                            </td>

                            
                            <td class="px-4 py-4">
                                <form
                                    method="POST"
                                    action="<?php echo e(route('kontrak.store', $kandidat->id)); ?>"
                                    onsubmit="return confirm('Buat kontrak untuk kerja sama ini?')"
                                >
                                    <?php echo csrf_field(); ?>

                                    <button
                                        type="submit"
                                        class="whitespace-nowrap rounded-lg bg-[#087F73] px-3 py-2.5 text-xs font-semibold text-white transition hover:bg-[#06685F]"
                                    >
                                        Buat Kontrak
                                    </button>
                                </form>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                    <?php $__currentLoopData = $daftarKontrak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kontrak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $nomorBaris++;

                            $kerjaSama = $kontrak->kerjaSama;
                            $tenant = $kontrak->tenant;
                            $lokasi = $kontrak->lokasi;

                            $tanggalAwal = $kerjaSama?->tanggal_mulai;
                            $tanggalAkhir = $kerjaSama?->tanggal_berakhir;

                            $isExpired = $tanggalAkhir
                                ? \Carbon\Carbon::parse($tanggalAkhir)
                                    ->startOfDay()
                                    ->lt(now()->startOfDay())
                                : false;

                            $akanHabis = $tanggalAkhir
                            ? (
                                !$isExpired &&
                                now()->startOfDay()->diffInDays(
                                    \Carbon\Carbon::parse($tanggalAkhir)->startOfDay()
                                ) <= 30
                            )
                            : false;

                            /*
                             * Status ditentukan berdasarkan keberadaan PDF final
                             * dan tanggal berakhir kerja sama.
                             */
                            $adaPdfFinal = filled($kontrak->final_pdf_path)
                                && \Illuminate\Support\Facades\Storage::disk('local')
                                    ->exists($kontrak->final_pdf_path);

                            $statusKontrak = !$adaPdfFinal
                                ? 'Draft'
                                : ($isExpired ? 'Nonaktif' : 'Aktif');

                            $batasKonfirmasi = $tanggalAkhir
                                ? \Carbon\Carbon::parse($tanggalAkhir)
                                    ->subMonthNoOverflow()
                                    ->startOfDay()
                                : null;

                            $bolehKonfirmasi = $adaPdfFinal
                                && $tanggalAkhir
                                && !$isExpired
                                && now()->startOfDay()->greaterThanOrEqualTo($batasKonfirmasi);
                                                    ?>

                        
<tr class="<?php echo e($statusKontrak === 'Nonaktif'
    ? 'bg-[#EEF1F0] opacity-65'
    : 'bg-white'); ?> transition">


                            <td class="px-4 py-4 text-sm text-[#7A9290]">
                                <?php echo e($nomorBaris); ?>

                            </td>

                            <td class="px-4 py-4">
                                <p class="text-sm font-semibold text-[#365F65]">
                                    <?php echo e($kontrak->nomor_kontrak ?? '-'); ?>

                                </p>
                            </td>

                            <td class="px-4 py-4 text-sm font-semibold text-[#365F65]">
                                <?php echo e($kerjaSama?->nomor_kerja_sama ?? '-'); ?>

                            </td>

                            <td class="px-4 py-4">
                                <p class="text-sm font-semibold text-[#365F65]">
                                    <?php echo e($tenant?->mitra_usaha ?? $kerjaSama?->mitra_usaha ?? '-'); ?>

                                </p>

                                <p class="mt-1 text-sm text-[#527D82]">
                                    <?php echo e($tenant?->nama_tenant ?? $kerjaSama?->brand ?? '-'); ?>

                                </p>

                                <?php if($tenant?->nama_pic): ?>
                                    <p class="mt-1 text-xs text-[#8BA5A2]">
                                        PIC: <?php echo e($tenant->nama_pic); ?>

                                    </p>
                                <?php endif; ?>
                            </td>

                            <td class="px-4 py-4">
                                <p class="text-sm font-semibold text-[#365F65]">
                                    <?php echo e($lokasi?->kode_ruang ?? '-'); ?>

                                </p>

                                <p class="mt-1 text-xs text-[#7A9290]">
                                    <?php echo e($lokasi?->lokasi ?? '-'); ?>

                                </p>

                                <?php if($lokasi): ?>
                                    <p class="mt-1 text-xs text-[#8BA5A2]">
                                        Terminal <?php echo e($lokasi->terminal ?? '-'); ?>

                                        - Lantai <?php echo e($lokasi->lantai ?? '-'); ?>

                                    </p>
                                <?php endif; ?>
                            </td>

                            
                            <td class="px-4 py-4 text-sm text-[#527D82]">
                                <?php if($tanggalAwal && $tanggalAkhir): ?>
                                    <?php echo e(\Carbon\Carbon::parse($tanggalAwal)->format('d M Y')); ?>

                                    -
                                    <?php echo e(\Carbon\Carbon::parse($tanggalAkhir)->format('d M Y')); ?>


                                    <p class="mt-1 text-xs text-[#8BA5A2]">
                                        (<?php echo e(\Carbon\Carbon::parse($tanggalAwal)
                                            ->diffInMonths(\Carbon\Carbon::parse($tanggalAkhir))); ?> bulan)
                                    </p>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>

                            
                            <td class="px-4 py-4">
                                <?php if($statusKontrak === 'Aktif'): ?>
                                    <span class="inline-flex rounded-lg bg-[#D1FAE5] px-3 py-1.5 text-xs font-semibold text-[#047857]">
                                        Aktif
                                    </span>
                                <?php elseif($statusKontrak === 'Nonaktif'): ?>
                                    <span class="inline-flex rounded-lg bg-[#F3F6F5] px-3 py-1.5 text-xs font-semibold text-[#64748B]">
                                        Nonaktif
                                    </span>
                                <?php else: ?>
                                    <span class="inline-flex rounded-lg bg-[#FFF0D9] px-3 py-1.5 text-xs font-semibold text-[#A16207]">
                                        Draft
                                    </span>
                                <?php endif; ?>
                            </td>

                            
                            <td class="px-4 py-4">
                                <?php if(!$adaPdfFinal): ?>
                                    <span class="text-xs text-[#8BA5A2]">
                                        -
                                    </span>

                                <?php elseif($kontrak->status_perpanjangan === 'Ingin Memperpanjang'): ?>
                                    <span class="inline-flex rounded-lg bg-[#D1FAE5] px-3 py-1.5 text-xs font-semibold text-[#047857]">
                                        Ingin Memperpanjang
                                    </span>

                                    <?php if($kontrak->tanggal_konfirmasi): ?>
                                        <p class="mt-1 text-xs text-[#8BA5A2]">
                                            <?php echo e($kontrak->tanggal_konfirmasi->format('d M Y')); ?>

                                        </p>
                                    <?php endif; ?>

                                <?php elseif($kontrak->status_perpanjangan === 'Tidak Memperpanjang'): ?>
                                    <span class="inline-flex rounded-lg bg-[#FEE2E2] px-3 py-1.5 text-xs font-semibold text-[#B91C1C]">
                                        Tidak Memperpanjang
                                    </span>

                                    <?php if($kontrak->tanggal_konfirmasi): ?>
                                        <p class="mt-1 text-xs text-[#8BA5A2]">
                                            <?php echo e($kontrak->tanggal_konfirmasi->format('d M Y')); ?>

                                        </p>
                                    <?php endif; ?>

                                <?php elseif($bolehKonfirmasi): ?>
                                    <button
                                        type="button"
                                        onclick="bukaModalPerpanjangan(
                                            <?php echo e($kontrak->id); ?>,
                                            <?php echo \Illuminate\Support\Js::from($kontrak->nomor_kontrak)->toHtml() ?>
                                        )"
                                        class="whitespace-nowrap rounded-lg bg-[#365F65] px-3 py-2.5 text-xs font-semibold text-white transition hover:bg-[#294F55]"
                                    >
                                        Konfirmasi
                                    </button>

                                <?php else: ?>
                                    <span class="text-xs text-[#8BA5A2]">
                                        Belum waktunya
                                    </span>

                                    <p class="mt-1 text-xs text-[#8BA5A2]">
                                        Aktif mulai
                                        <?php echo e($batasKonfirmasi?->format('d M Y') ?? '-'); ?>

                                    </p>
                                <?php endif; ?>
                            </td>

                            

<td class="px-4 py-4 text-sm text-[#527D82]">

    <?php if($statusKontrak === 'Nonaktif'): ?>

        Masa kontrak telah berakhir.

    <?php elseif($statusKontrak === 'Aktif' && $akanHabis): ?>

        <span class="font-semibold text-[#A47720]">
            Kontrak akan habis.
        </span>

    <?php elseif($statusKontrak === 'Aktif'): ?>

        PDF final telah diunggah dan kontrak masih berlaku.

    <?php else: ?>

        Dokumen kontrak belum memiliki PDF final.

    <?php endif; ?>

</td>


                            

<td class="px-4 py-4">

    
    <?php if($adaPdfFinal): ?>

        <a
            href="<?php echo e(route('kontrak.finalPdf', $kontrak->id)); ?>"
            target="_blank"
            rel="noopener noreferrer"
            class="inline-flex items-center justify-center whitespace-nowrap rounded-lg border border-[#DCE6E4] bg-white px-3 py-2.5 text-xs font-semibold text-[#365F65] transition hover:bg-[#F3F6F5]"
        >
            Detail
        </a>

    
    <?php elseif($kontrak->progress_tahap === 'upload_final'): ?>

        <a
            href="<?php echo e(route('kontrak.uploadFinal', $kontrak->id)); ?>"
            class="inline-flex items-center justify-center whitespace-nowrap rounded-lg bg-[#365F65] px-3 py-2.5 text-xs font-semibold text-white transition hover:bg-[#294F55]"
        >
            Lanjutkan
        </a>

    
    <?php else: ?>

        <a
            href="<?php echo e(route('kontrak.acc', $kontrak->id)); ?>"
            class="inline-flex items-center justify-center whitespace-nowrap rounded-lg bg-[#365F65] px-3 py-2.5 text-xs font-semibold text-white transition hover:bg-[#294F55]"
        >
            Lanjutkan
        </a>

    <?php endif; ?>

</td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                    <?php if($nomorBaris === 0): ?>
                        <tr>
                            <td colspan="10" class="px-5 py-16 text-center">
                                <div class="mx-auto max-w-md">
                                    <div class="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-[#F3F6F5]">
                                        <span class="text-xl text-[#8BA5A2]">📄</span>
                                    </div>

                                    <p class="mt-4 text-sm font-semibold text-[#527D82]">
                                        Belum ada data kontrak
                                    </p>

                                    <p class="mt-1 text-xs leading-5 text-[#8BA5A2]">
                                        Data akan muncul setelah kerja sama memenuhi
                                        syarat kontrak atau kontrak berhasil dibuat.
                                    </p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>

    
    <div class="rounded-xl border border-[#DCE6E4] bg-[#F3F6F5] px-4 py-3">
    <p class="text-xs leading-5 text-[#7A9290]">
        <span class="font-semibold text-[#527D82]">
            Keterangan:
        </span>

        Kontrak yang PDF finalnya sudah tersimpan dan masa sewanya
        telah berakhir akan berstatus
        <strong>Nonaktif</strong>, terlepas dari keputusan perpanjangan mitra.

        Jika masa sewa kontrak aktif tersisa maksimal 1 bulan,
        sistem akan memberikan catatan
        <strong>Kontrak akan habis</strong>.
    </p>
</div>

</div>


<script>
    window.dataStatusKontrak = <?php echo json_encode($dataStatus ?? [], 15, 512) ?>;
    window.dataKontrakTahunan = <?php echo json_encode($dataTahunan ?? [], 15, 512) ?>;
</script>

<div
    id="modalPerpanjangan"
    class="fixed inset-0 z-50 hidden items-center justify-center bg-black/40 p-4"
    role="dialog"
    aria-modal="true"
    aria-labelledby="judulModalPerpanjangan"
>
    <div class="w-full max-w-md rounded-2xl bg-white p-6 shadow-xl">

        <h3
            id="judulModalPerpanjangan"
            class="text-lg font-bold text-[#365F65]"
        >
            Konfirmasi Perpanjangan
        </h3>

        <p class="mt-2 text-sm text-[#7A9290]">
            Nomor kontrak:
            <span
                id="nomorKontrakModal"
                class="font-semibold text-[#365F65]"
            ></span>
        </p>

        <p class="mt-3 text-sm text-[#527D82]">
            Catat keputusan tenant setelah dikonfirmasi oleh petugas komersial.
        </p>

        <form
            id="formPerpanjangan"
            method="POST"
            class="mt-5"
        >
            <?php echo csrf_field(); ?>

            <label
                for="status_perpanjangan"
                class="mb-2 block text-sm font-semibold text-[#365F65]"
            >
                Keputusan tenant
            </label>

            <select
                id="status_perpanjangan"
                name="status_perpanjangan"
                required
                class="w-full rounded-xl border border-[#DCE6E4] bg-[#F8FAF9] px-4 py-3 text-sm text-[#365F65] focus:border-[#527D82] focus:outline-none focus:ring-2 focus:ring-[#527D82]/10"
            >
                <option value="">Pilih keputusan</option>

                <option value="Ingin Memperpanjang">
                    Ingin Memperpanjang
                </option>

                <option value="Tidak Memperpanjang">
                    Tidak Memperpanjang
                </option>
            </select>

            <div class="mt-6 flex justify-end gap-3">
                <button
                    type="button"
                    onclick="tutupModalPerpanjangan()"
                    class="rounded-xl border border-[#DCE6E4] px-4 py-2.5 text-sm font-semibold text-[#527D82] transition hover:bg-[#F3F6F5]"
                >
                    Batal
                </button>

                <button
                    id="tombolSimpanPerpanjangan"
                    type="submit"
                    class="rounded-xl bg-[#087F73] px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-[#06685F]"
                >
                    Simpan Konfirmasi
                </button>
            </div>
        </form>
    </div>
</div>


<script>
    function bukaModalPerpanjangan(id, nomorKontrak) {
        const modal = document.getElementById('modalPerpanjangan');
        const form = document.getElementById('formPerpanjangan');
        const pilihan = document.getElementById('status_perpanjangan');

        form.action = `<?php echo e(url('/kontrak')); ?>/${id}/konfirmasi-perpanjangan`;

        document.getElementById('nomorKontrakModal').textContent = nomorKontrak;
        pilihan.value = '';

        modal.classList.remove('hidden');
        modal.classList.add('flex');

        pilihan.focus();
    }

    function tutupModalPerpanjangan() {
        const modal = document.getElementById('modalPerpanjangan');

        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            tutupModalPerpanjangan();
        }
    });

    document.getElementById('modalPerpanjangan').addEventListener('click', function (event) {
        if (event.target === this) {
            tutupModalPerpanjangan();
        }
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\AeroTrack\resources\views/kontrak/index.blade.php ENDPATH**/ ?>