<?php $__env->startSection('page-title', 'Aktivasi'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $kelasInput = 'w-full rounded-xl border border-[#DCE6E4] bg-[#F8FAF9] px-3.5 py-2.5 text-sm text-[#365F65] outline-none transition focus:border-[#527D82] focus:bg-white focus:ring-2 focus:ring-[#527D82]/15';

    $persen = fn ($n) => $totalAktivasi > 0 ? round(($n / $totalAktivasi) * 100) : 0;

    // Alur utama dan satu cabang (Ditolak).
    $alur = [
        ['status' => 'Menunggu BA',        'warna' => '#8BA5A2', 'kelas' => 'text-[#527D82]',  'ket' => 'BA belum tersedia'],
        ['status' => 'Belum Diajukan',     'warna' => '#6C8EBF', 'kelas' => 'text-blue-700',   'ket' => 'Siap diajukan'],
        ['status' => 'Menunggu Keputusan', 'warna' => '#D6A14D', 'kelas' => 'text-amber-700',  'ket' => 'Di kantor pusat'],
        ['status' => 'Disetujui',          'warna' => '#31966A', 'kelas' => 'text-emerald-700', 'ket' => 'Kontrak sistem aktif'],
    ];
    $jumlahDitolak = $perAktivasi['Ditolak'] ?? 0;

    $warnaFisik = [
        'BA Belum Dibuat' => '#C9D6D3',
        'BA Belum TTD' => '#D6A14D',
        'BA Selesai' => '#527D82',
        'Kontrak Dalam Proses' => '#6C8EBF',
        'Kontrak Selesai' => '#31966A',
    ];
    $maksFisik = max(1, (int) $perKontrakFisik->max());

    $segmenSistem = [
        ['label' => 'Aktif', 'value' => $sistemAktif, 'color' => '#31966A'],
        ['label' => 'Belum Aktif', 'value' => max(0, $totalAktivasi - $sistemAktif), 'color' => '#C9D6D3'],
    ];

    $adaFilter = request()->hasAny(['search', 'kontrak_fisik', 'kontrak_sistem', 'status']);
?>

<div class="space-y-6">

    
    <div>
        <p class="text-sm text-[#8BA5A2]">Management / Aktivasi</p>
        <h1 class="mt-1 text-2xl font-bold text-[#365F65]">Aktivasi</h1>
        <p class="mt-1 text-sm text-[#7A9290]">
            Pantau Kontrak Fisik, Kontrak Sistem, dan pengajuan Aktivasi setiap tenant. Pengelolaan dilakukan melalui tombol Detail.
        </p>
    </div>

    
    <?php if(session('success')): ?>
        <div class="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800" role="status">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700" role="status">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            <p class="font-semibold">Data belum berhasil disimpan.</p>
            <ul class="mt-2 list-inside list-disc">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    
    <section class="grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4" aria-label="Ringkasan aktivasi">

        <a href="<?php echo e(route('aktivasi')); ?>"
           class="block rounded-2xl border border-[#E2EBE9] bg-white p-4 shadow-sm transition hover:border-[#B6C7C4] hover:shadow sm:p-5">
            <div class="flex items-center justify-between gap-3">
                <p class="text-sm font-medium text-[#7A9290]">Total Kerja Sama</p>
                <span class="flex h-9 w-9 items-center justify-center rounded-lg bg-[#EAF2F1] text-[#365F65]">
                    <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M9 12h6m-6 4h6m2 5H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7l5 5v11a2 2 0 0 1-2 2Z"/>
                    </svg>
                </span>
            </div>
            <p class="mt-2 text-3xl font-bold text-[#365F65]"><?php echo e($totalAktivasi); ?></p>
            <p class="mt-1 text-xs text-[#8BA5A2]">Semua kerja sama terdaftar</p>
        </a>

        <a href="<?php echo e(route('aktivasi', ['status' => 'Menunggu Keputusan'])); ?>"
           class="block rounded-2xl border border-[#E2EBE9] bg-white p-4 shadow-sm transition hover:border-amber-300 hover:shadow sm:p-5">
            <div class="flex items-center justify-between gap-3">
                <p class="text-sm font-medium text-[#7A9290]">Menunggu Keputusan</p>
                <span class="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-50 text-amber-700">
                    <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round">
                        <circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>
                    </svg>
                </span>
            </div>
            <p class="mt-2 text-3xl font-bold text-amber-700"><?php echo e($menunggu); ?></p>
            <div class="mt-2 h-1.5 overflow-hidden rounded-full bg-[#E7EFEC]">
                <div class="h-full rounded-full bg-amber-500" style="width: <?php echo e($persen($menunggu)); ?>%"></div>
            </div>
            <p class="mt-1 text-xs text-[#8BA5A2]"><?php echo e($persen($menunggu)); ?>% dari total</p>
        </a>

        <a href="<?php echo e(route('aktivasi', ['status' => 'Disetujui'])); ?>"
           class="block rounded-2xl border border-[#E2EBE9] bg-white p-4 shadow-sm transition hover:border-emerald-300 hover:shadow sm:p-5">
            <div class="flex items-center justify-between gap-3">
                <p class="text-sm font-medium text-[#7A9290]">Disetujui</p>
                <span class="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-50 text-emerald-700">
                    <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="m5 12 4 4L19 6"/>
                    </svg>
                </span>
            </div>
            <p class="mt-2 text-3xl font-bold text-emerald-700"><?php echo e($disetujui); ?></p>
            <div class="mt-2 h-1.5 overflow-hidden rounded-full bg-[#E7EFEC]">
                <div class="h-full rounded-full bg-emerald-600" style="width: <?php echo e($persen($disetujui)); ?>%"></div>
            </div>
            <p class="mt-1 text-xs text-[#8BA5A2]"><?php echo e($persen($disetujui)); ?>% dari total</p>
        </a>

        <a href="<?php echo e(route('aktivasi', ['kontrak_sistem' => 'Aktif'])); ?>"
           class="block rounded-2xl border border-[#E2EBE9] bg-white p-4 shadow-sm transition hover:border-emerald-300 hover:shadow sm:p-5">
            <div class="flex items-center justify-between gap-3">
                <p class="text-sm font-medium text-[#7A9290]">Kontrak Sistem Aktif</p>
                <span class="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-50 text-blue-700">
                    <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M13 2 4 14h7l-1 8 9-12h-7l1-8Z"/>
                    </svg>
                </span>
            </div>
            <p class="mt-2 text-3xl font-bold text-blue-700"><?php echo e($sistemAktif); ?></p>
            <div class="mt-2 h-1.5 overflow-hidden rounded-full bg-[#E7EFEC]">
                <div class="h-full rounded-full bg-blue-500" style="width: <?php echo e($persen($sistemAktif)); ?>%"></div>
            </div>
            <p class="mt-1 text-xs text-[#8BA5A2]"><?php echo e($persen($sistemAktif)); ?>% dari total</p>
        </a>
    </section>

    
    <section x-data="{ buka: true }" class="rounded-2xl border border-[#E2EBE9] bg-white shadow-sm">
        <button type="button" @click="buka = !buka" :aria-expanded="buka"
                class="flex w-full items-center justify-between gap-3 px-5 py-4 text-left">
            <span>
                <span class="block font-bold text-[#365F65]">Diagram Aktivasi</span>
                <span class="mt-0.5 block text-sm text-[#7A9290]">Alur pengajuan, posisi kontrak fisik, kontrak sistem, dan kontrak yang segera berakhir.</span>
            </span>
            <svg class="h-5 w-5 shrink-0 text-[#527D82] transition" :class="buka ? 'rotate-180' : ''" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="m6 9 6 6 6-6"/>
            </svg>
        </button>

        <div x-show="buka" x-transition class="space-y-6 border-t border-[#E2EBE9] p-5 sm:p-6">

            
            <div class="rounded-xl border border-[#E2EBE9] p-5">
                <h3 class="font-bold text-[#365F65]">Alur Pengajuan Aktivasi</h3>
                <p class="mt-1 text-sm text-[#7A9290]">Posisi setiap kerja sama dalam proses. Klik tahap untuk menyaring tabel.</p>

                
                <?php if($totalAktivasi > 0): ?>
                    <div class="mt-5 flex h-3 overflow-hidden rounded-full bg-[#E7EFEC]" role="img"
                         aria-label="Sebaran status aktivasi dari <?php echo e($totalAktivasi); ?> kerja sama">
                        <?php $__currentLoopData = $alur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $n = $perAktivasi[$tahap['status']] ?? 0; ?>
                            <?php if($n > 0): ?>
                                <div style="width: <?php echo e(($n / $totalAktivasi) * 100); ?>%; background: <?php echo e($tahap['warna']); ?>"
                                     title="<?php echo e($tahap['status']); ?>: <?php echo e($n); ?>"></div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($jumlahDitolak > 0): ?>
                            <div style="width: <?php echo e(($jumlahDitolak / $totalAktivasi) * 100); ?>%; background: #D14B4B"
                                 title="Ditolak: <?php echo e($jumlahDitolak); ?>"></div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                
                <div class="mt-5 grid grid-cols-2 gap-3 lg:grid-cols-[1fr_auto_1fr_auto_1fr_auto_1fr] lg:items-stretch lg:gap-2">
                    <?php $__currentLoopData = $alur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $tahap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $n = $perAktivasi[$tahap['status']] ?? 0; ?>

                        <a href="<?php echo e(route('aktivasi', ['status' => $tahap['status']])); ?>"
                           class="group block rounded-xl border border-[#E2EBE9] bg-[#F8FAF9] p-4 transition hover:border-[#B6C7C4] hover:bg-white hover:shadow-sm
                                  <?php echo e(request('status') === $tahap['status'] ? 'ring-2 ring-[#527D82]' : ''); ?>">
                            <span class="block h-1 w-8 rounded-full" style="background: <?php echo e($tahap['warna']); ?>"></span>
                            <p class="mt-3 text-xs font-semibold text-[#7A9290]"><?php echo e($i + 1); ?>. <?php echo e($tahap['status']); ?></p>
                            <p class="mt-1 text-2xl font-bold <?php echo e($tahap['kelas']); ?>"><?php echo e($n); ?></p>
                            <p class="mt-0.5 text-xs text-[#8BA5A2]"><?php echo e($persen($n)); ?>% · <?php echo e($tahap['ket']); ?></p>
                        </a>

                        <?php if(! $loop->last): ?>
                            <div class="hidden items-center justify-center text-[#B6C7C4] lg:flex" aria-hidden="true">
                                <svg class="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="m9 6 6 6-6 6"/>
                                </svg>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                
                <div class="mt-3 flex flex-wrap items-center gap-3 rounded-xl border border-dashed border-red-200 bg-red-50/50 px-4 py-3">
                    <svg class="h-4 w-4 shrink-0 text-red-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <path d="M6 3v6a4 4 0 0 0 4 4h8m0 0-4-4m4 4-4 4"/>
                    </svg>
                    <p class="text-sm text-[#527D82]">Cabang dari <span class="font-semibold">Menunggu Keputusan</span>:</p>
                    <a href="<?php echo e(route('aktivasi', ['status' => 'Ditolak'])); ?>"
                       class="inline-flex items-center gap-2 rounded-full bg-white px-3 py-1 text-sm font-semibold text-red-700 ring-1 ring-red-200 transition hover:bg-red-50">
                        Ditolak <span class="rounded-full bg-red-100 px-2 text-xs"><?php echo e($jumlahDitolak); ?></span>
                    </a>
                </div>
            </div>

            <div class="grid grid-cols-1 gap-6 xl:grid-cols-3">

                
                <div class="rounded-xl border border-[#E2EBE9] p-5">
                    <h3 class="font-bold text-[#365F65]">Posisi Kontrak Fisik</h3>
                    <p class="mt-1 text-sm text-[#7A9290]">Dari BA sampai kontrak selesai.</p>

                    <div class="mt-5 space-y-4">
                        <?php $__currentLoopData = $perKontrakFisik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posisi => $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <div class="mb-1.5 flex items-center justify-between gap-3 text-sm">
                                    <a href="<?php echo e(route('aktivasi', ['kontrak_fisik' => $posisi])); ?>"
                                       class="font-semibold text-[#527D82] hover:underline"><?php echo e($posisi); ?></a>
                                    <span class="font-bold text-[#365F65]"><?php echo e($n); ?></span>
                                </div>
                                <div class="h-3 overflow-hidden rounded-full bg-[#E7EFEC]">
                                    <div class="h-full rounded-full"
                                         style="width: <?php echo e($n > 0 ? max(4, ($n / $maksFisik) * 100) : 0); ?>%; background: <?php echo e($warnaFisik[$posisi] ?? '#8BA5A2'); ?>"></div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                
                <div class="rounded-xl border border-[#E2EBE9] p-5">
                    <h3 class="font-bold text-[#365F65]">Kontrak Sistem</h3>
                    <p class="mt-1 text-sm text-[#7A9290]">Aktif otomatis setelah pusat menyetujui.</p>

                    <div class="mt-5 flex flex-col items-center gap-5">
                        <?php if (isset($component)) { $__componentOriginal0e1bcee2085a0cf16601584b1c042f15 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0e1bcee2085a0cf16601584b1c042f15 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.donut','data' => ['segments' => $segmenSistem,'center' => $persen($sistemAktif) . '%','sub' => 'Sudah aktif']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('donut'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['segments' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($segmenSistem),'center' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($persen($sistemAktif) . '%'),'sub' => 'Sudah aktif']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0e1bcee2085a0cf16601584b1c042f15)): ?>
<?php $attributes = $__attributesOriginal0e1bcee2085a0cf16601584b1c042f15; ?>
<?php unset($__attributesOriginal0e1bcee2085a0cf16601584b1c042f15); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0e1bcee2085a0cf16601584b1c042f15)): ?>
<?php $component = $__componentOriginal0e1bcee2085a0cf16601584b1c042f15; ?>
<?php unset($__componentOriginal0e1bcee2085a0cf16601584b1c042f15); ?>
<?php endif; ?>

                        <div class="w-full space-y-3">
                            <?php $__currentLoopData = $segmenSistem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex items-center gap-3">
                                    <span class="h-3 w-3 shrink-0 rounded-full" style="background: <?php echo e($seg['color']); ?>"></span>
                                    <span class="flex-1 text-sm text-[#527D82]"><?php echo e($seg['label']); ?></span>
                                    <span class="text-sm font-bold text-[#365F65]"><?php echo e($seg['value']); ?></span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

                
                <div class="rounded-xl border border-[#E2EBE9] p-5">
                    <h3 class="font-bold text-[#365F65]">Aktivasi per Terminal</h3>
                    <p class="mt-1 text-sm text-[#7A9290]">Berdasarkan lokasi tenant.</p>

                    <?php $maksTerminal = max(1, (int) $perTerminal->max('total')); ?>

                    <div class="mt-5 space-y-5">
                        <?php $__empty_1 = true; $__currentLoopData = $perTerminal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nama => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php $belum = $d['total'] - $d['aktif'] - $d['menunggu']; ?>
                            <div>
                                <div class="mb-1.5 flex items-center justify-between gap-3 text-sm">
                                    <span class="font-semibold text-[#527D82]"><?php echo e($nama); ?></span>
                                    <span class="font-bold text-[#365F65]"><?php echo e($d['total']); ?> kerja sama</span>
                                </div>
                                <div class="flex h-3 overflow-hidden rounded-full bg-[#E7EFEC]"
                                     style="width: <?php echo e(max(10, ($d['total'] / $maksTerminal) * 100)); ?>%"
                                     role="img" aria-label="<?php echo e($nama); ?>: <?php echo e($d['aktif']); ?> aktif, <?php echo e($d['menunggu']); ?> menunggu keputusan, <?php echo e($belum); ?> belum">
                                    <div class="bg-emerald-600" style="width: <?php echo e(($d['aktif'] / $d['total']) * 100); ?>%"></div>
                                    <div class="bg-amber-500" style="width: <?php echo e(($d['menunggu'] / $d['total']) * 100); ?>%"></div>
                                </div>
                                <p class="mt-1 text-xs text-[#8BA5A2]"><?php echo e($d['aktif']); ?> aktif · <?php echo e($d['menunggu']); ?> menunggu · <?php echo e($belum); ?> lainnya</p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="rounded-xl bg-[#F8FAF9] px-4 py-8 text-center text-sm text-[#7A9290]">Belum ada data.</p>
                        <?php endif; ?>
                    </div>

                    <div class="mt-5 flex items-center gap-4 border-t border-[#E2EBE9] pt-3 text-xs text-[#7A9290]">
                        <span class="inline-flex items-center gap-1.5"><span class="h-2.5 w-2.5 rounded-full bg-emerald-600"></span>Aktif</span>
                        <span class="inline-flex items-center gap-1.5"><span class="h-2.5 w-2.5 rounded-full bg-amber-500"></span>Menunggu</span>
                    </div>
                </div>
            </div>

            
            <div class="rounded-xl border border-[#E2EBE9] p-5">
                <h3 class="font-bold text-[#365F65]">Masa Berlaku Segera Berakhir</h3>
                <p class="mt-1 text-sm text-[#7A9290]">Kontrak sistem aktif yang berakhir dalam 90 hari ke depan atau sudah lewat.</p>

                <?php $__empty_1 = true; $__currentLoopData = $segeraBerakhir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $sisa = (int) floor(now()->startOfDay()->diffInDays($ks->tanggal_berakhir->copy()->startOfDay(), false));
                        $lewat = $sisa < 0;
                        $mendesak = $sisa <= 30;
                        $totalMasa = $ks->tanggal_mulai ? max(1, $ks->tanggal_mulai->diffInDays($ks->tanggal_berakhir)) : null;
                        $berjalan = $totalMasa ? max(0, min(100, round(($ks->tanggal_mulai->diffInDays(now(), false) / $totalMasa) * 100))) : 100;
                    ?>
                    <a href="<?php echo e(route('aktivasi.show', $ks->id)); ?>"
                       class="mt-4 flex flex-col gap-3 rounded-xl border border-[#E2EBE9] bg-[#F8FAF9] p-4 transition first:mt-5 hover:border-[#B6C7C4] hover:bg-white sm:flex-row sm:items-center">
                        <div class="min-w-0 sm:w-64">
                            <p class="truncate font-semibold text-[#365F65]"><?php echo e($ks->mitra_usaha ?: '-'); ?></p>
                            <p class="mt-0.5 text-xs text-[#8BA5A2]">
                                <?php echo e($ks->brand ?: $ks->tenant?->nama_tenant ?: '-'); ?> · <?php echo e($ks->lokasi?->kode_tampilan ?: 'Tanpa lokasi'); ?>

                            </p>
                        </div>

                        <div class="flex-1">
                            <div class="h-2.5 overflow-hidden rounded-full bg-[#E7EFEC]">
                                <div class="h-full rounded-full <?php echo e($lewat ? 'bg-red-500' : ($mendesak ? 'bg-amber-500' : 'bg-[#365F65]')); ?>"
                                     style="width: <?php echo e($berjalan); ?>%"></div>
                            </div>
                            <p class="mt-1 text-xs text-[#8BA5A2]">Berakhir <?php echo e($ks->tanggal_berakhir->format('d M Y')); ?></p>
                        </div>

                        <span class="inline-flex shrink-0 justify-center rounded-full px-3 py-1.5 text-xs font-semibold
                            <?php echo e($lewat ? 'bg-red-50 text-red-700' : ($mendesak ? 'bg-amber-50 text-amber-700' : 'bg-[#EAF2F1] text-[#365F65]')); ?>">
                            <?php echo e($lewat ? 'Lewat ' . abs($sisa) . ' hari' : $sisa . ' hari lagi'); ?>

                        </span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="mt-5 rounded-xl bg-[#F8FAF9] px-4 py-8 text-center text-sm text-[#7A9290]">
                        Tidak ada kontrak aktif yang berakhir dalam 90 hari.
                    </p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    
    <section class="overflow-hidden rounded-2xl border border-[#E2EBE9] bg-white shadow-sm">

        <div class="border-b border-[#E2EBE9] p-5">
            <div class="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
                <div>
                    <h2 class="font-bold text-[#365F65]">Daftar Tenant</h2>
                    <p class="mt-0.5 text-sm text-[#8BA5A2]">
                        Seluruh kerja sama beserta posisi BA/kontrak dan status aktivasinya.
                    </p>
                </div>

                <form method="GET" action="<?php echo e(route('aktivasi')); ?>"
                      class="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:flex xl:flex-wrap xl:items-end">

                    <div class="xl:w-64">
                        <label for="search" class="mb-1 block text-xs font-semibold text-[#527D82]">Pencarian</label>
                        <input type="search" id="search" name="search" value="<?php echo e(request('search')); ?>"
                               placeholder="Mitra, brand, nomor…" class="<?php echo e($kelasInput); ?>">
                    </div>

                    <div>
                        <label for="kontrak_fisik" class="mb-1 block text-xs font-semibold text-[#527D82]">Kontrak Fisik</label>
                        <select id="kontrak_fisik" name="kontrak_fisik" onchange="this.form.submit()" class="<?php echo e($kelasInput); ?>">
                            <option value="">Semua</option>
                            <?php $__currentLoopData = $opsiKontrakFisik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pilihan); ?>" <?php if(request('kontrak_fisik') === $pilihan): echo 'selected'; endif; ?>><?php echo e($pilihan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div>
                        <label for="kontrak_sistem" class="mb-1 block text-xs font-semibold text-[#527D82]">Kontrak Sistem</label>
                        <select id="kontrak_sistem" name="kontrak_sistem" onchange="this.form.submit()" class="<?php echo e($kelasInput); ?>">
                            <option value="">Semua</option>
                            <?php $__currentLoopData = $opsiKontrakSistem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pilihan); ?>" <?php if(request('kontrak_sistem') === $pilihan): echo 'selected'; endif; ?>><?php echo e($pilihan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div>
                        <label for="status" class="mb-1 block text-xs font-semibold text-[#527D82]">Aktivasi</label>
                        <select id="status" name="status" onchange="this.form.submit()" class="<?php echo e($kelasInput); ?>">
                            <option value="">Semua</option>
                            <?php $__currentLoopData = $opsiAktivasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilihanStatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pilihanStatus); ?>" <?php if(request('status') === $pilihanStatus): echo 'selected'; endif; ?>><?php echo e($pilihanStatus); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="flex items-center gap-2">
                        <button type="submit"
                                class="inline-flex items-center rounded-xl bg-[#365F65] px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-[#294F55]">
                            Cari
                        </button>
                        <?php if($adaFilter): ?>
                            <a href="<?php echo e(route('aktivasi')); ?>"
                               class="inline-flex items-center rounded-xl border border-[#DCE6E4] px-4 py-2.5 text-sm font-semibold text-[#527D82] transition hover:bg-[#F5F8F7]">
                                Reset
                            </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <?php if($adaFilter): ?>
                <div class="mt-4 flex flex-wrap items-center gap-2 border-t border-[#E2EBE9] pt-3">
                    <span class="text-xs text-[#8BA5A2]">Filter aktif:</span>
                    <?php $__currentLoopData = ['search' => 'Cari', 'kontrak_fisik' => 'Kontrak Fisik', 'kontrak_sistem' => 'Kontrak Sistem', 'status' => 'Aktivasi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(request()->filled($key)): ?>
                            <a href="<?php echo e(request()->fullUrlWithQuery([$key => null])); ?>"
                               class="inline-flex items-center gap-1.5 rounded-full bg-[#EAF2F1] px-3 py-1 text-xs font-semibold text-[#365F65] transition hover:bg-[#DCE9E7]"
                               title="Hapus filter ini">
                                <?php echo e($label); ?>: <?php echo e(request($key)); ?> <span aria-hidden="true">×</span>
                            </a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full min-w-[1250px] text-left text-sm">
                <thead class="bg-[#F3F6F5] text-xs uppercase tracking-wide text-[#527D82]">
                    <tr>
                        <th class="px-5 py-4 font-semibold">No.</th>
                        <th class="px-5 py-4 font-semibold">Tenant / Mitra</th>
                        <th class="px-5 py-4 font-semibold">Lokasi</th>
                        <th class="px-5 py-4 font-semibold">Progres</th>
                        <th class="px-5 py-4 font-semibold">Kontrak Fisik</th>
                        <th class="px-5 py-4 font-semibold">Kontrak Sistem</th>
                        <th class="px-5 py-4 font-semibold">Aktivasi</th>
                        <th class="px-5 py-4 font-semibold">Masa Berlaku</th>
                        <th class="px-5 py-4 text-center font-semibold">Aksi</th>
                    </tr>
                </thead>

                <tbody class="divide-y divide-[#E2EBE9]">
                    <?php $__empty_1 = true; $__currentLoopData = $dataAktivasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $kerjaSama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $lokasi = $kerjaSama->lokasi;
                            $statusAktivasi = $kerjaSama->statusAktivasi();
                            $statusFisik = $kerjaSama->posisiKontrakFisik();
                            $statusSistem = $kerjaSama->statusKontrakSistem();

                            $tahap = $kerjaSama->tahapProgres();
                            $tahapSelesai = collect($tahap)->where('status', 'done')->count();

                            $badgeAktivasi = match ($statusAktivasi) {
                                'Disetujui' => 'bg-emerald-50 text-emerald-700',
                                'Ditolak' => 'bg-red-50 text-red-700',
                                'Menunggu Keputusan' => 'bg-amber-50 text-amber-700',
                                default => 'bg-[#F3F6F5] text-[#7A9290]',
                            };

                            $badgeFisik = match ($statusFisik) {
                                'Kontrak Selesai' => 'bg-emerald-50 text-emerald-700',
                                'Kontrak Dalam Proses' => 'bg-blue-50 text-blue-700',
                                'BA Selesai' => 'bg-teal-50 text-teal-700',
                                'BA Belum TTD' => 'bg-amber-50 text-amber-700',
                                default => 'bg-[#F3F6F5] text-[#7A9290]',
                            };

                            $badgeSistem = $statusSistem === 'Aktif'
                                ? 'bg-emerald-50 text-emerald-700'
                                : 'bg-[#F3F6F5] text-[#7A9290]';
                        ?>

                        <tr class="transition hover:bg-[#F8FAF9]">
                            <td class="px-5 py-4 text-[#8BA5A2]"><?php echo e($index + 1); ?></td>

                            <td class="px-5 py-4">
                                <p class="font-semibold text-[#365F65]"><?php echo e($kerjaSama->mitra_usaha ?: '-'); ?></p>
                                <p class="mt-1 text-xs text-[#7A9290]">
                                    <?php echo e($kerjaSama->brand ?: $kerjaSama->tenant?->nama_tenant ?: '-'); ?>

                                    · KS-<?php echo e(str_pad($kerjaSama->id, 4, '0', STR_PAD_LEFT)); ?>

                                </p>
                            </td>

                            <td class="px-5 py-4 text-[#527D82]">
                                <?php if($lokasi): ?>
                                    <p class="font-medium"><?php echo e($lokasi->terminal ?: '-'); ?></p>
                                    <p class="mt-1 text-xs text-[#7A9290]"><?php echo e($lokasi->kode_tampilan ?: $lokasi->lokasi ?: ''); ?></p>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>

                            <td class="px-5 py-4">
                                <div class="flex items-center gap-2.5">
                                    <div class="flex gap-1" role="img"
                                         aria-label="Progres <?php echo e($tahapSelesai); ?> dari <?php echo e(count($tahap)); ?> tahap">
                                        <?php $__currentLoopData = $tahap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="h-2 w-5 rounded-full <?php echo e(match ($t['status']) {
                                                    'done' => 'bg-[#365F65]',
                                                    'rejected' => 'bg-red-400',
                                                    default => 'bg-[#E1EAE8]',
                                                }); ?>"
                                                  title="<?php echo e($t['label']); ?>: <?php echo e(match ($t['status']) {
                                                    'done' => 'selesai',
                                                    'rejected' => 'ditolak',
                                                    default => 'belum',
                                                }); ?>"></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <span class="text-xs font-semibold tabular-nums text-[#527D82]"><?php echo e($tahapSelesai); ?>/<?php echo e(count($tahap)); ?></span>
                                </div>
                            </td>

                            <td class="px-5 py-4">
                                <span class="inline-flex whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-semibold <?php echo e($badgeFisik); ?>">
                                    <?php echo e($statusFisik); ?>

                                </span>
                            </td>

                            <td class="px-5 py-4">
                                <span class="inline-flex whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-semibold <?php echo e($badgeSistem); ?>">
                                    <?php echo e($statusSistem); ?>

                                </span>
                                <?php if($statusSistem === 'Aktif' && $kerjaSama->tanggal_mulai): ?>
                                    <p class="mt-1 text-xs text-[#7A9290]">Sejak <?php echo e($kerjaSama->tanggal_mulai->format('d M Y')); ?></p>
                                <?php endif; ?>
                            </td>

                            <td class="px-5 py-4">
                                <span class="inline-flex whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-semibold <?php echo e($badgeAktivasi); ?>">
                                    <?php echo e($statusAktivasi); ?>

                                </span>
                            </td>

                            <td class="px-5 py-4 text-[#527D82]">
                                <?php if($kerjaSama->tanggal_mulai && $kerjaSama->tanggal_berakhir): ?>
                                    <?php echo e($kerjaSama->tanggal_mulai->format('d M Y')); ?>

                                    – <?php echo e($kerjaSama->tanggal_berakhir->format('d M Y')); ?>

                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>

                            <td class="px-5 py-4 text-center">
                                <a href="<?php echo e(route('aktivasi.show', $kerjaSama->id)); ?>"
                                   class="inline-block whitespace-nowrap rounded-lg bg-[#365F65] px-4 py-2 text-xs font-semibold text-white transition hover:bg-[#294F55]">
                                    Detail
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="px-5 py-14 text-center">
                                <p class="font-semibold text-[#365F65]">Data aktivasi belum ditemukan</p>
                                <p class="mt-1 text-sm text-[#8BA5A2]">
                                    Pastikan dokumen BA tersedia atau ubah kata kunci pencarian.
                                </p>
                                <?php if($adaFilter): ?>
                                    <a href="<?php echo e(route('aktivasi')); ?>" class="mt-3 inline-block text-sm font-semibold text-[#527D82] hover:underline">Reset filter</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="flex flex-col gap-2 border-t border-[#E2EBE9] px-5 py-4 text-sm text-[#8BA5A2] sm:flex-row sm:items-center sm:justify-between">
            <p>Menampilkan <?php echo e($dataAktivasi->count()); ?> dari <?php echo e($totalAktivasi); ?> kerja sama</p>
            <p>Pengajuan aktivasi baru dapat dibuat setelah BA tersedia.</p>
        </div>
    </section>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\AeroTrack\resources\views/aktivasi/index.blade.php ENDPATH**/ ?>