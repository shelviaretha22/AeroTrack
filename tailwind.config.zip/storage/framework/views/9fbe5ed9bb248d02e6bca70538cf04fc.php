<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<div class="min-h-screen w-full overflow-x-hidden bg-[#F3F6F5]">

    <div class="min-h-screen w-full flex flex-col lg:flex-row">

        
        <div class="relative w-full lg:w-[62%]
                    min-h-[430px] lg:min-h-0 lg:h-screen
                    overflow-hidden">

            
            <img
                src="<?php echo e(asset('images/airport-bg.jpg')); ?>"
                alt="Juanda Airport"
                class="absolute inset-0 w-full h-full object-cover"
            >

            
            <div class="absolute inset-0 bg-[#3F6970]/35"></div>

            
            <div class="absolute inset-0 bg-gradient-to-r
                        from-[#294F55]/70
                        via-[#416B70]/38
                        to-transparent">
            </div>

            
            <div class="absolute inset-0 bg-gradient-to-t
                        from-[#294F55]/55
                        via-transparent
                        to-transparent">
            </div>

            
            <div class="absolute inset-0 bg-gradient-to-br
                        from-[#527D82]/15
                        via-transparent
                        to-[#B8CECA]/10">
            </div>

            
            <div class="absolute top-5 left-5 lg:left-10
                        w-48 h-32 rounded-full
                        bg-[#294F55]/25 blur-2xl">
            </div>


            
            <div class="relative z-10 min-h-[430px] lg:h-full
                        flex flex-col
                        px-5 sm:px-8 md:px-10 lg:px-12 xl:px-14
                        py-6 sm:py-8 lg:py-9">

                
                <div class="flex items-start justify-between">

                    
                    <img
                        src="<?php echo e(asset('images/aerotrack-logo.png')); ?>"
                        alt="AeroTrack"
                        class="w-32 sm:w-44 lg:w-48 h-auto
                               drop-shadow-[0_4px_12px_rgba(0,0,0,0.35)]"
                    >

                    
                    <div class="hidden sm:flex items-center
                                px-4 py-2
                                rounded-full
                                bg-[#355F65]/55
                                backdrop-blur-md
                                border border-white/15
                                text-white/90
                                text-[10px]
                                font-semibold
                                tracking-[0.18em]">

                        COMMERCIAL MANAGEMENT

                    </div>

                </div>


                
                <div class="my-auto max-w-[600px]">

                    
                    <div class="flex items-center gap-3 mb-5">

                        <div class="w-10 h-[2px] bg-[#B8CECA]"></div>

                        <span class="text-[#E3EEEC]
                                     text-xs sm:text-sm
                                     font-semibold
                                     tracking-[0.18em]
                                     uppercase">

                            Airport Tenant Management

                        </span>

                    </div>


                    
                    <h1 class="text-white
                               text-3xl sm:text-4xl md:text-5xl lg:text-[54px]
                               leading-[1.05]
                               font-bold
                               tracking-tight
                               drop-shadow-[0_3px_10px_rgba(0,0,0,0.45)]">

                        Manage Your

                        <span class="block text-[#D9E5E3]">
                            Airport Tenant
                        </span>

                        Smarter.

                    </h1>


                    
                    <p class="mt-6 max-w-[520px]
                              text-[#F0F5F4]/90
                              text-sm sm:text-base
                              leading-relaxed
                              drop-shadow-[0_2px_6px_rgba(0,0,0,0.35)]">

                        Satu platform untuk memantau tenant,
                        lokasi, kontrak, aktivasi, dan pendapatan
                        dalam pengelolaan tenant bandara.

                    </p>


                    
                    <div class="mt-8 flex flex-wrap gap-3">

                        <div class="px-4 py-2 rounded-full
                                    bg-[#365F65]/65
                                    backdrop-blur-md
                                    border border-white/15
                                    text-white
                                    text-xs font-medium">

                            Tenant Monitoring

                        </div>

                        <div class="px-4 py-2 rounded-full
                                    bg-[#365F65]/65
                                    backdrop-blur-md
                                    border border-white/15
                                    text-white
                                    text-xs font-medium">

                            Contract Tracking

                        </div>

                        <div class="px-4 py-2 rounded-full
                                    bg-[#365F65]/65
                                    backdrop-blur-md
                                    border border-white/15
                                    text-white
                                    text-xs font-medium">

                            Revenue Monitoring

                        </div>

                    </div>

                </div>


                
                <div class="flex items-end justify-between gap-5">

                    
                    <div class="flex items-center gap-4">

                        
                        <div class="flex items-center justify-center
                                    w-14 h-14
                                    rounded-xl
                                    bg-white/90
                                    backdrop-blur-sm
                                    shadow-[0_4px_15px_rgba(0,0,0,0.18)]
                                    p-2.5">

                            <img
                                src="<?php echo e(asset('images/angkasa-pura-logo.png')); ?>"
                                alt="PT Angkasa Pura Indonesia"
                                class="max-w-full max-h-full object-contain"
                            >

                        </div>


                        
                        <div class="text-white
                                    drop-shadow-[0_2px_5px_rgba(0,0,0,0.4)]">

                            <p class="text-[9px]
                                      uppercase
                                      tracking-[0.2em]
                                      text-[#D9E5E3]/80
                                      font-semibold">

                                Airport Tenant Management for

                            </p>

                            <p class="mt-1
                                      text-sm
                                      font-semibold">

                                Bandar Udara Internasional Juanda

                            </p>

                            <p class="mt-0.5
                                      text-[11px]
                                      text-[#E3EEEC]/85">

                                PT Angkasa Pura Indonesia

                            </p>

                        </div>

                    </div>


                    
                    <div class="hidden sm:block
                                text-right
                                text-white/65
                                text-[9px]
                                tracking-[0.18em]
                                uppercase">

                        <p>
                            AEROTRACK SYSTEM
                        </p>

                        <p class="mt-1">
                            2026
                        </p>

                    </div>

                </div>

            </div>

        </div>


        
        <div class="relative w-full lg:w-[38%]
                    min-h-[600px] lg:min-h-0 lg:h-screen
                    bg-[#F8FAF9]
                    flex items-center justify-center
                    px-5 sm:px-8 md:px-10 lg:px-12
                    py-12 sm:py-14 lg:py-0
                    overflow-hidden">


            
            <div class="absolute
                        -top-24 -right-24
                        w-72 h-72
                        rounded-full
                        bg-[#D9E5E3]/55">
            </div>

            <div class="absolute
                        -bottom-28 -left-28
                        w-80 h-80
                        rounded-full
                        bg-[#B8CECA]/20">
            </div>


            
            <div class="relative z-10
                        w-full max-w-[410px]">


                
                <div class="mb-10">

                    <div class="flex items-center gap-3">

                        <img
                            src="<?php echo e(asset('images/aerotrack-logo.png')); ?>"
                            alt="AeroTrack"
                            class="w-28 sm:w-32 md:w-36 h-auto"
                        >

                    </div>

                    <div class="mt-7">

                        <p class="text-[#4F8189]
                                  text-xs
                                  font-bold
                                  tracking-[0.2em]
                                  uppercase">

                            Welcome Back

                        </p>

                        <h2 class="mt-2
                                   text-2xl sm:text-3xl
                                   font-bold
                                   text-[#365F65]">

                            Log in to continue

                        </h2>

                        <p class="mt-2
                                  text-sm
                                  text-gray-500">

                            Login untuk mengakses AeroTrack
                            Commercial Management System.

                        </p>

                    </div>

                </div>


                
                <?php if (isset($component)) { $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-session-status','data' => ['class' => 'mb-4','status' => session('status')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $attributes = $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $component = $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>


                
                <form method="POST" action="<?php echo e(route('login')); ?>">

                    <?php echo csrf_field(); ?>


                    
                    <div>

                        <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'email','value' => __('Email'),'class' => 'text-[#365F65] font-semibold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'email','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Email')),'class' => 'text-[#365F65] font-semibold']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal18c21970322f9e5c938bc954620c12bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18c21970322f9e5c938bc954620c12bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['id' => 'email','class' => 'block mt-2 w-full
                                   border-[#D5E1DF]
                                   focus:border-[#6E9AA0]
                                   focus:ring-[#6E9AA0]/20
                                   rounded-xl
                                   bg-white','type' => 'email','name' => 'email','value' => old('email'),'required' => true,'autofocus' => true,'autocomplete' => 'username','placeholder' => 'Enter your email']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'email','class' => 'block mt-2 w-full
                                   border-[#D5E1DF]
                                   focus:border-[#6E9AA0]
                                   focus:ring-[#6E9AA0]/20
                                   rounded-xl
                                   bg-white','type' => 'email','name' => 'email','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('email')),'required' => true,'autofocus' => true,'autocomplete' => 'username','placeholder' => 'Enter your email']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $attributes = $__attributesOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__attributesOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $component = $__componentOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__componentOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('email'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('email')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>

                    </div>


                    
                    <div class="mt-5">

                        <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'password','value' => __('Password'),'class' => 'text-[#365F65] font-semibold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'password','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Password')),'class' => 'text-[#365F65] font-semibold']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal18c21970322f9e5c938bc954620c12bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18c21970322f9e5c938bc954620c12bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['id' => 'password','class' => 'block mt-2 w-full
                                   border-[#D5E1DF]
                                   focus:border-[#6E9AA0]
                                   focus:ring-[#6E9AA0]/20
                                   rounded-xl
                                   bg-white','type' => 'password','name' => 'password','required' => true,'autocomplete' => 'current-password','placeholder' => 'Enter your password']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'password','class' => 'block mt-2 w-full
                                   border-[#D5E1DF]
                                   focus:border-[#6E9AA0]
                                   focus:ring-[#6E9AA0]/20
                                   rounded-xl
                                   bg-white','type' => 'password','name' => 'password','required' => true,'autocomplete' => 'current-password','placeholder' => 'Enter your password']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $attributes = $__attributesOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__attributesOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $component = $__componentOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__componentOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('password'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('password')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>

                    </div>


                    
                    <div class="flex items-center justify-between mt-5">

                        <label
                            for="remember_me"
                            class="inline-flex items-center"
                        >

                            <input
                                id="remember_me"
                                type="checkbox"
                                class="rounded
                                       border-gray-300
                                       text-[#4F8189]
                                       shadow-sm
                                       focus:ring-[#6E9AA0]"
                                name="remember"
                            >

                            <span class="ms-2
                                         text-sm
                                         text-gray-500">

                                Remember me

                            </span>

                        </label>


                        <?php if(Route::has('password.request')): ?>

                            <a
                                class="text-sm
                                       text-[#4F8189]
                                       hover:text-[#365F65]
                                       font-medium
                                       transition"
                                href="<?php echo e(route('password.request')); ?>"
                            >

                                Forgot password?

                            </a>

                        <?php endif; ?>

                    </div>


                    
                    <div class="mt-7">

                        <button
                            type="submit"
                            class="w-full
                                   py-3.5
                                   rounded-xl
                                   bg-[#4F8189]
                                   hover:bg-[#3F7078]
                                   text-white
                                   font-semibold
                                   text-sm
                                   tracking-wide
                                   transition
                                   duration-200
                                   shadow-lg
                                   shadow-[#4F8189]/20
                                   hover:shadow-[#4F8189]/30"
                        >

                            Log In

                        </button>

                    </div>

                </form>


                
                <div class="mt-10 pt-6
                            border-t border-[#DCE6E4]">

                    <div class="flex items-center justify-between">

                        <div>

                            <p class="text-[10px]
                                      font-semibold
                                      tracking-[0.16em]
                                      text-[#6E9AA0]
                                      uppercase">

                                AeroTrack

                            </p>

                            <p class="mt-1
                                      text-[10px]
                                      text-gray-400">

                                Airport Tenant Management System

                            </p>

                        </div>


                        <div class="text-right">

                            <p class="text-[10px]
                                      text-gray-400">

                                Juanda Airport

                            </p>

                            <p class="mt-1
                                      text-[10px]
                                      text-gray-400">

                                © 2026

                            </p>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\AeroTrack\resources\views/auth/login.blade.php ENDPATH**/ ?>