
<?php
    $belum = $notifRingkas['belum'] ?? 0;
    $daftarLonceng = $notifRingkas['items'] ?? collect();
?>

<div class="relative" x-data="{ buka: false }" @keydown.escape.window="buka = false" @click.outside="buka = false">
    <button type="button" @click="buka = !buka" :aria-expanded="buka" aria-haspopup="true"
            aria-label="Notifikasi<?php echo e($belum > 0 ? ', ' . $belum . ' belum dibaca' : ''); ?>"
            class="relative flex h-10 w-10 items-center justify-center rounded-xl bg-[#F3F6F5] text-[#527D82] transition hover:bg-[#E8F0EE]">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8">
            <path stroke-linecap="round" stroke-linejoin="round" d="M18 8a6 6 0 00-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/>
        </svg>

        <?php if($belum > 0): ?>
            <span class="absolute -right-1 -top-1 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-red-500 px-1 text-[10px] font-bold leading-none text-white ring-2 ring-white">
                <?php echo e($belum > 9 ? '9+' : $belum); ?>

            </span>
        <?php endif; ?>
    </button>

    <div x-show="buka" x-transition.origin.top.right style="display: none;"
         class="absolute right-[-3.5rem] z-50 mt-3 w-[calc(100vw-2rem)] max-w-sm overflow-hidden rounded-2xl border border-[#E2EBE9] bg-white shadow-xl sm:right-0 sm:w-96">

        <div class="flex items-center justify-between gap-3 border-b border-[#E2EBE9] px-4 py-3">
            <div>
                <p class="text-sm font-bold text-[#365F65]">Notifikasi</p>
                <p class="text-xs text-[#8BA5A2]"><?php echo e($belum > 0 ? $belum . ' belum dibaca' : 'Semua sudah dibaca'); ?></p>
            </div>

            <?php if($belum > 0): ?>
                <form action="<?php echo e(route('notifikasi.baca-semua')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="text-xs font-semibold text-[#527D82] hover:underline">Tandai semua dibaca</button>
                </form>
            <?php endif; ?>
        </div>

        <div class="max-h-[26rem] divide-y divide-[#EEF3F1] overflow-y-auto">
            <?php $__empty_1 = true; $__currentLoopData = $daftarLonceng; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('notifikasi.buka', ['k' => $n['kunci']])); ?>"
                   class="flex gap-3 px-4 py-3 transition hover:bg-[#F8FAF9] <?php echo e($n['dibaca'] ? '' : 'bg-[#F8FBFA]'); ?>">
                    <?php if (isset($component)) { $__componentOriginal6ebcfe4cdda59dadbf9997ea22f8f370 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6ebcfe4cdda59dadbf9997ea22f8f370 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.notif-icon','data' => ['jenis' => $n['jenis'],'level' => $n['level']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('notif-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['jenis' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($n['jenis']),'level' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($n['level'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6ebcfe4cdda59dadbf9997ea22f8f370)): ?>
<?php $attributes = $__attributesOriginal6ebcfe4cdda59dadbf9997ea22f8f370; ?>
<?php unset($__attributesOriginal6ebcfe4cdda59dadbf9997ea22f8f370); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6ebcfe4cdda59dadbf9997ea22f8f370)): ?>
<?php $component = $__componentOriginal6ebcfe4cdda59dadbf9997ea22f8f370; ?>
<?php unset($__componentOriginal6ebcfe4cdda59dadbf9997ea22f8f370); ?>
<?php endif; ?>

                    <div class="min-w-0 flex-1">
                        <p class="text-[13px] leading-snug text-[#365F65] <?php echo e($n['dibaca'] ? 'font-medium' : 'font-bold'); ?>"><?php echo e($n['judul']); ?></p>
                        <p class="mt-0.5 truncate text-xs text-[#7A9290]"><?php echo e($n['pesan']); ?></p>
                    </div>

                    <?php if (! ($n['dibaca'])): ?>
                        <span class="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-[#4F8189]" title="Belum dibaca"></span>
                    <?php endif; ?>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="px-4 py-10 text-center">
                    <p class="text-sm font-semibold text-[#365F65]">Tidak ada notifikasi</p>
                    <p class="mt-1 text-xs text-[#8BA5A2]">Semua urusan sudah beres.</p>
                </div>
            <?php endif; ?>
        </div>

        <a href="<?php echo e(route('notifikasi.index')); ?>"
           class="block border-t border-[#E2EBE9] bg-[#F8FAF9] px-4 py-3 text-center text-sm font-semibold text-[#527D82] transition hover:bg-[#F3F6F5]">
            Lihat semua notifikasi
        </a>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\AeroTrack\resources\views/notifikasi/_dropdown.blade.php ENDPATH**/ ?>