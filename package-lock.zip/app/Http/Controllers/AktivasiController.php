<?php

namespace App\Http\Controllers;

use App\Models\Aktivasi;
use App\Models\AktivasiProgres;
use App\Models\AktivasiRiwayat;
use App\Models\KerjaSama;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Throwable;

class AktivasiController extends Controller
{
    /**
     * Menampilkan kerja sama yang BA-nya sudah tersedia.
     */
    public function index(Request $request)
    {
        $semuaData = KerjaSama::with([
            'tenant',
            'lokasi.tenant',
            'aktivasi',
            'kontrakTerbaru',
        ])
            ->latest()
            ->get();

        $dataAktivasi = $semuaData;

        if ($request->filled('search')) {
            $keyword = strtolower(trim($request->search));

            $dataAktivasi = $dataAktivasi->filter(
                function ($kerjaSama) use ($keyword) {
                    $dataCari = [
                        $kerjaSama->aktivasi?->nomor_pengajuan,
                        $kerjaSama->mitra_usaha,
                        $kerjaSama->brand,
                        $kerjaSama->tenant?->nama_tenant,
                        (string) $kerjaSama->id,
                    ];

                    foreach ($dataCari as $nilai) {
                        if (
                            $nilai !== null &&
                            str_contains(
                                strtolower((string) $nilai),
                                $keyword
                            )
                        ) {
                            return true;
                        }
                    }

                    return false;
                }
            );
        }

        if ($request->filled('kontrak_fisik')) {
            $dataAktivasi = $dataAktivasi->filter(
                fn ($ks) => $ks->posisiKontrakFisik()
                    === $request->kontrak_fisik
            );
        }

        if ($request->filled('kontrak_sistem')) {
            $dataAktivasi = $dataAktivasi->filter(
                fn ($ks) => $ks->statusKontrakSistem()
                    === $request->kontrak_sistem
            );
        }

        if ($request->filled('status')) {
            $dataAktivasi = $dataAktivasi->filter(
                fn ($ks) => $ks->statusAktivasi() === $request->status
            );
        }

        return view('aktivasi.index', [
            'dataAktivasi' => $dataAktivasi->values(),
            'totalAktivasi' => $semuaData->count(),
            'menunggu' => $semuaData->filter(
                fn ($ks) => $ks->statusAktivasi() === 'Menunggu Keputusan'
            )->count(),
            'disetujui' => $semuaData->filter(
                fn ($ks) => $ks->statusAktivasi() === 'Disetujui'
            )->count(),
            'sistemAktif' => $semuaData->filter(
                fn ($ks) => $ks->statusKontrakSistem() === 'Aktif'
            )->count(),
            'opsiKontrakFisik' => KerjaSama::POSISI_KONTRAK_FISIK,
            'opsiKontrakSistem' => KerjaSama::STATUS_KONTRAK_SISTEM,
            'opsiAktivasi' => KerjaSama::STATUS_AKTIVASI,
        ]);
    }

    /**
     * Halaman Detail: tiga bagian per Kerja Sama.
     */
    public function show(KerjaSama $kerjaSama)
    {
        $kerjaSama->load([
            'tenant',
            'lokasi.tenant',
            'aktivasi',
            'aktivasis' => fn ($q) => $q->orderByDesc('id'),
            'progres',
            'kontrakTerbaru',
            'aktivasiRiwayats.user',
        ]);

        return view('aktivasi.show', [
            'kerjaSama' => $kerjaSama,
            'tenant' => $kerjaSama->tenant,
            'lokasi' => $kerjaSama->lokasi,
            'progres' => $kerjaSama->progres,
            'kontrak' => $kerjaSama->kontrakTerbaru,
        ]);
    }

    /**
     * Catatan perkembangan Kontrak Fisik.
     * Posisi BA/kontrak dihitung otomatis dari data.
     */
    public function updateKontrakFisik(
        Request $request,
        KerjaSama $kerjaSama
    ) {
        $validated = $request->validate([
            'kontrak_fisik_catatan' => ['nullable', 'string', 'max:2000'],
        ]);

        DB::transaction(function () use ($kerjaSama, $validated) {
            $progres = AktivasiProgres::firstOrNew([
                'kerja_sama_id' => $kerjaSama->id,
            ]);

            $progres->kontrak_fisik_catatan =
                $validated['kontrak_fisik_catatan'] ?? null;
            $progres->kontrak_fisik_updated_at = now();
            $progres->save();

            $this->catatRiwayat(
                $kerjaSama->id,
                'Kontrak Fisik',
                'Catatan perkembangan diperbarui.'
            );
        });

        return redirect()
            ->route('aktivasi.show', $kerjaSama->id)
            ->with('success', 'Catatan Kontrak Fisik berhasil disimpan.');
    }

    private function catatRiwayat(
        int $kerjaSamaId,
        string $komponen,
        string $keterangan
    ): void {
        AktivasiRiwayat::create([
            'kerja_sama_id' => $kerjaSamaId,
            'user_id' => Auth::id(),
            'komponen' => $komponen,
            'keterangan' => $keterangan,
        ]);
    }

    /**
     * Menyimpan tanda tangan PIC Commercial (gambar langsung / unggah).
     */
    private function simpanTtd(Request $request): string
    {
        if ($request->ttd_type === 'upload') {
            return $request->file('ttd_file')
                ->store('aktivasi/ttd', 'local');
        }

        $data = (string) $request->ttd_draw;

        if (!preg_match('#^data:image/png;base64,#', $data)) {
            throw new \RuntimeException('Tanda tangan tidak valid.');
        }

        $biner = base64_decode(
            substr($data, strpos($data, ',') + 1),
            true
        );

        if (
            $biner === false ||
            strlen($biner) > 2 * 1024 * 1024 ||
            @getimagesizefromstring($biner) === false
        ) {
            throw new \RuntimeException('Tanda tangan tidak valid.');
        }

        $path = 'aktivasi/ttd/' . uniqid('ttd_', true) . '.png';
        Storage::disk('local')->put($path, $biner);

        return $path;
    }

    /**
     * Membuat pengajuan aktivasi baru dan PDF secara otomatis.
     */
    public function requestAktivasi(Request $request, $kerjaSamaId)
    {
        $validated = $request->validate([
            'nama_penandatangan' => ['required', 'string', 'max:150'],
            'jabatan_penandatangan' => ['required', 'string', 'max:150'],
            'ttd_type' => ['required', 'in:draw,upload'],
            'ttd_draw' => ['required_if:ttd_type,draw', 'nullable', 'string'],
            'ttd_file' => [
                'required_if:ttd_type,upload',
                'nullable',
                'file',
                'mimes:png,jpg,jpeg',
                'max:2048',
            ],
        ], [
            'nama_penandatangan.required' => 'Nama penandatangan wajib diisi.',
            'jabatan_penandatangan.required' => 'Jabatan penandatangan wajib diisi.',
            'ttd_draw.required_if' => 'Tanda tangan wajib digambar.',
            'ttd_file.required_if' => 'File tanda tangan wajib diunggah.',
            'ttd_file.mimes' => 'Tanda tangan harus berupa PNG atau JPG.',
            'ttd_file.max' => 'Ukuran tanda tangan maksimal 2 MB.',
        ]);

        $aktivasi = null;
        $pathSurat = null;
        $pathTtd = null;

        try {
            $pathTtd = $this->simpanTtd($request);

            $aktivasi = DB::transaction(function () use (
                $kerjaSamaId,
                $validated,
                $pathTtd,
                $request
            ) {
                $kerjaSama = KerjaSama::with([
                    'tenant',
                    'lokasi',
                ])
                    ->lockForUpdate()
                    ->findOrFail($kerjaSamaId);

                if (!$kerjaSama->baTersedia()) {
                    throw new \RuntimeException(
                        'Pengajuan belum dapat dibuat karena dokumen BA belum tersedia.'
                    );
                }

                if (!$kerjaSama->tenant || !$kerjaSama->lokasi) {
                    throw new \RuntimeException(
                        'Data tenant atau lokasi belum lengkap.'
                    );
                }

                $pengajuanTerakhir = Aktivasi::where(
                    'kerja_sama_id',
                    $kerjaSama->id
                )
                    ->orderByDesc('id')
                    ->first();

                if (
                    $pengajuanTerakhir &&
                    $pengajuanTerakhir->status === 'Menunggu Keputusan'
                ) {
                    throw new \RuntimeException(
                        'Pengajuan aktivasi masih menunggu keputusan.'
                    );
                }

                if (
                    $pengajuanTerakhir &&
                    $pengajuanTerakhir->status === 'Disetujui'
                ) {
                    throw new \RuntimeException(
                        'Pengajuan sudah disetujui dan tidak dapat diajukan ulang.'
                    );
                }

                if (
                    $pengajuanTerakhir &&
                    $pengajuanTerakhir->status !== 'Ditolak'
                ) {
                    throw new \RuntimeException(
                        'Status pengajuan sebelumnya belum memungkinkan pengajuan baru.'
                    );
                }

                $aktivasi = Aktivasi::create([
                    'kerja_sama_id' => $kerjaSama->id,
                    'tanggal_pengajuan' => now()->toDateString(),
                    'status' => 'Menunggu Keputusan',
                    'ttd_commercial_path' => $pathTtd,
                    'ttd_type' => $validated['ttd_type'],
                    'nama_penandatangan' => $validated['nama_penandatangan'],
                    'jabatan_penandatangan' => $validated['jabatan_penandatangan'],
                ]);

                $aktivasi->nomor_pengajuan = sprintf(
                    'ACT/JUANDA/%s/%04d',
                    now()->format('Y'),
                    $aktivasi->id
                );

                $aktivasi->save();

                return $aktivasi;
            });

            $kerjaSama = KerjaSama::with([
                'tenant',
                'lokasi',
            ])->findOrFail($kerjaSamaId);

            $pdf = Pdf::loadView(
                'aktivasi.surat-pengajuan-pdf',
                [
                    'aktivasi' => $aktivasi,
                    'kerjaSama' => $kerjaSama,
                    'tenant' => $kerjaSama->tenant,
                    'lokasi' => $kerjaSama->lokasi,
                    'ttdDataUri' => $this->ttdDataUri($aktivasi),
                ]
            );

            $pathSurat = 'aktivasi/pengajuan/'
                . $aktivasi->id
                . '-surat.pdf';

            Storage::disk('local')->put(
                $pathSurat,
                $pdf->output()
            );

            $aktivasi->surat_pengajuan_path = $pathSurat;
            $aktivasi->save();

            $this->catatRiwayat(
                (int) $kerjaSamaId,
                'Aktivasi',
                'Pengajuan ' . $aktivasi->nomor_pengajuan
                    . ' dibuat dengan status "Menunggu Keputusan".'
            );

            return redirect()
                ->route('aktivasi.show', $kerjaSamaId)
                ->with(
                    'success',
                    'Pengajuan aktivasi berhasil dibuat dan surat PDF sudah tersedia.'
                );
        } catch (Throwable $e) {
            report($e);

            if ($pathSurat) {
                Storage::disk('local')->delete($pathSurat);
            }

            // Jika surat gagal dibuat, batalkan pengajuan agar tidak
            // tersisa data "Menunggu Keputusan" tanpa surat.
            if ($aktivasi && !$aktivasi->surat_pengajuan_path) {
                $aktivasi->delete();
            }

            if ($pathTtd) {
                Storage::disk('local')->delete($pathTtd);
            }

            if ($e instanceof \RuntimeException) {
                return back()->with('error', $e->getMessage());
            }

            $kolomHilang = $e instanceof \Illuminate\Database\QueryException
                && (
                    str_contains($e->getMessage(), 'no column')
                    || str_contains($e->getMessage(), 'Unknown column')
                    || str_contains($e->getMessage(), 'no such column')
                );

            $penyebab = $kolomHilang
                ? 'Kolom database belum ada. Jalankan "php artisan migrate" lalu coba lagi.'
                : \Illuminate\Support\Str::limit($e->getMessage(), 300);

            return back()->with(
                'error',
                'Pengajuan gagal dibuat. Penyebab: ' . $penyebab
            );
        }
    }

    /**
     * Mencatat keputusan resmi dari kantor pusat.
     */
    public function catatKeputusan(
        Request $request,
        Aktivasi $aktivasi
    ) {
        if ($aktivasi->status !== 'Menunggu Keputusan') {
            return back()->with(
                'error',
                'Keputusan hanya dapat dicatat untuk pengajuan yang masih menunggu.'
            );
        }

        $validated = $request->validate([
            'status' => [
                'required',
                'in:Disetujui,Ditolak',
            ],
            'tanggal_keputusan' => [
                'required',
                'date',
                'before_or_equal:today',
            ],
            'dokumen_keputusan' => [
                'required',
                'file',
                'mimes:pdf,jpg,jpeg,png',
                'max:5120',
            ],
            'catatan' => [
                'nullable',
                'required_if:status,Ditolak',
                'string',
                'max:2000',
            ],
        ], [
            'catatan.required_if' =>
                'Catatan / alasan wajib diisi jika pengajuan ditolak.',
            'tanggal_keputusan.required' =>
                'Tanggal keputusan wajib diisi.',
            'tanggal_keputusan.before_or_equal' =>
                'Tanggal keputusan tidak boleh melewati hari ini.',
            'dokumen_keputusan.required' =>
                'Dokumen keputusan resmi wajib diunggah.',
            'dokumen_keputusan.mimes' =>
                'Dokumen harus berupa PDF, JPG, JPEG, atau PNG.',
            'dokumen_keputusan.max' =>
                'Ukuran dokumen maksimal 5 MB.',
        ]);

        $pathDokumen = null;

        try {
            $pathDokumen = $request->file('dokumen_keputusan')
                ->store('aktivasi/keputusan', 'local');

            DB::transaction(function () use (
                $aktivasi,
                $validated,
                $pathDokumen
            ) {
                $data = Aktivasi::whereKey($aktivasi->id)
                    ->lockForUpdate()
                    ->firstOrFail();

                if ($data->status !== 'Menunggu Keputusan') {
                    throw new \RuntimeException(
                        'Keputusan pengajuan ini sudah pernah dicatat.'
                    );
                }

                $data->status = $validated['status'];
                $data->tanggal_keputusan = $validated['tanggal_keputusan'];
                $data->dokumen_path = $pathDokumen;
                $data->catatan = $validated['catatan'] ?? null;
                $data->save();
            });

            $this->catatRiwayat(
                (int) $aktivasi->kerja_sama_id,
                'Aktivasi',
                'Keputusan pengajuan ' . $aktivasi->nomor_pengajuan
                    . ' dicatat: ' . $validated['status'] . '.'
            );

            return redirect()
                ->route('aktivasi.show', $aktivasi->kerja_sama_id)
                ->with(
                    'success',
                    'Keputusan resmi berhasil dicatat.'
                );
        } catch (Throwable $e) {
            if ($pathDokumen) {
                Storage::disk('local')->delete($pathDokumen);
            }

            if ($e instanceof \RuntimeException) {
                return back()->with('error', $e->getMessage());
            }

            report($e);

            return back()->with(
                'error',
                'Keputusan gagal disimpan. Silakan periksa kembali.'
            );
        }
    }

    /**
     * Menampilkan surat pengajuan dalam format PDF.
     */
    public function lihatSurat(Aktivasi $aktivasi)
    {
        abort_unless(
            $aktivasi->surat_pengajuan_path &&
            Storage::disk('local')->exists(
                $aktivasi->surat_pengajuan_path
            ),
            404
        );

        return response()->file(
            Storage::disk('local')->path(
                $aktivasi->surat_pengajuan_path
            ),
            [
                'Content-Type' => 'application/pdf',
                'Content-Disposition' => 'inline; filename="'
                    . $aktivasi->nomor_pengajuan
                    . '.pdf"',
            ]
        );
    }

    /**
     * Mengunduh dokumen keputusan resmi.
     */
    public function lihatDokumenKeputusan(Aktivasi $aktivasi)
    {
        abort_unless(
            $aktivasi->dokumen_path &&
            Storage::disk('local')->exists($aktivasi->dokumen_path),
            404
        );

        return Storage::disk('local')->download(
            $aktivasi->dokumen_path
        );
    }

    private function ttdDataUri(Aktivasi $aktivasi): ?string
    {
        $path = $aktivasi->ttd_commercial_path;

        if (!$path || !Storage::disk('local')->exists($path)) {
            return null;
        }

        $mime = Storage::disk('local')->mimeType($path) ?: 'image/png';

        return 'data:' . $mime . ';base64,'
            . base64_encode(Storage::disk('local')->get($path));
    }
}
