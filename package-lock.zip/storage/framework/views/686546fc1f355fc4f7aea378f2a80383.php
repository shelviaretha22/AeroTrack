<?php $__env->startSection('page-title', 'Aktivasi'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">

    
    <div class="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
            <p class="text-sm text-gray-500">Management / Aktivasi</p>
            <h1 class="mt-1 text-2xl font-bold text-gray-800">
                Aktivasi
            </h1>
            <p class="mt-1 text-sm text-gray-500">
                Pantau Kontrak Fisik, Kontrak Sistem, dan pengajuan Aktivasi setiap tenant. Pengelolaan dilakukan melalui tombol Detail.
            </p>
        </div>
    </div>

    
    <?php if(session('success')): ?>
        <div class="rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-700">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            <p class="font-semibold">Data belum berhasil disimpan.</p>
            <ul class="mt-2 list-inside list-disc">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    
    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">

        <div class="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
            <p class="text-sm text-gray-500">Total Kerja Sama</p>
            <div class="mt-3 flex items-center justify-between">
                <h2 class="text-3xl font-bold text-gray-800"><?php echo e($totalAktivasi); ?></h2>
                <span class="rounded-xl bg-gray-100 p-3 text-gray-600">
                    <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8"
                            d="M9 12h6m-6 4h6m2 5H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7l5 5v11a2 2 0 0 1-2 2Z"/>
                    </svg>
                </span>
            </div>
        </div>

        <div class="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
            <p class="text-sm text-gray-500">Menunggu Keputusan</p>
            <div class="mt-3 flex items-center justify-between">
                <h2 class="text-3xl font-bold text-amber-600"><?php echo e($menunggu); ?></h2>
                <span class="rounded-xl bg-amber-50 p-3 text-amber-600">
                    <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="9" stroke-width="1.8"/>
                        <path stroke-linecap="round" stroke-width="1.8" d="M12 7v5l3 2"/>
                    </svg>
                </span>
            </div>
        </div>

        <div class="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
            <p class="text-sm text-gray-500">Disetujui</p>
            <div class="mt-3 flex items-center justify-between">
                <h2 class="text-3xl font-bold text-green-600"><?php echo e($disetujui); ?></h2>
                <span class="rounded-xl bg-green-50 p-3 text-green-600">
                    <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m5 12 4 4L19 6"/>
                    </svg>
                </span>
            </div>
        </div>

        <div class="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
            <p class="text-sm text-gray-500">Kontrak Sistem Aktif</p>
            <div class="mt-3 flex items-center justify-between">
                <h2 class="text-3xl font-bold text-green-600"><?php echo e($sistemAktif); ?></h2>
                <span class="rounded-xl bg-green-50 p-3 text-green-600">
                    <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="m7 7 10 10M17 7 7 17"/>
                    </svg>
                </span>
            </div>
        </div>

    </div>

    
    <div class="overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm">

        <div class="border-b border-gray-100 p-5">
            <div class="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                <div>
                    <h2 class="text-lg font-bold text-gray-800">Daftar Tenant</h2>
                    <p class="mt-1 text-sm text-gray-500">
                        Seluruh kerja sama beserta posisi BA/kontrak dan status aktivasinya.
                    </p>
                </div>

                <form method="GET" action="<?php echo e(route('aktivasi')); ?>"
                    class="flex flex-col gap-3 sm:flex-row sm:flex-wrap">

                    <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                        placeholder="Cari mitra, brand, nomor..."
                        class="w-full rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-teal-700 focus:ring-2 focus:ring-teal-100 sm:w-64">

                    <select name="kontrak_fisik"
                        class="rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-teal-700 focus:ring-2 focus:ring-teal-100">
                        <option value="">Kontrak Fisik: Semua</option>
                        <?php $__currentLoopData = $opsiKontrakFisik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($pilihan); ?>" <?php if(request('kontrak_fisik') === $pilihan): echo 'selected'; endif; ?>>
                                <?php echo e($pilihan); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <select name="kontrak_sistem"
                        class="rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-teal-700 focus:ring-2 focus:ring-teal-100">
                        <option value="">Kontrak Sistem: Semua</option>
                        <?php $__currentLoopData = $opsiKontrakSistem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($pilihan); ?>" <?php if(request('kontrak_sistem') === $pilihan): echo 'selected'; endif; ?>>
                                <?php echo e($pilihan); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <select name="status"
                        class="rounded-xl border border-gray-200 px-4 py-2.5 text-sm outline-none focus:border-teal-700 focus:ring-2 focus:ring-teal-100">
                        <option value="">Aktivasi: Semua</option>
                        <?php $__currentLoopData = $opsiAktivasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilihanStatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($pilihanStatus); ?>" <?php if(request('status') === $pilihanStatus): echo 'selected'; endif; ?>>
                                <?php echo e($pilihanStatus); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <button type="submit"
                        class="rounded-xl bg-[#365F65] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#294b50]">
                        Cari
                    </button>

                    <?php if(request()->hasAny(['search', 'kontrak_fisik', 'kontrak_sistem', 'status'])): ?>
                        <a href="<?php echo e(route('aktivasi')); ?>"
                            class="rounded-xl border border-gray-200 px-4 py-2.5 text-center text-sm font-medium text-gray-600 hover:bg-gray-50">
                            Reset
                        </a>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full min-w-[1100px] text-left text-sm">
                <thead class="bg-[#EEF6F3] text-xs uppercase tracking-wide text-[#365F65]">
                    <tr>
                        <th class="px-5 py-4 font-semibold">No.</th>
                        <th class="px-5 py-4 font-semibold">Tenant / Mitra</th>
                        <th class="px-5 py-4 font-semibold">Lokasi</th>
                        <th class="px-5 py-4 font-semibold">Kontrak Fisik</th>
                        <th class="px-5 py-4 font-semibold">Kontrak Sistem</th>
                        <th class="px-5 py-4 font-semibold">Aktivasi</th>
                        <th class="px-5 py-4 font-semibold">Masa Berlaku</th>
                        <th class="px-5 py-4 text-center font-semibold">Aksi</th>
                    </tr>
                </thead>

                <tbody class="divide-y divide-gray-100">
                    <?php $__empty_1 = true; $__currentLoopData = $dataAktivasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $kerjaSama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $lokasi = $kerjaSama->lokasi;
                            $aktivasi = $kerjaSama->aktivasi;
                            
                            $statusAktivasi = $kerjaSama->statusAktivasi();
                            $statusFisik = $kerjaSama->posisiKontrakFisik();
                            $statusSistem = $kerjaSama->statusKontrakSistem();

                            $badgeAktivasi = match ($statusAktivasi) {
                                'Disetujui' => 'bg-green-50 text-green-700',
                                'Ditolak' => 'bg-red-50 text-red-700',
                                'Menunggu Keputusan' => 'bg-amber-50 text-amber-700',
                                default => 'bg-gray-100 text-gray-600',
                            };

                            $badgeFisik = match ($statusFisik) {
                                'Kontrak Selesai' => 'bg-green-50 text-green-700',
                                'Kontrak Dalam Proses' => 'bg-blue-50 text-blue-700',
                                'BA Selesai' => 'bg-teal-50 text-teal-700',
                                'BA Belum TTD' => 'bg-amber-50 text-amber-700',
                                default => 'bg-gray-100 text-gray-600',
                            };

                            $badgeSistem = $statusSistem === 'Aktif'
                                ? 'bg-green-50 text-green-700'
                                : 'bg-gray-100 text-gray-600';
                        ?>

                        <tr class="transition hover:bg-gray-50/70">
                            <td class="px-5 py-4 text-gray-500"><?php echo e($index + 1); ?></td>

                            <td class="px-5 py-4">
                                <p class="font-semibold text-gray-800">
                                    <?php echo e($kerjaSama->mitra_usaha ?: '-'); ?>

                                </p>
                                <p class="mt-1 text-xs text-gray-500">
                                    <?php echo e($kerjaSama->brand ?: $kerjaSama->tenant?->nama_tenant ?: '-'); ?>

                                    · KS-<?php echo e(str_pad($kerjaSama->id, 4, '0', STR_PAD_LEFT)); ?>

                                </p>
                            </td>

                            <td class="px-5 py-4 text-gray-600">
                                <?php if($lokasi): ?>
                                    <p class="font-medium text-gray-700"><?php echo e($lokasi->terminal ?: '-'); ?></p>
                                    <p class="mt-1 text-xs text-gray-500"><?php echo e($lokasi->kode_tampilan ?: $lokasi->lokasi ?: ''); ?></p>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>

                            <td class="px-5 py-4">
                                <span class="inline-flex whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-semibold <?php echo e($badgeFisik); ?>">
                                    <?php echo e($statusFisik); ?>

                                </span>
                            </td>

                            <td class="px-5 py-4">
                                <span class="inline-flex whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-semibold <?php echo e($badgeSistem); ?>">
                                    <?php echo e($statusSistem); ?>

                                </span>
                                <?php if($statusSistem === 'Aktif' && $kerjaSama->tanggal_mulai): ?>
                                    <p class="mt-1 text-xs text-gray-500">
                                        Sejak <?php echo e($kerjaSama->tanggal_mulai->format('d M Y')); ?>

                                    </p>
                                <?php endif; ?>
                            </td>

                            <td class="px-5 py-4">
                                <span class="inline-flex whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-semibold <?php echo e($badgeAktivasi); ?>">
                                    <?php echo e($statusAktivasi); ?>

                                </span>
                            </td>

                            <td class="px-5 py-4 text-gray-600">
                                <?php if($kerjaSama->tanggal_mulai && $kerjaSama->tanggal_berakhir): ?>
                                    <?php echo e($kerjaSama->tanggal_mulai->format('d M Y')); ?>

                                    – <?php echo e($kerjaSama->tanggal_berakhir->format('d M Y')); ?>

                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>

                            <td class="px-5 py-4 text-center">
                                <a href="<?php echo e(route('aktivasi.show', $kerjaSama->id)); ?>"
                                    class="inline-block whitespace-nowrap rounded-lg bg-[#365F65] px-4 py-2 text-xs font-semibold text-white transition hover:bg-[#294b50]">
                                    Detail
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="px-5 py-14 text-center">
                                <p class="font-semibold text-gray-700">
                                    Data aktivasi belum ditemukan
                                </p>
                                <p class="mt-1 text-sm text-gray-500">
                                    Pastikan dokumen BA tersedia atau ubah kata kunci pencarian.
                                </p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="flex flex-col gap-2 border-t border-gray-100 px-5 py-4 text-sm text-gray-500 sm:flex-row sm:items-center sm:justify-between">
            <p>Menampilkan <?php echo e($dataAktivasi->count()); ?> kerja sama</p>
            <p>Pengajuan aktivasi baru dapat dibuat setelah BA tersedia.</p>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\AeroTrack\resources\views/aktivasi/index.blade.php ENDPATH**/ ?>